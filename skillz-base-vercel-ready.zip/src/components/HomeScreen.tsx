import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Play, 
  Volume2, 
  Video, 
  Zap
} from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const { setCurrentTab, openModal, paymentSettings } = useApp();

  return (
    <div className="pb-24 pt-2 px-3 max-w-md mx-auto space-y-4">
      {/* Marquee Notice Bar matching video (00:16, 01:21) */}
      <div className="bg-[#121935] border border-amber-500/30 rounded-xl px-3 py-2 flex items-center gap-2 shadow-md overflow-hidden">
        <div className="flex items-center gap-1 shrink-0 bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded text-xs font-bold border border-amber-500/30">
          <Volume2 className="w-3.5 h-3.5 animate-pulse" />
          <span>নোটিশঃ</span>
        </div>
        <div className="overflow-hidden whitespace-nowrap w-full text-xs text-slate-200 font-medium">
          <div className="inline-block animate-marquee pl-4">
            {paymentSettings.marqueeNotice || `আমাদের অ্যাপে ২৪ ঘণ্টা ম্যাচ খেলতে পারবেন এবং খেলার সঙ্গী অনেক পাবেন। 🏆 WhatsApp হেল্পলাইন: ${paymentSettings.whatsappSupport || '01972943649'} 👈 যেকোনো সমস্যায় সাথে সাথে ম্যাসেজ দিন।`}
          </div>
        </div>
      </div>

      {/* Block Puzzle Duel (Skillz Base Feature) */}
      <div 
        id="home-block-puzzle-card"
        onClick={() => setCurrentTab('block_puzzle')}
        className="bg-gradient-to-r from-blue-950/90 via-[#182352] to-purple-950/90 border-2 border-cyan-400/80 rounded-2xl p-4 flex items-center justify-between shadow-2xl cursor-pointer hover:border-cyan-300 active:scale-[0.99] transition-all group relative overflow-hidden"
      >
        <div className="absolute top-0 right-1/4 w-28 h-28 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center gap-3.5 z-10">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-cyan-400 via-indigo-500 to-purple-500 p-0.5 shadow-lg flex items-center justify-center group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#0d1222] rounded-[14px] flex items-center justify-center text-2xl">
              🧩
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="font-black text-white text-base group-hover:text-cyan-300 transition-colors">
                Block Puzzle Duel
              </h4>
              <span className="bg-cyan-500 text-slate-950 text-[9.5px] font-black px-1.5 py-0.2 rounded-md shadow-sm uppercase tracking-wide flex items-center gap-0.5 animate-pulse">
                <Zap className="w-2.5 h-2.5 fill-current" /> 1v1 NEW
              </span>
            </div>
            <p className="text-xs text-cyan-300 font-bold mt-0.5 flex items-center gap-1">
              <span>⚔️ Synchronized 1v1 • Practice • Ranked</span>
            </p>
            <span className="text-[11px] text-slate-300 block">
              ১০x১০ গ্রিড ডুয়েল • এন্ট্রি ফি দিয়ে খেলুন ও স্কোর সাবমিট করুন
            </span>
          </div>
        </div>

        <button
          id="home-block-puzzle-play-btn"
          className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-1.5 group-hover:scale-105 active:scale-95 transition-all z-10"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Play</span>
        </button>
      </div>

      {/* Quick Menu Grid */}
      <div className="grid grid-cols-3 gap-2 pt-1">
        <button
          id="quick-wallet-btn"
          onClick={() => setCurrentTab('wallet')}
          className="bg-[#121935] hover:bg-[#182145] border border-indigo-900/60 rounded-xl p-2.5 flex flex-col items-center text-center transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-amber-400/10 flex items-center justify-center text-amber-400 mb-1">
            💰
          </div>
          <span className="text-xs font-bold text-white">ওয়ালেট</span>
          <span className="text-[10px] text-slate-400">ডিপোজিট / উইথড্র</span>
        </button>

        <button
          id="quick-transactions-btn"
          onClick={() => setCurrentTab('transactions')}
          className="bg-[#121935] hover:bg-[#182145] border border-indigo-900/60 rounded-xl p-2.5 flex flex-col items-center text-center transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-blue-400/10 flex items-center justify-center text-blue-400 mb-1">
            📜
          </div>
          <span className="text-xs font-bold text-white">লেনদেন</span>
          <span className="text-[10px] text-slate-400">হিস্ট্রি দেখুন</span>
        </button>

        <button
          id="quick-leaderboard-btn"
          onClick={() => openModal('leaderboard')}
          className="bg-[#121935] hover:bg-[#182145] border border-indigo-900/60 rounded-xl p-2.5 flex flex-col items-center text-center transition-colors"
        >
          <div className="w-8 h-8 rounded-full bg-purple-400/10 flex items-center justify-center text-purple-400 mb-1">
            👑
          </div>
          <span className="text-xs font-bold text-white">টপ প্লেয়ার</span>
          <span className="text-[10px] text-slate-400">লিডারবোর্ড</span>
        </button>
      </div>

      {/* Rules and Video Tutorial Banner */}
      <div className="bg-[#10162e] border border-indigo-950 rounded-xl p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Video className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-slate-300">খেলা শিখতে ও ভিডিও দেখতে চান?</span>
        </div>
        <button
          id="home-tutorials-btn"
          onClick={() => openModal('video_tutorials')}
          className="text-xs font-bold text-amber-400 hover:underline"
        >
          ভিডিও দেখুন ›
        </button>
      </div>
    </div>
  );
};
