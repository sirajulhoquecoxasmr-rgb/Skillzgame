import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, 
  UploadCloud, 
  RotateCw, 
  Flame, 
  Clock, 
  UserCheck, 
  HelpCircle, 
  KeyRound,
  ShieldAlert,
  Wallet,
  Lock
} from 'lucide-react';
import { Match, MatchCategory } from '../types';

export const MatchListScreen: React.FC = () => {
  const { 
    matches, 
    matchFilter, 
    setMatchFilter, 
    setCurrentTab, 
    user, 
    openModal, 
    refreshMatches, 
    isRefreshing 
  } = useApp();

  // Filter matches based on tab
  const filteredMatches = matches.filter((m) => {
    if (matchFilter === 'special') return m.category === 'special';
    if (matchFilter === 'time') return m.category === 'time';
    if (matchFilter === 'one_player') return m.joinedSeats === 1;
    return true;
  });

  const handleJoinClick = (match: Match) => {
    openModal('join_match', match);
  };

  const handleRoomIdClick = (match: Match) => {
    openModal('room_id', match);
  };

  return (
    <div className="pb-24 pt-1 px-3 max-w-md mx-auto relative min-h-screen">
      {/* Sub Header (00:22) */}
      <div className="sticky top-14 z-30 bg-[#0d1222]/95 backdrop-blur-md py-2.5 mb-3 flex items-center justify-between border-b border-indigo-950/60">
        <div className="flex items-center gap-2">
          <button
            id="matches-back-btn"
            onClick={() => setCurrentTab('home')}
            className="w-8 h-8 rounded-full bg-indigo-950/80 hover:bg-indigo-900 text-slate-300 flex items-center justify-center border border-indigo-800/40"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h2 className="text-base font-extrabold text-white tracking-wide">
            Ludo Matches
          </h2>
        </div>

        <div className="flex items-center gap-2">
          {/* Balance chip */}
          <div 
            onClick={() => setCurrentTab('wallet')}
            className="flex items-center gap-1 bg-[#151c38] px-2 py-1 rounded-md border border-indigo-800/50 text-xs font-bold text-amber-400 cursor-pointer"
          >
            <span>৳</span>
            <span className="font-mono">{user.gamingBalance.toFixed(0)}</span>
          </div>

          {/* Upload Screenshot Result Button (00:22, 02:44) */}
          <button
            id="matches-upload-result-btn"
            onClick={() => setCurrentTab('upload_result')}
            className="w-8 h-8 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center border border-indigo-400/40 shadow-sm active:scale-95 transition-all"
            title="Upload Result Screenshot"
          >
            <UploadCloud className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Tabs (00:22, 01:10) */}
      <div className="grid grid-cols-3 gap-1.5 mb-4 bg-[#11172f] p-1 rounded-xl border border-indigo-950">
        <button
          id="tab-special-matches"
          onClick={() => setMatchFilter('special')}
          className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            matchFilter === 'special'
              ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>🔥</span>
          <span className="truncate">স্পেশাল ম্যাচ</span>
        </button>

        <button
          id="tab-time-matches"
          onClick={() => setMatchFilter('time')}
          className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            matchFilter === 'time'
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>⏱️</span>
          <span className="truncate">টাইম ম্যাচ</span>
        </button>

        <button
          id="tab-one-player-matches"
          onClick={() => setMatchFilter('one_player')}
          className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
            matchFilter === 'one_player'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>👤</span>
          <span className="truncate">১ জন জয়েন</span>
        </button>
      </div>

      {/* Match Cards List (00:23 - 00:58) */}
      <div className="space-y-3.5">
        {filteredMatches.length === 0 ? (
          <div className="bg-[#121935] border border-indigo-950 rounded-2xl p-8 text-center">
            <p className="text-sm text-slate-400">এই ক্যাটাগরিতে বর্তমানে কোনো ম্যাচ নেই।</p>
            <button
              onClick={() => setMatchFilter('special')}
              className="mt-3 bg-amber-500 text-slate-950 px-4 py-1.5 rounded-lg text-xs font-bold"
            >
              সব স্পেশাল ম্যাচ দেখুন
            </button>
          </div>
        ) : (
          filteredMatches.map((match) => {
            const isFull = match.joinedSeats >= match.totalSeats;
            const isUserJoined = match.joinedPlayers.some(
              (p) => p.userId === user.id || p.phone === user.phone || (user.ludoKingName && p.ludoKingName === user.ludoKingName)
            );

            return (
              <div
                key={match.id}
                id={`match-card-${match.matchNo}`}
                className="bg-white rounded-2xl p-4 shadow-xl border border-slate-200 text-slate-900 relative overflow-hidden"
              >
                {/* Match Header */}
                <div className="text-center mb-3">
                  <h3 className="font-black text-base text-red-600 tracking-wide flex items-center justify-center gap-1">
                    {match.title}
                  </h3>
                  <p className="text-xs text-red-500 font-semibold mt-0.5">
                    {match.subtitle}
                  </p>
                </div>

                {/* Match Details Grid */}
                <div className="grid grid-cols-2 gap-4 py-2 border-y border-slate-100">
                  {/* Left Column */}
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Total Prize</div>
                    <div className="text-base font-extrabold text-slate-900 flex items-center gap-0.5">
                      <span>৳</span>{match.totalPrize}
                    </div>

                    <div className="mt-2 text-xs text-slate-500 font-medium">Version</div>
                    <div className="text-xs font-bold text-slate-800">{match.version}</div>
                  </div>

                  {/* Right Column */}
                  <div className="text-right">
                    <div className="text-xs text-slate-500 font-medium">Entry Fee</div>
                    <div className="text-base font-extrabold text-slate-900 flex items-center justify-end gap-0.5">
                      <span>৳</span>{match.entryFee}
                    </div>

                    <div className="mt-2 text-xs text-slate-500 font-medium">Board Type</div>
                    <div className="text-xs font-bold text-slate-800">{match.boardType}</div>
                  </div>
                </div>

                {/* Progress bar / Player count */}
                <div className="mt-3 flex items-center justify-between text-xs font-bold text-slate-600 mb-1.5">
                  <span className="text-slate-500 font-mono text-[11px]">
                    {match.joinedSeats}/{match.totalSeats}
                  </span>
                  {isFull ? (
                    <span className="bg-red-600 text-white text-[10px] font-extrabold px-3 py-0.5 rounded-md uppercase tracking-wider">
                      SEAT FULL
                    </span>
                  ) : (
                    <button
                      id={`match-join-btn-${match.matchNo}`}
                      onClick={() => handleJoinClick(match)}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold px-4 py-1 rounded-md uppercase tracking-wider shadow-md active:scale-95 transition-all"
                    >
                      JOIN
                    </button>
                  )}
                </div>

                {/* Progress bar line */}
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mb-3">
                  <div
                    className={`h-full transition-all duration-500 ${
                      isFull ? 'bg-red-600' : 'bg-blue-600'
                    }`}
                    style={{ width: `${(match.joinedSeats / match.totalSeats) * 100}%` }}
                  />
                </div>

                {/* Card Action Buttons (00:23) */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    id={`match-limit-btn-${match.matchNo}`}
                    onClick={() => openModal('daily_limit')}
                    className="bg-[#4d63b8] hover:bg-[#3d51a0] text-white text-xs font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1 shadow transition-colors"
                  >
                    <span>দৈনিক লিমিট?</span>
                  </button>

                  {isFull && !isUserJoined ? (
                    <button
                      id={`match-room-btn-${match.matchNo}`}
                      disabled={true}
                      className="bg-slate-300 text-slate-500 cursor-not-allowed text-xs font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1 shadow-none opacity-60 select-none"
                      title="সিট ফুল - রুম আইডি শুধুমাত্র জয়েন করা প্লেয়ারদের জন্য"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Room ID (লক)</span>
                    </button>
                  ) : isFull && isUserJoined ? (
                    <button
                      id={`match-room-btn-${match.matchNo}`}
                      onClick={() => handleRoomIdClick(match)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1 shadow transition-colors animate-pulse"
                      title="আপনার রুম কোড দেখুন"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>🔑 আমার Room ID</span>
                    </button>
                  ) : (
                    <button
                      id={`match-room-btn-${match.matchNo}`}
                      onClick={() => handleRoomIdClick(match)}
                      className="bg-[#4d63b8] hover:bg-[#3d51a0] text-white text-xs font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1 shadow transition-colors"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Room ID</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating Refresh Button (00:23, 00:50) */}
      <button
        id="matches-fab-refresh-btn"
        onClick={refreshMatches}
        className="fixed bottom-18 right-4 z-40 w-12 h-12 rounded-full bg-[#10b981] hover:bg-[#059669] text-white flex items-center justify-center shadow-2xl active:scale-90 transition-all border-2 border-white/40"
        title="Refresh Matches"
      >
        <RotateCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
      </button>
    </div>
  );
};
