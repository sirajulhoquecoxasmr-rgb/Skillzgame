import React from 'react';
import { Sparkles, Dices, RefreshCw } from 'lucide-react';

interface LudoDiceProps {
  value: number | null;
  isRolling: boolean;
  canRoll: boolean;
  onRoll: () => void;
  color: 'red' | 'green';
  hasRolledSix?: boolean;
}

export const LudoDice: React.FC<LudoDiceProps> = ({
  value,
  isRolling,
  canRoll,
  onRoll,
  color,
  hasRolledSix,
}) => {
  const isRed = color === 'red';

  // Render authentic dice pips/dots
  const renderPips = (num: number) => {
    switch (num) {
      case 1:
        return (
          <div className="w-full h-full flex items-center justify-center">
            <div className={`w-3.5 h-3.5 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
          </div>
        );
      case 2:
        return (
          <div className="w-full h-full flex flex-col justify-between p-1">
            <div className="flex justify-start"><div className="w-2.5 h-2.5 rounded-full bg-slate-900 shadow-inner" /></div>
            <div className="flex justify-end"><div className="w-2.5 h-2.5 rounded-full bg-slate-900 shadow-inner" /></div>
          </div>
        );
      case 3:
        return (
          <div className="w-full h-full flex flex-col justify-between p-1">
            <div className="flex justify-start"><div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" /></div>
            <div className="flex justify-center"><div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" /></div>
            <div className="flex justify-end"><div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" /></div>
          </div>
        );
      case 4:
        return (
          <div className="w-full h-full flex flex-col justify-between p-1">
            <div className="flex justify-between">
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
            </div>
            <div className="flex justify-between">
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
            </div>
          </div>
        );
      case 5:
        return (
          <div className="w-full h-full flex flex-col justify-between p-1">
            <div className="flex justify-between">
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
            </div>
            <div className="flex justify-center">
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
            </div>
            <div className="flex justify-between">
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
              <div className="w-2 h-2 rounded-full bg-slate-900 shadow-inner" />
            </div>
          </div>
        );
      case 6:
        return (
          <div className="w-full h-full flex flex-col justify-between p-1">
            <div className="flex justify-between">
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
            </div>
            <div className="flex justify-between">
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
            </div>
            <div className="flex justify-between">
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
              <div className={`w-2 h-2 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'} shadow-inner`} />
            </div>
          </div>
        );
      default:
        return (
          <div className="w-full h-full flex items-center justify-center text-slate-400">
            <Dices className="w-6 h-6 animate-pulse" />
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col items-center gap-1.5">
      {/* 3D Dice Box */}
      <button
        id={`ludo-dice-${color}`}
        type="button"
        disabled={!canRoll || isRolling}
        onClick={onRoll}
        className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-white via-slate-100 to-slate-200 border-2 shadow-2xl p-1 flex items-center justify-center transition-all ${
          canRoll && !isRolling
            ? 'cursor-pointer hover:scale-105 active:scale-95 ring-4 ring-amber-400/80 shadow-amber-500/40 animate-pulse'
            : 'cursor-default opacity-90'
        } ${
          isRed
            ? 'border-red-400 shadow-red-500/20'
            : 'border-emerald-400 shadow-emerald-500/20'
        }`}
      >
        {/* Animated Spin during Roll */}
        <div
          className={`w-full h-full rounded-xl bg-gradient-to-b from-white to-slate-100 flex items-center justify-center shadow-inner border border-slate-300 ${
            isRolling ? 'animate-spin' : ''
          }`}
        >
          {value ? renderPips(value) : renderPips(0)}
        </div>

        {/* 6 Bonus Badge */}
        {hasRolledSix && !isRolling && (
          <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-full border border-amber-300 shadow-md animate-bounce">
            +1 ROLL
          </span>
        )}
      </button>

      {/* Helper text */}
      {canRoll && !isRolling && (
        <span className="text-[10px] font-extrabold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/30 animate-pulse">
          ট্যাপ করে চালুন
        </span>
      )}
    </div>
  );
};
