import React from 'react';
import { 
  LudoToken, 
  CellCoord, 
  SAFE_INDICES, 
  MAIN_PATH 
} from '../../utils/ludoConstants';
import { Sparkles, Trophy, Star } from 'lucide-react';

interface LudoBoardViewProps {
  redTokens: LudoToken[];
  greenTokens: LudoToken[];
  currentTurn: 'red' | 'green';
  movableTokenIds: number[];
  onTokenClick: (token: LudoToken) => void;
  isMoving: boolean;
  diceValue: number | null;
  mode: 'quick' | 'classic';
}

export const LudoBoardView: React.FC<LudoBoardViewProps> = ({
  redTokens,
  greenTokens,
  currentTurn,
  movableTokenIds,
  onTokenClick,
  isMoving,
  mode,
}) => {
  // Check if a coordinate is a safe star
  const isSafeStar = (r: number, c: number) => {
    // Red Start
    if (r === 6 && c === 1) return true;
    // Green Start
    if (r === 8 && c === 13) return true;
    // Stars on arms
    if (r === 2 && c === 6) return true;
    if (r === 1 && c === 8) return true;
    if (r === 6 && c === 12) return true;
    if (r === 12 && c === 8) return true;
    if (r === 13 && c === 6) return true;
    if (r === 8 && c === 2) return true;
    return false;
  };

  // Check cell color/type
  const getCellType = (r: number, c: number) => {
    // Yards
    if (r < 6 && c < 6) return 'yard-red';
    if (r < 6 && c > 8) return 'yard-blue';
    if (r > 8 && c < 6) return 'yard-yellow';
    if (r > 8 && c > 8) return 'yard-green';

    // Center Goal
    if (r >= 6 && r <= 8 && c >= 6 && c <= 8) return 'center';

    // Red Start & Home Corridor
    if (r === 6 && c === 1) return 'red-start';
    if (r === 7 && c >= 1 && c <= 5) return 'red-home';

    // Green Start & Home Corridor
    if (r === 8 && c === 13) return 'green-start';
    if (r === 7 && c >= 9 && c <= 13) return 'green-home';

    // Blue Start & Home Corridor
    if (r === 1 && c === 8) return 'blue-start';
    if (c === 7 && r >= 1 && r <= 5) return 'blue-home';

    // Yellow Start & Home Corridor
    if (r === 13 && c === 6) return 'yellow-start';
    if (c === 7 && r >= 9 && r <= 13) return 'yellow-home';

    return 'normal';
  };

  // Calculate percentage position on 15x15 board
  const getPercentPosition = (coord: CellCoord, stackIndex = 0, totalOnCell = 1) => {
    const cellSize = 100 / 15;
    let baseLeft = coord.c * cellSize + cellSize / 2;
    let baseTop = coord.r * cellSize + cellSize / 2;

    // If multiple tokens on same cell, stagger them slightly
    if (totalOnCell > 1) {
      const offset = (stackIndex - (totalOnCell - 1) / 2) * 1.8;
      baseLeft += offset;
      baseTop += offset;
    }

    return { left: `${baseLeft}%`, top: `${baseTop}%` };
  };

  // Group tokens currently on board cells
  const allTokens = [...redTokens, ...greenTokens];
  const cellTokensMap = new Map<string, LudoToken[]>();

  allTokens.forEach(t => {
    const key = `${t.position.r.toFixed(1)}_${t.position.c.toFixed(1)}`;
    if (!cellTokensMap.has(key)) {
      cellTokensMap.set(key, []);
    }
    cellTokensMap.get(key)!.push(t);
  });

  return (
    <div className="w-full max-w-[370px] mx-auto aspect-square bg-[#0b0f1f] rounded-2xl p-2 shadow-2xl border-2 border-indigo-500/50 relative select-none">
      {/* 15x15 Base Board Layout */}
      <div className="w-full h-full relative rounded-xl overflow-hidden bg-[#161d36] border border-indigo-900 grid grid-cols-15 grid-rows-15">
        
        {/* Render Cells */}
        {Array.from({ length: 15 }).map((_, r) => (
          <div key={`row-${r}`} className="contents">
            {Array.from({ length: 15 }).map((_, c) => {
              const type = getCellType(r, c);
              const isStar = isSafeStar(r, c);

              // Don't render individual cells for Yards and Center (rendered as big overlay blocks below)
              if (
                (r < 6 && c < 6) ||
                (r < 6 && c > 8) ||
                (r > 8 && c < 6) ||
                (r > 8 && c > 8) ||
                (r >= 6 && r <= 8 && c >= 6 && c <= 8)
              ) {
                return <div key={`empty-${r}-${c}`} className="w-full h-full" />;
              }

              // Path cell colors
              let bgClass = 'bg-[#182038] border-indigo-950/70';
              let textClass = '';

              if (type === 'red-start' || type === 'red-home') {
                bgClass = 'bg-red-600/90 border-red-700/80';
              } else if (type === 'green-start' || type === 'green-home') {
                bgClass = 'bg-emerald-600/90 border-emerald-700/80';
              } else if (type === 'blue-start' || type === 'blue-home') {
                bgClass = 'bg-blue-600/80 border-blue-700/80';
              } else if (type === 'yellow-start' || type === 'yellow-home') {
                bgClass = 'bg-amber-500/80 border-amber-600/80';
              }

              return (
                <div
                  key={`cell-${r}-${c}`}
                  className={`w-full h-full border-[0.5px] ${bgClass} flex items-center justify-center relative overflow-hidden`}
                >
                  {isStar && (
                    <span className="text-amber-300 drop-shadow-md text-[10px] sm:text-xs animate-pulse">
                      ★
                    </span>
                  )}
                  {type === 'red-start' && !isStar && (
                    <div className="w-2 h-2 rounded-full bg-red-400 opacity-60" />
                  )}
                  {type === 'green-start' && !isStar && (
                    <div className="w-2 h-2 rounded-full bg-emerald-400 opacity-60" />
                  )}
                  {type === 'red-home' && c === 1 && (
                    <span className="text-white/80 text-[8px] font-bold">▶</span>
                  )}
                  {type === 'green-home' && c === 13 && (
                    <span className="text-white/80 text-[8px] font-bold">◀</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}

        {/* ================= CORNER YARDS & CENTER OVERLAYS ================= */}

        {/* 1. Red Yard (Top Left: 6x6) */}
        <div 
          className="absolute top-0 left-0 w-[40%] h-[40%] bg-gradient-to-br from-red-600 via-rose-600 to-red-800 p-2 border-r-2 border-b-2 border-slate-900 shadow-inner flex items-center justify-center z-10"
        >
          <div className="w-[82%] h-[82%] rounded-2xl bg-[#0e1428] border-2 border-red-400/60 shadow-xl flex items-center justify-center p-2">
            <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-2">
              <div className="rounded-full bg-red-950/70 border-2 border-red-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-red-400/40" />
              </div>
              <div className="rounded-full bg-red-950/70 border-2 border-red-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-red-400/40" />
              </div>
              <div className="rounded-full bg-red-950/70 border-2 border-red-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-red-400/40" />
              </div>
              <div className="rounded-full bg-red-950/70 border-2 border-red-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-red-400/40" />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Blue Yard (Top Right: 6x6) */}
        <div 
          className="absolute top-0 right-0 w-[40%] h-[40%] bg-gradient-to-bl from-blue-600 via-indigo-600 to-blue-800 p-2 border-l-2 border-b-2 border-slate-900 shadow-inner flex items-center justify-center z-10"
        >
          <div className="w-[82%] h-[82%] rounded-2xl bg-[#0e1428] border-2 border-blue-400/60 shadow-xl flex items-center justify-center p-2">
            <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-2">
              <div className="rounded-full bg-blue-950/70 border-2 border-blue-500/40" />
              <div className="rounded-full bg-blue-950/70 border-2 border-blue-500/40" />
              <div className="rounded-full bg-blue-950/70 border-2 border-blue-500/40" />
              <div className="rounded-full bg-blue-950/70 border-2 border-blue-500/40" />
            </div>
          </div>
        </div>

        {/* 3. Yellow Yard (Bottom Left: 6x6) */}
        <div 
          className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-600 p-2 border-r-2 border-t-2 border-slate-900 shadow-inner flex items-center justify-center z-10"
        >
          <div className="w-[82%] h-[82%] rounded-2xl bg-[#0e1428] border-2 border-amber-400/60 shadow-xl flex items-center justify-center p-2">
            <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-2">
              <div className="rounded-full bg-amber-950/70 border-2 border-amber-500/40" />
              <div className="rounded-full bg-amber-950/70 border-2 border-amber-500/40" />
              <div className="rounded-full bg-amber-950/70 border-2 border-amber-500/40" />
              <div className="rounded-full bg-amber-950/70 border-2 border-amber-500/40" />
            </div>
          </div>
        </div>

        {/* 4. Green Yard (Bottom Right: 6x6) */}
        <div 
          className="absolute bottom-0 right-0 w-[40%] h-[40%] bg-gradient-to-tl from-emerald-600 via-green-600 to-teal-800 p-2 border-l-2 border-t-2 border-slate-900 shadow-inner flex items-center justify-center z-10"
        >
          <div className="w-[82%] h-[82%] rounded-2xl bg-[#0e1428] border-2 border-emerald-400/60 shadow-xl flex items-center justify-center p-2">
            <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-2">
              <div className="rounded-full bg-emerald-950/70 border-2 border-emerald-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-emerald-400/40" />
              </div>
              <div className="rounded-full bg-emerald-950/70 border-2 border-emerald-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-emerald-400/40" />
              </div>
              <div className="rounded-full bg-emerald-950/70 border-2 border-emerald-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-emerald-400/40" />
              </div>
              <div className="rounded-full bg-emerald-950/70 border-2 border-emerald-500/50 flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 rounded-full bg-emerald-400/40" />
              </div>
            </div>
          </div>
        </div>

        {/* 5. Center Winning Triangle Arena (3x3: Rows 6-8, Cols 6-8) */}
        <div className="absolute top-[40%] left-[40%] w-[20%] h-[20%] border-2 border-slate-950 z-10 overflow-hidden bg-[#0d1222]">
          {/* SVG 4 Quadrant Triangles */}
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Left Red Triangle */}
            <polygon points="0,0 50,50 0,100" fill="#dc2626" />
            {/* Top Blue Triangle */}
            <polygon points="0,0 50,50 100,0" fill="#2563eb" />
            {/* Right Green Triangle */}
            <polygon points="100,0 50,50 100,100" fill="#059669" />
            {/* Bottom Yellow Triangle */}
            <polygon points="0,100 50,50 100,100" fill="#d97706" />
            {/* Center Golden Ring */}
            <circle cx="50" cy="50" r="16" fill="#0f172a" stroke="#fbbf24" strokeWidth="2" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <Trophy className="w-4 h-4 text-amber-400 drop-shadow" />
          </div>
        </div>

        {/* ================= INTERACTIVE TOKENS (PIECES) ================= */}
        {allTokens.map((token) => {
          const key = `${token.position.r.toFixed(1)}_${token.position.c.toFixed(1)}`;
          const stack = cellTokensMap.get(key) || [token];
          const stackIndex = stack.findIndex(t => t.id === token.id && t.color === token.color);
          const pos = getPercentPosition(token.position, stackIndex, stack.length);

          const isMovable = currentTurn === token.color && movableTokenIds.includes(token.id);
          const isRed = token.color === 'red';

          return (
            <div
              key={`token-${token.color}-${token.id}`}
              id={`ludo-token-${token.color}-${token.id}`}
              onClick={() => {
                if (isMovable && !isMoving) {
                  onTokenClick(token);
                }
              }}
              style={{
                left: pos.left,
                top: pos.top,
                transform: 'translate(-50%, -50%)',
                transition: 'all 0.22s cubic-bezier(0.34, 1.56, 0.64, 1)',
              }}
              className={`absolute z-30 flex flex-col items-center justify-center select-none ${
                isMovable 
                  ? 'cursor-pointer scale-125 z-40 p-1' 
                  : 'cursor-default pointer-events-none'
              }`}
            >
              {/* Tap Hand Indicator when Movable */}
              {isMovable && (
                <div className="absolute -top-5 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-bounce">
                  <span className="text-xs filter drop-shadow">👆</span>
                </div>
              )}

              {/* Pulsing Outer Aura if movable */}
              {isMovable && (
                <span 
                  className={`absolute -inset-1.5 rounded-full animate-ping opacity-85 pointer-events-none ${
                    isRed ? 'bg-amber-400' : 'bg-emerald-400'
                  }`} 
                />
              )}

              {/* 3D Glossy Piece Body */}
              <div
                className={`w-6 h-6 sm:w-7 sm:h-7 rounded-full shadow-lg flex items-center justify-center border-2 transition-all ${
                  isRed
                    ? 'bg-gradient-to-b from-rose-400 via-red-600 to-red-900 border-white text-white shadow-red-500/50'
                    : 'bg-gradient-to-b from-emerald-300 via-emerald-600 to-teal-900 border-white text-white shadow-emerald-500/50'
                } ${
                  isMovable 
                    ? 'ring-4 ring-amber-400 ring-offset-1 ring-offset-[#0b0f1f] shadow-amber-400/60 animate-pulse active:scale-90 pointer-events-auto' 
                    : ''
                }`}
              >
                {/* Inner token icon/dot */}
                <div className="w-2.5 h-2.5 rounded-full bg-white/90 shadow-inner flex items-center justify-center">
                  <div className={`w-1.5 h-1.5 rounded-full ${isRed ? 'bg-red-600' : 'bg-emerald-600'}`} />
                </div>
              </div>
            </div>
          );
        })}

      </div>
    </div>
  );
};
