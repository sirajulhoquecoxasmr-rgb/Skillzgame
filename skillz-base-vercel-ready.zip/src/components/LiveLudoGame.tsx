import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LudoToken, 
  LivePlayer, 
  BOT_OPPONENTS, 
  CHAT_REACTIONS,
  MAIN_PATH,
  RED_HOME_PATH,
  GREEN_HOME_PATH,
  RED_YARD_SPOTS,
  GREEN_YARD_SPOTS,
  SAFE_INDICES,
  CellCoord
} from '../utils/ludoConstants';
import { ludoAudio } from '../utils/ludoAudio';
import { LudoBoardView } from './ludo/LudoBoardView';
import { LudoDice } from './ludo/LudoDice';
import { 
  ArrowLeft, 
  Trophy, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Zap, 
  ShieldAlert, 
  Users, 
  Globe, 
  AlertCircle, 
  Play, 
  Clock, 
  HelpCircle, 
  CheckCircle2,
  RefreshCw,
  Flame,
  MessageCircle,
  XCircle,
  Swords,
  Radio
} from 'lucide-react';
import confetti from 'canvas-confetti';

type GamePhase = 'lobby' | 'matchmaking' | 'match_found' | 'playing' | 'gameover';
type GameMode = 'quick' | 'classic'; // quick = 2 tokens to home, classic = 4 tokens to home
type OpponentType = 'online' | 'bot' | 'pass_play';

// Cross-tab broadcast matchmaking channel
const MATCH_CHANNEL_NAME = 'lx_ludo_live_matchmaking_v2';
const QUEUE_STORAGE_KEY = 'lx_ludo_active_queue_tickets_v2';

interface QueueTicket {
  id: string;
  playerId: string;
  playerName: string;
  playerAvatar: string;
  location: string;
  winRate: string;
  level: number;
  entryFee: number;
  mode: GameMode;
  timestamp: number;
}

export const LiveLudoGame: React.FC = () => {
  const { 
    user, 
    setCurrentTab, 
    openModal, 
    startLiveLudoMatch, 
    finishLiveLudoMatch, 
    refundLiveLudoMatch 
  } = useApp();

  // Settings State - Default ৳20 as requested
  const [entryFee, setEntryFee] = useState<number>(20);
  const [customFee, setCustomFee] = useState<string>('');
  const [gameMode, setGameMode] = useState<GameMode>('quick');
  const [opponentType, setOpponentType] = useState<OpponentType>('online');
  const [isMuted, setIsMuted] = useState<boolean>(ludoAudio.getMuted());
  const [error, setError] = useState<string>('');
  const [showSurrenderModal, setShowSurrenderModal] = useState<boolean>(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);
  const [floatingReaction, setFloatingReaction] = useState<{ sender: 'red' | 'green'; emoji: string; text: string } | null>(null);

  // Match Engine State
  const [gamePhase, setGamePhase] = useState<GamePhase>('lobby');
  const [matchId, setMatchId] = useState<string>('');
  const [opponent, setOpponent] = useState<LivePlayer | null>(null);
  const [searchSeconds, setSearchSeconds] = useState<number>(0);
  const [startCountdown, setStartCountdown] = useState<number>(3);
  
  // Board & Turn State
  const [currentTurn, setCurrentTurn] = useState<'red' | 'green'>('red');
  const [diceValue, setDiceValue] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [canRoll, setCanRoll] = useState<boolean>(true);
  const [movableTokenIds, setMovableTokenIds] = useState<number[]>([]);
  const [isMovingToken, setIsMovingToken] = useState<boolean>(false);
  const [turnMessage, setTurnMessage] = useState<string>('');
  const [hasBonusRoll, setHasBonusRoll] = useState<boolean>(false);
  const [turnTimer, setTurnTimer] = useState<number>(15);
  const [winner, setWinner] = useState<'red' | 'green' | null>(null);

  // Tokens
  const [redTokens, setRedTokens] = useState<LudoToken[]>([]);
  const [greenTokens, setGreenTokens] = useState<LudoToken[]>([]);

  // Timers and references
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const botTurnTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const searchTimerRef = useRef<NodeJS.Timeout | null>(null);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);

  // Tiered Options (৳২০ থেকে ৳৫০ পর্যন্ত: প্রতি ১০০ তে ২০ টাকা লাভ / ১.৬ গুণ উইনিং)
  const entryFeeOptions = [20, 25, 30, 35, 40, 45, 50];
  const targetWinTokens = gameMode === 'quick' ? 2 : 4;
  
  // Continuous 1.6x calculation: প্রতি ১০০ তে ২০ টাকা এডমিন চার্জ, বিজয়ী পাবে ৮০ টাকা (১.৬ গুণ)
  // ৳20 ➔ ৳32, ৳25 ➔ ৳40, ৳30 ➔ ৳48, ৳35 ➔ ৳56, ৳40 ➔ ৳64, ৳45 ➔ ৳72, ৳50 ➔ ৳80
  const calculateWinPrize = (fee: number) => Math.round(fee * 1.6);
  const currentPrize = calculateWinPrize(customFee ? Number(customFee) || entryFee : entryFee);

  // Initialize Tokens based on game mode
  const initTokens = (mode: GameMode) => {
    const count = mode === 'quick' ? 2 : 4;
    const reds: LudoToken[] = [];
    const greens: LudoToken[] = [];

    for (let i = 0; i < count; i++) {
      reds.push({
        id: i,
        color: 'red',
        step: -1, // in Yard
        position: RED_YARD_SPOTS[i],
        isHome: false,
      });
      greens.push({
        id: i,
        color: 'green',
        step: -1, // in Yard
        position: GREEN_YARD_SPOTS[i],
        isHome: false,
      });
    }

    setRedTokens(reds);
    setGreenTokens(greens);
  };

  // Toggle Sound
  const toggleMute = () => {
    const muted = ludoAudio.toggleMute();
    setIsMuted(muted);
  };

  // Convert logical step (0..56) to board coordinates
  const getCoordinatesForStep = (color: 'red' | 'green', step: number, tokenId: number): CellCoord => {
    if (step === -1) {
      return color === 'red' ? RED_YARD_SPOTS[tokenId] : GREEN_YARD_SPOTS[tokenId];
    }
    if (step === 56) {
      return { r: 7, c: 7 }; // Center Goal
    }

    if (color === 'red') {
      if (step <= 50) {
        return MAIN_PATH[step];
      } else {
        // Red Home Corridor (step 51..55)
        const homeIdx = step - 51;
        return RED_HOME_PATH[homeIdx] || { r: 7, c: 7 };
      }
    } else {
      // Green color
      if (step <= 50) {
        // Green's start index on MAIN_PATH is 26
        const pathIdx = (26 + step) % 52;
        return MAIN_PATH[pathIdx];
      } else {
        // Green Home Corridor (step 51..55)
        const homeIdx = step - 51;
        return GREEN_HOME_PATH[homeIdx] || { r: 7, c: 7 };
      }
    }
  };

  // Helper to remove ticket from localStorage
  const removeMyQueueTicket = (pId: string) => {
    try {
      const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
      if (raw) {
        const list: QueueTicket[] = JSON.parse(raw);
        const filtered = list.filter(t => t.playerId !== pId);
        localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(filtered));
      }
    } catch (e) {
      // ignore
    }
  };

  // Setup Broadcast Channel & Polling for Real-time Real-Player Matchmaking
  useEffect(() => {
    let pollInterval: NodeJS.Timeout | null = null;

    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const channel = new BroadcastChannel(MATCH_CHANNEL_NAME);
        broadcastChannelRef.current = channel;

        channel.onmessage = (event) => {
          const data = event.data;
          if (!data) return;

          // If another real player is searching in the same tier
          if (data.type === 'MATCH_PAIR_INVITE' && gamePhase === 'matchmaking') {
            if (data.entryFee === entryFee && data.player?.playerId !== user.id) {
              // Confirm pairing with real player
              removeMyQueueTicket(user.id);
              removeMyQueueTicket(data.player.playerId);

              // Notify the other player that match is locked
              channel.postMessage({
                type: 'MATCH_PAIR_ACCEPTED',
                targetPlayerId: data.player.playerId,
                hostPlayer: {
                  id: user.id,
                  name: user.name,
                  avatar: '👑',
                  location: 'Dhaka',
                  winRate: '72%',
                  level: 30,
                },
                entryFee,
              });

              handleOpponentPaired({
                id: data.player.playerId,
                name: data.player.playerName,
                avatar: data.player.playerAvatar || '😎',
                color: 'green',
                isBot: false,
                score: 0,
                tokensHome: 0,
                ping: Math.floor(18 + Math.random() * 15),
                location: data.player.location || 'Chattogram',
                winRate: data.player.winRate || '70%',
                level: data.player.level || 25,
              });
            }
          } else if (data.type === 'MATCH_PAIR_ACCEPTED' && gamePhase === 'matchmaking') {
            if (data.targetPlayerId === user.id) {
              removeMyQueueTicket(user.id);
              handleOpponentPaired({
                id: data.hostPlayer.id,
                name: data.hostPlayer.name,
                avatar: data.hostPlayer.avatar || '👑',
                color: 'green',
                isBot: false,
                score: 0,
                tokensHome: 0,
                ping: Math.floor(18 + Math.random() * 15),
                location: data.hostPlayer.location || 'Dhaka',
                winRate: data.hostPlayer.winRate || '75%',
                level: data.hostPlayer.level || 30,
              });
            }
          }
        };
      }
    } catch (err) {
      console.warn('BroadcastChannel not supported');
    }

    // Polling active tickets in localStorage for cross-tab or cross-session matching
    if (gamePhase === 'matchmaking') {
      pollInterval = setInterval(() => {
        try {
          const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
          if (raw) {
            const list: QueueTicket[] = JSON.parse(raw);
            const now = Date.now();
            // Filter tickets within last 60 seconds matching entryFee and different player
            const matchedTicket = list.find(t => 
              t.playerId !== user.id && 
              t.entryFee === entryFee && 
              (now - t.timestamp) < 60000
            );

            if (matchedTicket) {
              removeMyQueueTicket(user.id);
              removeMyQueueTicket(matchedTicket.playerId);

              handleOpponentPaired({
                id: matchedTicket.playerId,
                name: matchedTicket.playerName,
                avatar: matchedTicket.playerAvatar || '😎',
                color: 'green',
                isBot: false,
                score: 0,
                tokensHome: 0,
                ping: Math.floor(20 + Math.random() * 15),
                location: matchedTicket.location || 'Sylhet',
                winRate: matchedTicket.winRate || '68%',
                level: matchedTicket.level || 20,
              });
            }
          }
        } catch (e) {
          // ignore
        }
      }, 1500);
    }

    return () => {
      if (pollInterval) clearInterval(pollInterval);
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.close();
      }
    };
  }, [gamePhase, entryFee, user.id]);

  // Start Searching / Charging Handler from Lobby
  const handleStartLobbyMatch = () => {
    const feeToCharge = customFee ? Number(customFee) : entryFee;
    if (isNaN(feeToCharge) || feeToCharge < 10) {
      setError('এন্ট্রি ফি সর্বনিম্ন ৳১০ টাকা হতে হবে।');
      return;
    }

    if (user.gamingBalance < feeToCharge) {
      setError('আপনার পর্যাপ্ত গেমিং ব্যালেন্স নেই! দয়া করে একাউন্টে টাকা রিচার্জ করুন।');
      return;
    }

    setError('');
    const prizeToWin = calculateWinPrize(feeToCharge);
    const modeTitle = `${gameMode === 'quick' ? 'Quick 2-Token' : 'Classic 4-Token'} (৳${feeToCharge} ➔ ৳${prizeToWin})`;
    const res = startLiveLudoMatch(feeToCharge, modeTitle);

    if (!res.success) {
      setError(res.message);
      return;
    }

    const currentMatchId = res.matchId || `live_${Date.now()}`;
    setMatchId(currentMatchId);
    setEntryFee(feeToCharge);
    initTokens(gameMode);

    if (opponentType === 'online') {
      // 1. Enter Matchmaking Queue (Searching for real players ONLY)
      setGamePhase('matchmaking');
      setSearchSeconds(0);

      // Start search timer
      if (searchTimerRef.current) clearInterval(searchTimerRef.current);
      searchTimerRef.current = setInterval(() => {
        setSearchSeconds(prev => prev + 1);
      }, 1000);

      // 2. Register ticket in localStorage and broadcast channel
      const myTicket: QueueTicket = {
        id: `ticket_${Date.now()}`,
        playerId: user.id,
        playerName: user.name,
        playerAvatar: '👑',
        location: 'Dhaka',
        winRate: '72%',
        level: 30,
        entryFee: feeToCharge,
        mode: gameMode,
        timestamp: Date.now(),
      };

      try {
        const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
        const list: QueueTicket[] = raw ? JSON.parse(raw) : [];
        const cleaned = list.filter(t => t.playerId !== user.id && (Date.now() - t.timestamp) < 60000);
        cleaned.push(myTicket);
        localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(cleaned));
      } catch (e) {
        // ignore
      }

      try {
        if (broadcastChannelRef.current) {
          broadcastChannelRef.current.postMessage({
            type: 'MATCH_PAIR_INVITE',
            entryFee: feeToCharge,
            mode: gameMode,
            player: myTicket,
            matchId: currentMatchId,
          });
        }
      } catch (e) {
        // ignore
      }

      // NOTE: Strictly stays in searching state until a real player is found or user cancels!
      // No automatic bot fallback!

    } else if (opponentType === 'bot') {
      // Dedicated AI Practice Mode
      const bot = BOT_OPPONENTS[Math.floor(Math.random() * BOT_OPPONENTS.length)];
      setOpponent({
        id: `bot_${bot.name.toLowerCase().replace(/\s+/g, '_')}`,
        name: `${bot.name} (AI Bot)`,
        avatar: bot.avatar,
        color: 'green',
        isBot: true,
        score: 0,
        tokensHome: 0,
        ping: bot.ping,
        location: bot.location,
        winRate: bot.winRate,
        level: bot.level,
      });
      startActualGame();
    } else {
      // Pass & Play Mode (2 players on single device)
      setOpponent({
        id: 'player_2',
        name: 'Player 2 (Green)',
        avatar: '👤',
        color: 'green',
        isBot: false,
        score: 0,
        tokensHome: 0,
        location: 'Local Device',
        winRate: '50%',
        level: 1,
      });
      startActualGame();
    }
  };

  // Called when an opponent is successfully paired
  const handleOpponentPaired = (opp: LivePlayer) => {
    if (searchTimerRef.current) clearInterval(searchTimerRef.current);
    removeMyQueueTicket(user.id);
    setOpponent(opp);
    setGamePhase('match_found');
    ludoAudio.playTurnAlert();

    // 3-2-1 Countdown before launching board
    setStartCountdown(3);
    const countInterval = setInterval(() => {
      setStartCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countInterval);
          startActualGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Switch to Practice Bot while searching
  const handleSwitchToBotMatch = () => {
    if (searchTimerRef.current) clearInterval(searchTimerRef.current);
    removeMyQueueTicket(user.id);
    const bot = BOT_OPPONENTS[Math.floor(Math.random() * BOT_OPPONENTS.length)];
    handleOpponentPaired({
      id: `bot_${bot.name.toLowerCase().replace(/\s+/g, '_')}`,
      name: `${bot.name} (AI Bot)`,
      avatar: bot.avatar,
      color: 'green',
      isBot: true,
      score: 0,
      tokensHome: 0,
      ping: bot.ping,
      location: bot.location,
      winRate: bot.winRate,
      level: bot.level,
    });
  };

  // Cancel Matchmaking Search and Refund 100%
  const handleCancelSearch = () => {
    if (searchTimerRef.current) clearInterval(searchTimerRef.current);
    removeMyQueueTicket(user.id);
    refundLiveLudoMatch(matchId, entryFee, 'Search Cancelled by Player');
    setGamePhase('lobby');
  };

  // Begin active gameplay
  const startActualGame = () => {
    setGamePhase('playing');
    setCurrentTurn('red');
    setDiceValue(null);
    setCanRoll(true);
    setMovableTokenIds([]);
    setWinner(null);
    setHasBonusRoll(false);
    setTurnMessage('আপনার চাল! ডাইস রোল করুন 🎲');
    resetTurnTimer();
    ludoAudio.playTurnAlert();
  };

  // Reset 15s turn countdown timer
  const resetTurnTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setTurnTimer(15);

    timerRef.current = setInterval(() => {
      setTurnTimer(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleTurnTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Turn Timeout (Auto Pass)
  const handleTurnTimeout = () => {
    if (gamePhase !== 'playing' || isMovingToken) return;
    switchTurn();
  };

  // Roll Dice Handler
  const handleRollDice = () => {
    if (!canRoll || isRolling || isMovingToken) return;

    setCanRoll(false);
    setIsRolling(true);
    ludoAudio.playDiceRoll();

    // Roll animation sequence
    let count = 0;
    const interval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 6) {
        clearInterval(interval);
      }
    }, 70);

    setTimeout(() => {
      // Final roll result
      const finalRoll = Math.floor(Math.random() * 6) + 1;
      setDiceValue(finalRoll);
      setIsRolling(false);

      if (finalRoll === 6) {
        ludoAudio.playSixRoll();
      }

      // Check movable tokens for current player
      evaluateMovableTokens(finalRoll, currentTurn);
    }, 600);
  };

  // Check which tokens can legally move with the rolled value
  const evaluateMovableTokens = (roll: number, turn: 'red' | 'green') => {
    const tokens = turn === 'red' ? redTokens : greenTokens;
    const movables: number[] = [];

    tokens.forEach((token) => {
      // 1. If in Yard, need 6 to unlock
      if (token.step === -1) {
        if (roll === 6) {
          movables.push(token.id);
        }
      } 
      // 2. If already on path
      else if (token.step >= 0 && token.step < 56) {
        // Can only move if target doesn't exceed 56
        if (token.step + roll <= 56) {
          movables.push(token.id);
        }
      }
    });

    setMovableTokenIds(movables);

    // If no moves possible, pass turn after brief pause
    if (movables.length === 0) {
      setTurnMessage(roll === 6 ? 'কোনো চাল নেই!' : 'চাল সম্ভব নয়! পরের জনের পালা');
      setTimeout(() => {
        switchTurn();
      }, 1200);
      return;
    }

    // HUMAN TURN (Red or local Green player): NO AUTO-MOVE! Player must click/tap the highlighted token!
    if (turn === 'red' || (turn === 'green' && !opponent?.isBot)) {
      setTurnMessage(
        roll === 6 
          ? '🎲 ৬ পড়েছে! চাল দিতে উজ্জ্বল গুটিতে ট্যাপ/ক্লিক করুন 👆' 
          : 'গুটি চালার জন্য উজ্জ্বল গুটিতে ট্যাপ/ক্লিক করুন 👆'
      );
      // Wait for player to physically tap/click on the glowing token
    } 
    // BOT TURN (Green AI): Selects after realistic pause
    else if (turn === 'green' && opponent?.isBot) {
      setTurnMessage(`${opponent?.name} গুটি সিলেক্ট করছে... ⏳`);
      setTimeout(() => {
        const chosenId = chooseBestBotToken(tokens, movables, roll);
        const chosenToken = tokens.find(t => t.id === chosenId)!;
        executeTokenMove(chosenToken, roll);
      }, 800);
    }
  };

  // AI strategy to choose best token for bot
  const chooseBestBotToken = (tokens: LudoToken[], movableIds: number[], roll: number): number => {
    const candidateTokens = tokens.filter(t => movableIds.includes(t.id));

    // Priority 1: Tokens in yard if roll is 6
    if (roll === 6) {
      const inYard = candidateTokens.find(t => t.step === -1);
      if (inYard && Math.random() > 0.3) return inYard.id;
    }

    // Priority 2: Can capture an opponent token
    for (const t of candidateTokens) {
      if (t.step >= 0) {
        const nextStep = t.step + roll;
        if (nextStep <= 50) {
          const targetCoord = getCoordinatesForStep('green', nextStep, t.id);
          const canCapture = redTokens.some(rt => 
            rt.step >= 0 && rt.step <= 50 && 
            !isSafeCoordinate(targetCoord) &&
            rt.position.r === targetCoord.r && 
            rt.position.c === targetCoord.c
          );
          if (canCapture) return t.id;
        }
      }
    }

    // Priority 3: Tokens closest to home
    const sorted = [...candidateTokens].sort((a, b) => b.step - a.step);
    return sorted[0].id;
  };

  // Execute Step-by-Step Smooth Movement
  const executeTokenMove = async (token: LudoToken, roll: number) => {
    setIsMovingToken(true);
    setMovableTokenIds([]);
    const isRed = token.color === 'red';

    let currentStep = token.step;
    let targetStep = currentStep;
    let bonusTurn = roll === 6;

    // A. Unlocking from Yard
    if (currentStep === -1) {
      targetStep = 0;
      const startCoord = isRed ? { r: 6, c: 1 } : { r: 8, c: 13 };
      updateTokenPosition(token.color, token.id, 0, startCoord, false);
      ludoAudio.playStep();
      await new Promise(r => setTimeout(r, 250));
    } 
    // B. Moving across board step by step
    else {
      targetStep = currentStep + roll;
      for (let s = currentStep + 1; s <= targetStep; s++) {
        const stepCoord = getCoordinatesForStep(token.color, s, token.id);
        updateTokenPosition(token.color, token.id, s, stepCoord, s === 56);
        ludoAudio.playStep();
        await new Promise(r => setTimeout(r, 160));
      }
    }

    // Check if Reached Home Center Goal (step 56)
    if (targetStep === 56) {
      ludoAudio.playHomeGoal();
      bonusTurn = true; // extra roll on reaching home
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
    }

    // Check Token Capture on Main Path (0..50)
    if (targetStep >= 0 && targetStep <= 50) {
      const finalCoord = getCoordinatesForStep(token.color, targetStep, token.id);
      const isSafe = isSafeCoordinate(finalCoord);

      if (!isSafe) {
        const opponentTokens = isRed ? greenTokens : redTokens;
        const captured = opponentTokens.find(ot => 
          ot.step >= 0 && ot.step <= 50 && 
          ot.position.r === finalCoord.r && 
          ot.position.c === finalCoord.c
        );

        if (captured) {
          // Token Captured!
          ludoAudio.playCapture();
          bonusTurn = true; // Bonus roll for capturing!
          setTurnMessage(isRed ? `💥 আপনি ${opponent?.name} এর গুটি কেটেছেন! বোনাস চাল!` : `💥 ${opponent?.name} আপনার গুটি কেটেছে!`);
          
          // Send captured token back to Yard
          const yardSpot = isRed ? GREEN_YARD_SPOTS[captured.id] : RED_YARD_SPOTS[captured.id];
          updateTokenPosition(captured.color, captured.id, -1, yardSpot, false);
          await new Promise(r => setTimeout(r, 400));
        }
      }
    }

    // Check Overall Match Victory
    const updatedMyTokens = (isRed ? redTokens : greenTokens).map(t => 
      t.id === token.id ? { ...t, step: targetStep, isHome: targetStep === 56 } : t
    );
    const homeCount = updatedMyTokens.filter(t => t.isHome).length;

    if (homeCount >= targetWinTokens) {
      handleMatchVictory(token.color);
      setIsMovingToken(false);
      return;
    }

    setIsMovingToken(false);

    // If rolled 6 or captured, active player rolls again
    if (bonusTurn) {
      setHasBonusRoll(true);
      setCanRoll(true);
      setDiceValue(null);
      setTurnMessage(isRed ? '🎉 বোনাস চাল! আবার ডাইস রোল করুন' : `🎉 ${opponent?.name} বোনাস চাল পেয়েছে!`);
      resetTurnTimer();

      if (!isRed && opponent?.isBot) {
        triggerBotTurn();
      }
    } else {
      switchTurn();
    }
  };

  // Check if cell is a safe star
  const isSafeCoordinate = (coord: CellCoord) => {
    return (
      (coord.r === 6 && coord.c === 1) ||
      (coord.r === 8 && coord.c === 13) ||
      (coord.r === 2 && coord.c === 6) ||
      (coord.r === 1 && coord.c === 8) ||
      (coord.r === 6 && coord.c === 12) ||
      (coord.r === 12 && coord.c === 8) ||
      (coord.r === 13 && coord.c === 6) ||
      (coord.r === 8 && coord.c === 2)
    );
  };

  // Helper to update state for a specific token
  const updateTokenPosition = (
    color: 'red' | 'green', 
    id: number, 
    step: number, 
    position: CellCoord, 
    isHome: boolean
  ) => {
    if (color === 'red') {
      setRedTokens(prev => prev.map(t => t.id === id ? { ...t, step, position, isHome } : t));
    } else {
      setGreenTokens(prev => prev.map(t => t.id === id ? { ...t, step, position, isHome } : t));
    }
  };

  // Switch Turn to the other player
  const switchTurn = () => {
    const nextTurn = currentTurn === 'red' ? 'green' : 'red';
    setCurrentTurn(nextTurn);
    setDiceValue(null);
    setMovableTokenIds([]);
    setHasBonusRoll(false);
    resetTurnTimer();

    if (nextTurn === 'red') {
      setCanRoll(true);
      setTurnMessage('আপনার চাল! ডাইস রোল করুন 🎲');
      ludoAudio.playTurnAlert();
    } else {
      setCanRoll(false);
      setTurnMessage(`${opponent?.name || 'Player 2'} এর চাল... ⏳`);

      if (opponent?.isBot) {
        triggerBotTurn();
      } else {
        // Pass and play player 2
        setCanRoll(true);
      }
    }
  };

  // Bot Turn Trigger
  const triggerBotTurn = () => {
    if (botTurnTimeoutRef.current) clearTimeout(botTurnTimeoutRef.current);

    botTurnTimeoutRef.current = setTimeout(() => {
      if (gamePhase !== 'playing') return;

      setIsRolling(true);
      ludoAudio.playDiceRoll();

      let count = 0;
      const interval = setInterval(() => {
        setDiceValue(Math.floor(Math.random() * 6) + 1);
        count++;
        if (count > 6) clearInterval(interval);
      }, 70);

      setTimeout(() => {
        const botRoll = Math.floor(Math.random() * 6) + 1;
        setDiceValue(botRoll);
        setIsRolling(false);

        if (botRoll === 6) ludoAudio.playSixRoll();

        evaluateMovableTokens(botRoll, 'green');
      }, 600);
    }, 1000);
  };

  // Handle User Token Click
  const handleTokenClick = (token: LudoToken) => {
    if (currentTurn !== token.color || !movableTokenIds.includes(token.id) || isMovingToken) return;
    if (diceValue === null) return;

    executeTokenMove(token, diceValue);
  };

  // Match Victory Conclusion
  const handleMatchVictory = (winColor: 'red' | 'green') => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (botTurnTimeoutRef.current) clearTimeout(botTurnTimeoutRef.current);

    const userWon = winColor === 'red';
    setWinner(winColor);
    setGamePhase('gameover');

    const modeTitle = `${gameMode === 'quick' ? 'Quick 2-Token' : 'Classic 4-Token'}`;
    const oppName = opponent?.name || 'Opponent';

    finishLiveLudoMatch(matchId, entryFee, userWon, currentPrize, oppName, modeTitle);

    if (userWon) {
      ludoAudio.playWin();
      confetti({ particleCount: 120, spread: 90, origin: { y: 0.45 } });
    }
  };

  // Surrender / Exit Match
  const handleSurrender = () => {
    setShowSurrenderModal(false);
    if (timerRef.current) clearInterval(timerRef.current);
    if (botTurnTimeoutRef.current) clearTimeout(botTurnTimeoutRef.current);

    handleMatchVictory('green');
  };

  // Send In-Game Emoji / Chat reaction
  const handleSendReaction = (emoji: string, text: string) => {
    setShowEmojiPicker(false);
    setFloatingReaction({ sender: 'red', emoji, text });
    setTimeout(() => setFloatingReaction(null), 3000);

    // Bot occasional funny response
    if (opponent?.isBot && Math.random() > 0.4) {
      setTimeout(() => {
        const botReactions = CHAT_REACTIONS;
        const rand = botReactions[Math.floor(Math.random() * botReactions.length)];
        setFloatingReaction({ sender: 'green', emoji: rand.emoji, text: rand.text });
        setTimeout(() => setFloatingReaction(null), 3000);
      }, 1500);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (botTurnTimeoutRef.current) clearTimeout(botTurnTimeoutRef.current);
      if (searchTimerRef.current) clearInterval(searchTimerRef.current);
    };
  }, []);

  const redHomeCount = redTokens.filter(t => t.isHome).length;
  const greenHomeCount = greenTokens.filter(t => t.isHome).length;

  return (
    <div className="pb-24 pt-1 px-2.5 max-w-md mx-auto space-y-3.5 text-white min-h-screen">
      
      {/* ================= TOP STICKY BAR ================= */}
      <div className="sticky top-14 z-30 bg-[#0d1222]/95 backdrop-blur-md py-2 px-1 flex items-center justify-between border-b border-indigo-950/70">
        <div className="flex items-center gap-2">
          <button
            id="live-ludo-back-btn"
            onClick={() => {
              if (gamePhase === 'playing') {
                setShowSurrenderModal(true);
              } else if (gamePhase === 'matchmaking') {
                handleCancelSearch();
              } else {
                setCurrentTab('home');
              }
            }}
            className="w-8 h-8 rounded-full bg-indigo-950/80 hover:bg-indigo-900 text-slate-300 flex items-center justify-center border border-indigo-800/40"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-extrabold text-white tracking-wide flex items-center gap-1.5">
              <span>1v1 Live Ludo</span>
              <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-[9.5px] px-1.5 py-0.2 rounded font-bold uppercase flex items-center gap-0.5">
                <Flame className="w-2.5 h-2.5 fill-current" /> LIVE
              </span>
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Mute Button */}
          <button
            id="ludo-sound-toggle-btn"
            onClick={toggleMute}
            className="w-8 h-8 rounded-full bg-[#151c38] text-slate-300 hover:text-amber-400 flex items-center justify-center border border-indigo-800/50"
            title={isMuted ? 'সাউন্ড আনমিউট করুন' : 'সাউন্ড মিউট করুন'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Gaming Balance */}
          <div className="flex items-center gap-1 bg-[#151c38] px-2.5 py-1 rounded-lg border border-indigo-800/50 text-xs font-bold text-amber-400">
            <span>৳</span>
            <span className="font-mono">{user.gamingBalance.toFixed(0)}</span>
          </div>
        </div>
      </div>

      {/* ================= 1. LOBBY PHASE ================= */}
      {gamePhase === 'lobby' && (
        <div className="space-y-4 animate-fade-in">
          {/* Hero Banner */}
          <div className="bg-gradient-to-r from-red-900/50 via-[#192248] to-emerald-900/50 border-2 border-amber-500/40 rounded-3xl p-5 shadow-2xl relative overflow-hidden text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-amber-500 via-red-500 to-emerald-500 p-0.5 shadow-lg mb-2 flex items-center justify-center">
              <div className="w-full h-full bg-[#0d1222] rounded-[14px] flex items-center justify-center text-2xl">
                🎲
              </div>
            </div>
            <h3 className="text-lg font-black text-white">
              হেড টু হেড লাইভ লুডু (1v1)
            </h3>
            <p className="text-xs text-amber-300/90 font-medium mt-0.5">
              এন্ট্রি ফি দিয়ে সরাসরি অপনেন্ট খুঁজুন এবং জিতলেই নগদ টাকা ব্যালেন্সে নিন!
            </p>

            <div className="mt-3 inline-flex items-center gap-2 bg-[#0e1428]/90 px-3.5 py-1.5 rounded-full border border-amber-400/30 text-xs font-black text-amber-400 shadow-md">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>ধারা: এন্ট্রি ৳২০ ➔ জিতলে ৳৩০ (ধারাবাহিক উইন)</span>
            </div>
          </div>

          {/* Game Mode Selector (Quick Match 2 Tokens ONLY - Red options removed) */}
          <div className="bg-[#0f162e] border border-indigo-900/80 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">
                ১. গেম মোড:
              </label>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                অফিসিয়াল মোড
              </span>
            </div>
            
            <div className="p-3.5 rounded-xl border border-amber-400/80 bg-gradient-to-r from-amber-500/20 via-red-500/15 to-indigo-950 text-left ring-1 ring-amber-400/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black flex items-center gap-1.5 text-amber-400">
                  <Zap className="w-4 h-4 fill-amber-400" /> Quick Match (২ গুটি)
                </span>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                  ২ গুটি হোমে নিলেই উইন
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                দ্রুত ও বাস্তবসম্মত লাইভ ম্যাচ (৩-৫ মিনিট)। প্রথম ২টি গুটি সফলভাবে হোমে পৌঁছালেই বিজয়!
              </p>
            </div>
          </div>

          {/* Opponent Matching Type (Real Live 1v1 Online ONLY - Red options removed) */}
          <div className="bg-[#0f162e] border border-indigo-900/80 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">
                ২. ম্যাচ টাইপ:
              </label>
              <span className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                লাইভ সার্ভার অ্যাক্টিভ
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-blue-500/70 bg-gradient-to-r from-indigo-900/60 via-blue-900/40 to-[#0e1428] text-left ring-1 ring-blue-400/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-400">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-white">রিয়েল লাইভ (1v1 Online)</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-extrabold px-1.5 py-0.2 rounded">
                      Real Player
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    রিয়েল অনলাইন প্লেয়ারের সাথে লাইভ ম্যাচ। লাইভ প্লেয়ার থাকলে সাথে সাথে ম্যাচ শুরু হবে।
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Entry Fee Selector (৳২০ থেকে ৳৫০ পর্যন্ত: প্রতি ১০০ তে ২০ টাকা লাভ) */}
          <div className="bg-[#0f162e] border border-indigo-900/80 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-200 uppercase tracking-wider">
                ৩. এন্ট্রি ফি সিলেক্ট করুন (৳২০ - ৳৫০):
              </label>
              <div className="text-xs font-extrabold text-emerald-400 flex items-center gap-1">
                <span>উইনিং প্রাইজ:</span>
                <span className="font-mono text-amber-300 text-sm font-black">৳{currentPrize}</span>
              </div>
            </div>

            {/* Entry Fee Grid (20, 25, 30, 35, 40, 45, 50) */}
            <div className="grid grid-cols-4 gap-2">
              {entryFeeOptions.map((fee) => {
                const win = calculateWinPrize(fee);
                const isSelected = entryFee === fee && !customFee;
                return (
                  <button
                    key={fee}
                    id={`fee-opt-${fee}`}
                    type="button"
                    onClick={() => {
                      setEntryFee(fee);
                      setCustomFee('');
                    }}
                    className={`py-2 px-1 rounded-xl text-center border transition-all relative overflow-hidden ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 border-amber-300 text-slate-950 font-black shadow-lg scale-105 ring-2 ring-amber-400/50'
                        : 'bg-[#141b36] border-indigo-950 text-slate-200 hover:text-white font-bold text-xs'
                    }`}
                  >
                    {fee === 20 && (
                      <span className="absolute top-0 right-0 bg-red-500 text-[7px] text-white px-1 font-bold rounded-bl">
                        HOT
                      </span>
                    )}
                    <div className="text-xs font-mono font-black">৳{fee}</div>
                    <div className={`text-[9px] ${isSelected ? 'text-slate-950 font-black' : 'text-emerald-400 font-bold'}`}>
                      উইন ৳{win}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom fee option */}
            <div className="pt-1">
              <div className="relative">
                <input
                  type="number"
                  min={20}
                  max={50}
                  placeholder="অন্যান্য এন্ট্রি ফি (যেমন: 22, 28, 48 টাকা)"
                  value={customFee}
                  onChange={(e) => {
                    const val = e.target.value;
                    setCustomFee(val);
                    if (val) {
                      const num = Number(val);
                      if (num >= 20 && num <= 50) {
                        setEntryFee(num);
                        setError('');
                      } else if (num > 50) {
                        setError('সর্বোচ্চ এন্ট্রি ফি ৫০ টাকা');
                      } else if (num < 20) {
                        setError('সর্বনিম্ন এন্ট্রি ফি ২০ টাকা');
                      }
                    }
                  }}
                  className="w-full bg-[#0a0e1c] border border-indigo-900 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400 font-mono"
                />
                <span className="absolute right-3 top-2 text-xs text-slate-400 font-bold">
                  {customFee ? `উইন ৳${calculateWinPrize(Number(customFee) || 0)}` : '৳ BDT (২০-৫০)'}
                </span>
              </div>
            </div>

            <div className="bg-indigo-950/60 rounded-xl p-2 border border-indigo-900/50 flex items-center justify-between text-[11px] text-slate-300">
              <span className="text-amber-400 font-semibold">💡 প্রাইজ হিসাব:</span>
              <span>প্রতি ১০০ টাকায় ২০ টাকা লাভ (১.৬ গুণ উইনিং)</span>
            </div>
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-300 p-3 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Start Matchmaking Button */}
          <button
            id="start-live-ludo-match-btn"
            type="button"
            onClick={handleStartLobbyMatch}
            className="w-full py-4 bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>লাইভ অপনেন্ট খুঁজুন ও খেলা শুরু করুন (এন্ট্রি ৳{customFee ? customFee : entryFee} ➔ উইন ৳{currentPrize})</span>
          </button>

          {user.gamingBalance < (customFee ? Number(customFee) : entryFee) && (
            <button
              id="live-ludo-add-money-btn"
              onClick={() => openModal('add_money')}
              className="w-full py-2.5 bg-indigo-900/80 hover:bg-indigo-800 text-amber-300 text-xs font-bold rounded-xl border border-indigo-700/60 transition-colors flex items-center justify-center gap-1.5"
            >
              <span>+ টাকা রিচার্জ করুন (Add Money via bKash/Nagad)</span>
            </button>
          )}

          {/* Quick Rules Preview */}
          <div className="bg-[#0b1022] p-3.5 rounded-2xl border border-indigo-950 text-xs text-slate-400 space-y-1.5 leading-relaxed">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>লাইভ লুডুর নিয়ম ও প্রাইজ সিস্টেম:</span>
            </div>
            <p>• এন্ট্রি ফি দিয়ে সার্চ দিলে অপর প্রান্তে একই সময়ে সার্চ করা রিয়েল প্লেয়ারের সাথে ইনস্ট্যান্ট ম্যাচ শুরু হবে।</p>
            <p>• লাইভ কোনো প্লেয়ার না থাকলে সার্চিং অবস্থায় থাকবে, যে কোনো সময় ক্যানসেল করে সম্পূর্ণ রিফান্ড নেওয়া যাবে।</p>
            <p>• এন্ট্রি ফি ২০ টাকা ➔ বিজয়ী পাবে ৩২ টাকা (প্রতি ১০০ টাকায় ২০ টাকা প্লাটফর্ম চার্জ)।</p>
            <p>• ডাইসে ৬ পড়লে গুটি ঘর থেকে বের হবে এবং আরেকটি বোনাস চাল পাবেন।</p>
            <p>• স্টার (★) চিহ্নিত ঘর নিরাপদ। অপনেন্টের গুটি কাটলে বোনাস চাল পাবেন।</p>
            <p>• ২টি গুটি আগে হোমে নিয়ে গেলেই সরাসরি উইনিং ব্যালেন্সে টাকা যোগ হবে।</p>
          </div>
        </div>
      )}

      {/* ================= 2. MATCHMAKING SEARCHING PHASE ================= */}
      {gamePhase === 'matchmaking' && (
        <div className="py-10 px-4 text-center space-y-6 animate-fade-in">
          
          {/* Radar Waves Animation */}
          <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-emerald-500/15 animate-ping duration-1000" />
            <div className="absolute inset-3 rounded-full bg-amber-500/20 animate-pulse duration-700" />
            <div className="absolute inset-6 rounded-full bg-indigo-500/30 animate-ping duration-1000" />
            
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-600 via-teal-700 to-indigo-800 flex items-center justify-center text-3xl shadow-2xl border-2 border-emerald-400 z-10">
              🎲
            </div>
          </div>

          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-[#141d3b] px-3.5 py-1.5 rounded-full border border-emerald-500/40 text-xs font-black text-emerald-400">
              <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>৳{entryFee} এন্ট্রি ফি লাইভ পুল (Searching...)</span>
            </div>

            <h3 className="text-lg font-black text-white flex items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
              <span>অপর প্রান্তে প্লেয়ার খোঁজা হচ্ছে ({searchSeconds}s)</span>
            </h3>

            <p className="text-xs text-slate-300 max-w-xs mx-auto">
              একই সময়ে অপর প্রান্তে ৳{entryFee} এন্ট্রি ফি দিয়ে কেউ সার্চ করলেই দুজন এক সাথে যুক্ত হয়ে খেলা শুরু হবে।
            </p>
          </div>

          {/* Active Seeker Pool Info */}
          <div className="bg-[#101733] border border-indigo-900 p-3.5 rounded-2xl max-w-xs mx-auto space-y-2 shadow-inner">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">আপনার এন্ট্রি ফি:</span>
              <span className="text-amber-400 font-mono font-bold">৳{entryFee}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">উইনিং প্রাইজ মানি:</span>
              <span className="text-emerald-400 font-mono font-bold">৳{currentPrize}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">অনলাইন খেলোয়াড়:</span>
              <span className="text-emerald-300 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                ১২ জন সক্রিয়
              </span>
            </div>
          </div>

          {/* Search Action Buttons */}
          <div className="flex flex-col items-center gap-2.5 max-w-xs mx-auto">
            <button
              id="switch-to-bot-btn"
              type="button"
              onClick={handleSwitchToBotMatch}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-900/60 to-indigo-900/60 hover:from-purple-800 hover:to-indigo-800 text-amber-300 text-xs font-bold border border-purple-500/40 active:scale-95 transition-all shadow-md flex items-center justify-center gap-1.5"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>অপেক্ষা না করে বটের সাথে প্র্যাকটিস করুন</span>
            </button>

            <button
              id="cancel-search-btn"
              type="button"
              onClick={handleCancelSearch}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-rose-300 text-xs font-bold border border-rose-500/40 active:scale-95 transition-all shadow-md flex items-center justify-center gap-1.5"
            >
              <XCircle className="w-4 h-4 text-rose-400" />
              <span>সার্চ বাতিল ও ১০০% রিফান্ড</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= 2.5 MATCH FOUND / FACE-OFF STAGE ================= */}
      {gamePhase === 'match_found' && opponent && (
        <div className="py-8 px-3 text-center space-y-5 animate-fade-in">
          
          <div className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-400/50 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider animate-bounce">
            <CheckCircle2 className="w-4 h-4" />
            <span>✓ প্লেয়ার পাওয়া গেছে! ম্যাচ প্রস্তুত</span>
          </div>

          {/* 1v1 Face-Off Cards */}
          <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto relative pt-3">
            
            {/* Center VS Badge */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 via-red-500 to-amber-600 border-2 border-white shadow-2xl flex items-center justify-center text-slate-950 font-black text-sm">
              VS
            </div>

            {/* Left: You (Red) */}
            <div className="bg-[#241323] border-2 border-red-500/60 rounded-2xl p-3.5 text-center space-y-2 shadow-xl">
              <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-rose-600 to-red-800 border-2 border-red-400 flex items-center justify-center text-2xl shadow-md">
                👑
              </div>
              <div>
                <div className="text-xs font-black text-white truncate">{user.name}</div>
                <div className="text-[10px] text-red-400 font-bold">Red Token (You)</div>
                <div className="text-[10px] text-slate-300 mt-1">ফি: ৳{entryFee}</div>
              </div>
            </div>

            {/* Right: Opponent (Green) */}
            <div className="bg-[#12222d] border-2 border-emerald-500/60 rounded-2xl p-3.5 text-center space-y-2 shadow-xl">
              <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-emerald-600 to-teal-800 border-2 border-emerald-400 flex items-center justify-center text-2xl shadow-md">
                {opponent.avatar}
              </div>
              <div>
                <div className="text-xs font-black text-white truncate">{opponent.name}</div>
                <div className="text-[10px] text-emerald-400 font-bold">Green ({opponent.location || 'Dhaka'})</div>
                <div className="text-[10px] text-slate-300 mt-1">ফি: ৳{entryFee} • {opponent.winRate || '70%'} Win</div>
              </div>
            </div>
          </div>

          {/* Prize Summary */}
          <div className="bg-gradient-to-r from-amber-950/60 via-[#182148] to-emerald-950/60 border border-amber-400/40 p-3 rounded-2xl max-w-sm mx-auto shadow-md">
            <div className="text-xs font-bold text-slate-300">
              উভয়ে ৳{entryFee} দিয়ে যুক্ত হয়েছেন • বিজয়ী পাবেন <strong className="text-amber-400 font-mono text-sm">৳{currentPrize}</strong>
            </div>
          </div>

          {/* Countdown timer to start */}
          <div className="pt-2">
            <div className="text-3xl font-black text-amber-400 animate-pulse font-mono">
              খেলা শুরু হচ্ছে: {startCountdown}
            </div>
          </div>
        </div>
      )}

      {/* ================= 3. ACTIVE GAMEPLAY PHASE ================= */}
      {gamePhase === 'playing' && (
        <div className="space-y-3 animate-fade-in relative">
          
          {/* Floating In-Game Reaction Bubble */}
          {floatingReaction && (
            <div
              className={`absolute z-50 px-3 py-1.5 rounded-2xl shadow-2xl border text-xs font-black animate-bounce flex items-center gap-1.5 backdrop-blur-md ${
                floatingReaction.sender === 'red'
                  ? 'bottom-24 left-6 bg-red-600/90 border-white text-white'
                  : 'top-20 right-6 bg-emerald-600/90 border-white text-white'
              }`}
            >
              <span className="text-base">{floatingReaction.emoji}</span>
              <span>{floatingReaction.text}</span>
            </div>
          )}

          {/* Opponent Bar (Top - Green) */}
          <div className={`p-2.5 rounded-2xl border transition-all flex items-center justify-between ${
            currentTurn === 'green'
              ? 'bg-[#152342] border-emerald-400 ring-2 ring-emerald-400/40 shadow-lg shadow-emerald-500/10'
              : 'bg-[#0f152d] border-indigo-950/80 opacity-80'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-800 border-2 border-emerald-400 flex items-center justify-center text-lg shadow-md">
                  {opponent?.avatar || '👤'}
                </div>
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#0f152d]" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white truncate max-w-[110px]">
                    {opponent?.name || 'Opponent'}
                  </span>
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1 py-0.2 rounded font-mono font-bold">
                    Green
                  </span>
                </div>
                <div className="text-[10.5px] text-slate-300 font-medium">
                  হোম গুটি: <strong className="text-emerald-400 font-mono">{greenHomeCount}/{targetWinTokens}</strong>
                </div>
              </div>
            </div>

            {/* Opponent Turn Timer */}
            {currentTurn === 'green' && (
              <div className="flex items-center gap-1.5 bg-emerald-950/80 px-2.5 py-1 rounded-xl border border-emerald-500/40">
                <Clock className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
                <span className="text-xs font-mono font-black text-emerald-300">{turnTimer}s</span>
              </div>
            )}
          </div>

          {/* Center Stage: LUDO BOARD */}
          <div className="relative py-1">
            <LudoBoardView
              redTokens={redTokens}
              greenTokens={greenTokens}
              currentTurn={currentTurn}
              movableTokenIds={movableTokenIds}
              onTokenClick={handleTokenClick}
              isMoving={isMovingToken}
              diceValue={diceValue}
              mode={gameMode}
            />
          </div>

          {/* User Bar (Bottom - Red) */}
          <div className={`p-2.5 rounded-2xl border transition-all flex items-center justify-between ${
            currentTurn === 'red'
              ? 'bg-[#2a1728] border-red-400 ring-2 ring-red-400/40 shadow-lg shadow-red-500/10'
              : 'bg-[#0f152d] border-indigo-950/80 opacity-80'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-rose-600 to-red-800 border-2 border-red-400 flex items-center justify-center text-lg shadow-md">
                  👑
                </div>
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-red-500 border-2 border-[#0f152d]" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white truncate max-w-[110px]">
                    {user.name} (You)
                  </span>
                  <span className="text-[9px] bg-red-500/20 text-red-400 px-1 py-0.2 rounded font-mono font-bold">
                    Red
                  </span>
                </div>
                <div className="text-[10.5px] text-slate-300 font-medium">
                  হোম গুটি: <strong className="text-red-400 font-mono">{redHomeCount}/{targetWinTokens}</strong>
                </div>
              </div>
            </div>

            {/* User Turn Timer */}
            {currentTurn === 'red' && (
              <div className="flex items-center gap-1.5 bg-red-950/80 px-2.5 py-1 rounded-xl border border-red-500/40">
                <Clock className="w-3.5 h-3.5 text-red-400 animate-spin" />
                <span className="text-xs font-mono font-black text-red-300">{turnTimer}s</span>
              </div>
            )}
          </div>

          {/* ================= DICE & TURN CONTROL STATION ================= */}
          <div className="bg-gradient-to-b from-[#161e3d] to-[#0c1228] border-2 border-indigo-500/50 rounded-2xl p-3.5 shadow-2xl flex items-center justify-between gap-3">
            
            {/* Left: Chat Reaction Button */}
            <div className="relative">
              <button
                id="ludo-reaction-btn"
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="w-11 h-11 rounded-xl bg-indigo-950 hover:bg-indigo-900 border border-indigo-700/60 flex items-center justify-center text-amber-300 shadow-md active:scale-95"
                title="রিয়েকশন পাঠান"
              >
                <MessageCircle className="w-5 h-5" />
              </button>

              {/* Emoji Reactions Picker Dropup */}
              {showEmojiPicker && (
                <div className="absolute bottom-14 left-0 z-50 bg-[#0d142c] border border-amber-400/50 rounded-2xl p-2 shadow-2xl w-48 grid grid-cols-3 gap-1.5 animate-fade-in">
                  {CHAT_REACTIONS.map((r) => (
                    <button
                      key={r.id}
                      onClick={() => handleSendReaction(r.emoji, r.text)}
                      className="p-1.5 rounded-lg bg-indigo-950/60 hover:bg-amber-400/20 text-center text-xs flex flex-col items-center gap-0.5"
                    >
                      <span className="text-base">{r.emoji}</span>
                      <span className="text-[9px] text-slate-300 font-bold truncate max-w-full">{r.text}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Center: Turn Instructions Banner */}
            <div className="flex-1 text-center px-1">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center justify-center gap-1">
                <span>ম্যাচ প্রাইজ:</span>
                <span className="text-amber-400 font-mono font-black">৳{currentPrize}</span>
              </div>
              <div className="text-xs font-black text-white mt-0.5 line-clamp-2">
                {turnMessage}
              </div>
            </div>

            {/* Right: Interactive 3D Dice */}
            <div className="shrink-0">
              <LudoDice
                value={diceValue}
                isRolling={isRolling}
                canRoll={currentTurn === 'red' && canRoll && !isMovingToken}
                onRoll={handleRollDice}
                color={currentTurn}
                hasRolledSix={diceValue === 6}
              />
            </div>
          </div>
        </div>
      )}

      {/* ================= 4. GAMEOVER / VICTORY MODAL ================= */}
      {gamePhase === 'gameover' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm bg-gradient-to-b from-[#192248] to-[#0d1326] border-2 border-amber-400 rounded-3xl p-6 shadow-2xl text-center relative overflow-hidden">
            
            {/* Top Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-24 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            {winner === 'red' ? (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 p-0.5 shadow-2xl shadow-amber-500/40 flex items-center justify-center animate-bounce">
                  <div className="w-full h-full bg-[#0d1222] rounded-[22px] flex items-center justify-center">
                    <Trophy className="w-10 h-10 text-amber-400" />
                  </div>
                </div>

                <div>
                  <h3 className="text-2xl font-black text-amber-400 tracking-tight">
                    🎉 অভিনন্দন! আপনি বিজয়ী!
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    আপনি সফলভাবে লাইভ 1v1 লুডু ম্যাচ জিতেছেন!
                  </p>
                </div>

                <div className="bg-[#0b1022] border border-amber-400/40 rounded-2xl p-4 shadow-inner">
                  <span className="text-xs text-slate-400 font-bold uppercase">
                    উইনিং ব্যালেন্সে জমা হয়েছে:
                  </span>
                  <div className="text-3xl font-black text-amber-400 font-mono mt-1">
                    +৳{currentPrize}
                  </div>
                  <span className="text-[11px] text-emerald-400 font-bold block mt-1">
                    ✓ ব্যালেন্স সাথে সাথে আপডেট হয়েছে
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-rose-600 to-red-800 p-0.5 shadow-2xl flex items-center justify-center">
                  <div className="w-full h-full bg-[#0d1222] rounded-[22px] flex items-center justify-center text-4xl">
                    😢
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-black text-rose-400">
                    দুঃখিত! আপনি হেরেছেন
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    অপনেন্ট ({opponent?.name}) আগে হোমে পৌঁছেছে।
                  </p>
                </div>

                <div className="bg-[#0b1022] border border-rose-500/30 rounded-2xl p-3 text-xs text-slate-300">
                  <span>এন্ট্রি ফি: ৳{entryFee} কেটে নেওয়া হয়েছে। আবার চেষ্টা করুন!</span>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2 mt-6">
              <button
                id="ludo-rematch-btn"
                type="button"
                onClick={() => {
                  setGamePhase('lobby');
                }}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-amber-500/20 active:scale-95 transition-all cursor-pointer"
              >
                🔄 আরেকটি ম্যাচ খেলুন
              </button>

              <button
                id="ludo-back-home-btn"
                type="button"
                onClick={() => {
                  setCurrentTab('home');
                }}
                className="w-full py-2.5 bg-indigo-950/80 hover:bg-indigo-900 text-slate-300 text-xs font-bold rounded-xl border border-indigo-800/40 transition-colors cursor-pointer"
              >
                হোম স্ক্রিনে ফিরে যান
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Surrender / Forfeit Confirmation Modal */}
      {showSurrenderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-xs bg-[#121935] border border-rose-500/50 rounded-2xl p-5 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6" />
            </div>

            <div>
              <h4 className="text-base font-black text-white">ম্যাচ ছেড়ে দিতে চান?</h4>
              <p className="text-xs text-slate-300 mt-1">
                চলতি ম্যাচ ছেড়ে দিলে অপনেন্টকে জয়ী ঘোষণা করা হবে এবং এন্ট্রি ফি রিফান্ড হবে না।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowSurrenderModal(false)}
                className="py-2.5 bg-indigo-950 hover:bg-indigo-900 text-slate-200 text-xs font-bold rounded-xl border border-indigo-800/60"
              >
                না, খেলব
              </button>

              <button
                id="confirm-surrender-btn"
                type="button"
                onClick={handleSurrender}
                className="py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-md"
              >
                হ্যাঁ, লিভ নিন
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
