import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeft, 
  UploadCloud, 
  KeyRound, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert,
  Image as ImageIcon,
  Loader2,
  Clock,
  Check,
  X
} from 'lucide-react';

export const UploadResultScreen: React.FC = () => {
  const { setCurrentTab, submitResultScreenshot, matches, user, resultSubmissions } = useApp();
  const [selectedMatchId, setSelectedMatchId] = useState<string>('');
  const [roomCode, setRoomCode] = useState<string>('06447612');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // User's own submissions
  const userSubmissions = resultSubmissions.filter(s => s.userId === user.id || s.userPhone === user.phone);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode.trim()) {
      setStatusMessage({ type: 'error', text: 'দয়া করে রুম আইডি (Room ID) প্রদান করুন।' });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    setTimeout(() => {
      const res = submitResultScreenshot(selectedMatchId, roomCode, imagePreview || undefined);
      setIsSubmitting(false);
      if (res.success) {
        setStatusMessage({ type: 'success', text: res.message });
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    }, 1000);
  };

  return (
    <div className="pb-24 pt-1 px-3 max-w-md mx-auto space-y-4 text-white min-h-screen">
      {/* Header */}
      <div className="sticky top-14 z-30 bg-[#0d1222]/95 backdrop-blur-md py-2.5 flex items-center justify-between border-b border-indigo-950/60">
        <div className="flex items-center gap-2">
          <button
            id="upload-result-back-btn"
            onClick={() => setCurrentTab('matches')}
            className="w-8 h-8 rounded-full bg-indigo-950/80 hover:bg-indigo-900 text-slate-300 flex items-center justify-center border border-indigo-800/40"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h2 className="text-base font-extrabold text-white tracking-wide">
            Upload Screenshot
          </h2>
        </div>

        <button
          onClick={() => setCurrentTab('admin')}
          className="text-[11px] font-bold bg-amber-500/20 border border-amber-500/40 text-amber-400 px-2.5 py-1 rounded-lg"
        >
          এডমিন ভিউ
        </button>
      </div>

      {/* Main Upload Form Card */}
      <form onSubmit={handleSubmit} className="bg-[#121935] border border-indigo-500/30 rounded-3xl p-5 shadow-xl space-y-4">
        {/* Upload Box */}
        <label 
          htmlFor="screenshot-file-input"
          className="border-2 border-dashed border-indigo-500/50 hover:border-amber-400/70 bg-[#0b1022] rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors relative overflow-hidden group"
        >
          {imagePreview ? (
            <div className="relative w-full h-44 flex items-center justify-center">
              <img 
                src={imagePreview} 
                alt="Uploaded Screenshot" 
                className="w-full h-full object-contain rounded-xl"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-xl">
                <span className="text-xs font-bold text-white bg-indigo-600 px-3 py-1.5 rounded-lg">
                  ছবি পরিবর্তন করুন
                </span>
              </div>
            </div>
          ) : (
            <>
              <div className="w-14 h-14 rounded-full bg-blue-500/15 text-blue-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                <UploadCloud className="w-8 h-8 stroke-[1.5]" />
              </div>
              <span className="text-xs font-bold text-slate-200">
                Click Here to Upload Image (উইনিং স্ক্রিনশট দিন)
              </span>
              <span className="text-[10px] text-slate-400 mt-1">
                PNG, JPG or JPEG Supported
              </span>
            </>
          )}
          <input
            id="screenshot-file-input"
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>

        {/* Room ID Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Ludo King Room ID (রুম কোড)
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <input
              id="upload-room-id-input"
              type="text"
              placeholder="e.g. 06447612"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-[#0b1022] border border-indigo-900 focus:border-amber-400 rounded-xl text-sm text-white placeholder-slate-500 font-mono tracking-wider focus:outline-none transition-colors"
              required
            />
          </div>
        </div>

        {statusMessage && (
          <div
            className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
              statusMessage.type === 'success'
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200'
                : 'bg-red-500/20 border-red-500/40 text-red-200'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            )}
            <span className="leading-relaxed">{statusMessage.text}</span>
          </div>
        )}

        {/* Submit Result Button */}
        <button
          id="submit-result-btn"
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3.5 bg-gradient-to-r from-slate-900 via-indigo-900 to-slate-950 hover:from-indigo-900 hover:to-indigo-800 text-white font-extrabold text-sm rounded-xl border border-indigo-500/50 shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
              <span>রেজাল্ট যাচাই হচ্ছে...</span>
            </>
          ) : (
            <span>Submit Result</span>
          )}
        </button>
      </form>

      {/* User Submission Status Tracker */}
      {userSubmissions.length > 0 && (
        <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4 space-y-2.5 shadow-lg">
          <h3 className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>আপনার রেজাল্ট সাবমিশন হিস্টোরি:</span>
          </h3>

          <div className="space-y-2">
            {userSubmissions.map(sub => (
              <div key={sub.id} className="bg-[#0b1022] p-2.5 rounded-xl border border-indigo-950 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono text-white font-bold">Room: {sub.roomCode}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{sub.submittedAt}</span>
                </div>
                <div>
                  {sub.status === 'PENDING' ? (
                    <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      ⏳ যাচাইধীন
                    </span>
                  ) : sub.status === 'APPROVED' ? (
                    <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      ৳{sub.prizeAmount} উইনিং ব্যালেন্সে যুক্ত!
                    </span>
                  ) : (
                    <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <X className="w-3 h-3" />
                      বাতিলকৃত
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Guidelines and Warning Rules */}
      <div className="bg-[#10162e] border border-indigo-950 rounded-2xl p-4 space-y-2.5 text-xs text-slate-300 leading-relaxed shadow-lg">
        <div className="flex items-center gap-1.5 text-amber-400 font-bold mb-1">
          <ShieldAlert className="w-4 h-4" />
          <span>রেজাল্ট সাবমিশনের জরুরি নিয়মাবলী:</span>
        </div>
        
        <div className="flex items-start gap-2">
          <span className="text-amber-400 font-bold">•</span>
          <p>Ludo King এ ম্যাচ জয়ের পর স্পষ্ট স্ক্রিনশট তুলে এখানে আপলোড করবেন।</p>
        </div>

        <div className="flex items-start gap-2">
          <span className="text-amber-400 font-bold">•</span>
          <p>এডমিন স্ক্রিনশট যাচাই করে সরাসরি আপনার উইনিং ব্যালেন্সে প্রাইজ টাকা যোগ করে দিবেন।</p>
        </div>

        <div className="flex items-start gap-2 text-red-400 font-medium">
          <span className="font-bold">•</span>
          <p>ভুল বা এডিটেড ছবি আপলোড করলে একাউন্ট চিরকালের জন্য ব্যান করা হবে।</p>
        </div>
      </div>
    </div>
  );
};

