import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Play, Trophy, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

export const AutoLudoGame: React.FC = () => {
  const { user, setCurrentTab, playAutoLudoRound, openModal } = useApp();
  const [betAmount, setBetAmount] = useState<number>(20);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [userRoll, setUserRoll] = useState<number | null>(null);
  const [botRoll, setBotRoll] = useState<number | null>(null);
  const [gameResult, setGameResult] = useState<{ won: boolean; prize: number } | null>(null);
  const [error, setError] = useState<string>('');

  const betOptions = [10, 20, 50, 100, 200];

  const handlePlay = async () => {
    if (user.gamingBalance < betAmount) {
      setError('আপনার পর্যাপ্ত গেমিং ব্যালেন্স নেই! দয়া করে ডিপোজিট করুন।');
      return;
    }

    setError('');
    setIsRolling(true);
    setGameResult(null);
    setUserRoll(null);
    setBotRoll(null);

    // Simulate animated dice rolling sequence
    let count = 0;
    const interval = setInterval(() => {
      setUserRoll(Math.floor(Math.random() * 6) + 1);
      setBotRoll(Math.floor(Math.random() * 6) + 1);
      count++;
      if (count > 10) {
        clearInterval(interval);
      }
    }, 100);

    setTimeout(async () => {
      try {
        const res = await playAutoLudoRound(betAmount);
        setUserRoll(res.userRoll);
        setBotRoll(res.botRoll);
        setGameResult({ won: res.won, prize: res.prize });
        setIsRolling(false);
      } catch (err: any) {
        setError(err.message || 'খেলা সম্পন্ন করা যায়নি।');
        setIsRolling(false);
      }
    }, 1200);
  };

  const getDiceFace = (val: number | null) => {
    if (!val) return '🎲';
    const faces = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
    return faces[val - 1] || '🎲';
  };

  return (
    <div className="pb-24 pt-1 px-3 max-w-md mx-auto space-y-4 text-white min-h-screen">
      {/* Header */}
      <div className="sticky top-14 z-30 bg-[#0d1222]/95 backdrop-blur-md py-2.5 flex items-center justify-between border-b border-indigo-950/60">
        <div className="flex items-center gap-2">
          <button
            id="auto-ludo-back-btn"
            onClick={() => setCurrentTab('home')}
            className="w-8 h-8 rounded-full bg-indigo-950/80 hover:bg-indigo-900 text-slate-300 flex items-center justify-center border border-indigo-800/40"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-base font-extrabold text-white tracking-wide flex items-center gap-1.5">
              <span>Auto Ludo</span>
              <span className="bg-amber-400/20 text-amber-400 text-[10px] px-1.5 py-0.2 rounded border border-amber-400/40 uppercase">
                Quick Play
              </span>
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-[#151c38] px-2.5 py-1 rounded-md border border-indigo-800/50 text-xs font-bold text-amber-400">
          <span>গেমিং: ৳</span>
          <span className="font-mono">{user.gamingBalance.toFixed(0)}</span>
        </div>
      </div>

      {/* Game Stage Board */}
      <div className="bg-gradient-to-b from-[#161f42] to-[#0c1228] border border-amber-500/40 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        {/* Arena Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Stakes Banner */}
        <div className="text-center mb-4">
          <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">
            সম্ভাব্য উইনিং প্রাইজ (১.৮৫x)
          </span>
          <div className="text-2xl font-black font-mono text-amber-400">
            ৳{Math.round(betAmount * 1.85)}
          </div>
        </div>

        {/* Dual Battle Arena */}
        <div className="grid grid-cols-2 gap-4 my-6">
          {/* User Side */}
          <div className="bg-[#0e152d] border border-blue-500/40 rounded-2xl p-4 text-center shadow-lg relative">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500 absolute top-3 left-3 shadow-md shadow-blue-500" />
            <div className="text-xs font-bold text-blue-400 mb-2 truncate">
              {user.name} (You)
            </div>

            <div className="w-18 h-18 mx-auto bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center text-4xl shadow-xl shadow-blue-500/20 border border-blue-400/40">
              <span className={isRolling ? 'animate-spin' : ''}>
                {getDiceFace(userRoll)}
              </span>
            </div>

            <div className="mt-2 text-xs font-extrabold text-white">
              Roll: <span className="font-mono text-amber-300">{userRoll ?? '-'}</span>
            </div>
          </div>

          {/* Opponent / Bot Side */}
          <div className="bg-[#0e152d] border border-red-500/40 rounded-2xl p-4 text-center shadow-lg relative">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500 absolute top-3 right-3 shadow-md shadow-red-500" />
            <div className="text-xs font-bold text-red-400 mb-2">
              Opponent (Bot)
            </div>

            <div className="w-18 h-18 mx-auto bg-gradient-to-br from-red-600 to-rose-700 rounded-2xl flex items-center justify-center text-4xl shadow-xl shadow-red-500/20 border border-red-400/40">
              <span className={isRolling ? 'animate-spin' : ''}>
                {getDiceFace(botRoll)}
              </span>
            </div>

            <div className="mt-2 text-xs font-extrabold text-white">
              Roll: <span className="font-mono text-amber-300">{botRoll ?? '-'}</span>
            </div>
          </div>
        </div>

        {/* Outcome Display */}
        {gameResult && (
          <div
            className={`p-3 rounded-2xl text-center mb-4 border font-bold text-sm ${
              gameResult.won
                ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300'
                : 'bg-red-500/20 border-red-500/60 text-red-300'
            }`}
          >
            {gameResult.won ? (
              <div className="flex flex-col items-center gap-0.5">
                <span className="text-base">🎉 অভিনন্দন! আপনি জিতেছেন ৳{gameResult.prize}!</span>
                <span className="text-xs text-emerald-200 font-normal">উইনিং ব্যালেন্সে টাকা যোগ হয়েছে।</span>
              </div>
            ) : (
              <div>
                <span>😢 দুঃখিত! আপনি হেরেছেন। আবার চেষ্টা করুন।</span>
              </div>
            )}
          </div>
        )}

        {/* Bet Amount Selector */}
        <div className="space-y-2 mb-4">
          <label className="block text-xs font-bold text-slate-300">
            বেট পরিমাণ নির্ধারণ করুন:
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {betOptions.map((amount) => (
              <button
                key={amount}
                id={`auto-ludo-bet-${amount}`}
                disabled={isRolling}
                onClick={() => setBetAmount(amount)}
                className={`py-2 rounded-xl text-xs font-extrabold transition-all border ${
                  betAmount === amount
                    ? 'bg-amber-400 border-amber-300 text-slate-950 shadow-md scale-105'
                    : 'bg-[#0d1326] border-indigo-900 text-slate-300 hover:text-white'
                }`}
              >
                ৳{amount}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="mb-4 bg-red-500/20 border border-red-500/40 text-red-300 text-xs p-2.5 rounded-xl flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Play Action Button */}
        <button
          id="auto-ludo-roll-btn"
          disabled={isRolling}
          onClick={handlePlay}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-amber-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          {isRolling ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
              <span>ডাইস ঘুরছে...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>রোল করুন এবং জিতুন (৳{betAmount})</span>
            </>
          )}
        </button>

        {user.gamingBalance < betAmount && (
          <button
            id="auto-ludo-deposit-btn"
            onClick={() => openModal('add_money')}
            className="w-full mt-2 py-2 bg-indigo-900/60 hover:bg-indigo-800 text-amber-300 text-xs font-bold rounded-xl border border-indigo-700/60 transition-colors"
          >
            + টাকা রিচার্জ করুন (Add Money)
          </button>
        )}
      </div>
    </div>
  );
};
