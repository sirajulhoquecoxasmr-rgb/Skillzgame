import React, { useState } from 'react';
import { X, Trophy, Medal, Crown, Flame, Users, Calendar } from 'lucide-react';
import { BlockLeaderboardEntry } from '../../types';

interface BlockLeaderboardModalProps {
  currentUserId: string;
  onClose: () => void;
}

export const BlockLeaderboardModal: React.FC<BlockLeaderboardModalProps> = ({
  currentUserId,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'global' | 'weekly' | 'monthly' | 'friends'>('global');

  // Realistic mock leaderboard entries
  const globalLeaderboard: BlockLeaderboardEntry[] = [
    { rank: 1, userId: 'u_1', username: 'Mahir_PuzzleKing', avatar: '👑', rating: 2680, tier: 'Master', wins: 342, losses: 48, winRate: 88, bestScore: 1890 },
    { rank: 2, userId: 'u_2', username: 'BlockMaster_BD', avatar: '⚡', rating: 2540, tier: 'Master', wins: 290, losses: 55, winRate: 84, bestScore: 1720 },
    { rank: 3, userId: 'u_3', username: 'Sabbir_Pro99', avatar: '🔥', rating: 2410, tier: 'Master', wins: 240, losses: 62, winRate: 79, bestScore: 1640 },
    { rank: 4, userId: 'u_4', username: 'Raihan_Gamer', avatar: '💎', rating: 2190, tier: 'Diamond', wins: 195, losses: 70, winRate: 74, bestScore: 1480 },
    { rank: 5, userId: 'u_5', username: 'Naimul_X', avatar: '🛡️', rating: 1980, tier: 'Platinum', wins: 160, losses: 68, winRate: 70, bestScore: 1390 },
    { rank: 6, userId: 'u_6', username: 'Tanvir_Skillz', avatar: '🎯', rating: 1750, tier: 'Platinum', wins: 135, losses: 60, winRate: 69, bestScore: 1250 },
    { rank: 7, userId: 'u_7', username: 'Arif_Boss', avatar: '⭐', rating: 1520, tier: 'Gold', wins: 110, losses: 58, winRate: 65, bestScore: 1120 },
    { rank: 8, userId: 'u_8', username: 'Fahim_Challenger', avatar: '🚀', rating: 1380, tier: 'Gold', wins: 95, losses: 54, winRate: 64, bestScore: 980 },
    { rank: 9, userId: 'u_9', username: 'Sakib_75', avatar: '⚔️', rating: 1250, tier: 'Gold', wins: 82, losses: 49, winRate: 63, bestScore: 890 },
    { rank: 10, userId: 'u_10', username: 'Rubel_Duelist', avatar: '🕹️', rating: 1120, tier: 'Silver', wins: 68, losses: 45, winRate: 60, bestScore: 810 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in select-none">
      <div className="bg-[#0e162f] border border-indigo-500/60 rounded-3xl p-5 max-w-sm w-full shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-indigo-900/80 pb-2.5">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="font-black text-white text-base">LEADERBOARD</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#141b38] flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Filters */}
        <div className="grid grid-cols-4 gap-1 bg-[#090d1f] p-1 rounded-xl border border-indigo-950">
          {(['global', 'weekly', 'monthly', 'friends'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-1.5 rounded-lg text-[10px] font-extrabold uppercase transition-all ${
                activeTab === tab
                  ? 'bg-amber-400 text-slate-950 font-black shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Top 3 Podium */}
        <div className="grid grid-cols-3 gap-2 pt-2 items-end">
          {/* 2nd Place */}
          <div className="bg-[#121935] p-2.5 rounded-2xl border border-slate-600/60 text-center relative flex flex-col items-center">
            <span className="text-xl">{globalLeaderboard[1].avatar}</span>
            <span className="text-[10px] font-black text-slate-300 truncate w-full mt-1">
              {globalLeaderboard[1].username}
            </span>
            <span className="text-xs font-black text-slate-200 font-mono">
              {globalLeaderboard[1].rating}
            </span>
            <span className="bg-slate-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full mt-1">
              2nd
            </span>
          </div>

          {/* 1st Place */}
          <div className="bg-gradient-to-b from-amber-500/20 to-[#121935] p-3 rounded-2xl border-2 border-amber-400 text-center relative flex flex-col items-center shadow-lg shadow-amber-500/10 scale-105">
            <Crown className="w-4 h-4 text-amber-400 -mt-1 mb-0.5" />
            <span className="text-2xl">{globalLeaderboard[0].avatar}</span>
            <span className="text-[11px] font-black text-amber-300 truncate w-full mt-1">
              {globalLeaderboard[0].username}
            </span>
            <span className="text-sm font-black text-amber-400 font-mono">
              {globalLeaderboard[0].rating}
            </span>
            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full mt-1">
              1st 🏆
            </span>
          </div>

          {/* 3rd Place */}
          <div className="bg-[#121935] p-2.5 rounded-2xl border border-amber-800/60 text-center relative flex flex-col items-center">
            <span className="text-xl">{globalLeaderboard[2].avatar}</span>
            <span className="text-[10px] font-black text-amber-500 truncate w-full mt-1">
              {globalLeaderboard[2].username}
            </span>
            <span className="text-xs font-black text-amber-500 font-mono">
              {globalLeaderboard[2].rating}
            </span>
            <span className="bg-amber-700 text-white font-black text-[9px] px-2 py-0.5 rounded-full mt-1">
              3rd
            </span>
          </div>
        </div>

        {/* Full List */}
        <div className="space-y-1.5 pt-2">
          {globalLeaderboard.slice(3).map((item) => (
            <div
              key={item.userId}
              className="p-2.5 rounded-xl bg-[#121832] border border-indigo-950 flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5">
                <span className="font-mono text-xs font-bold text-slate-500 w-5 text-center">
                  #{item.rank}
                </span>
                <span className="text-base">{item.avatar}</span>
                <div>
                  <span className="text-xs font-bold text-white block truncate max-w-[120px]">
                    {item.username}
                  </span>
                  <span className="text-[9px] text-slate-400">
                    {item.wins} Wins • {item.winRate}% WR
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-black text-amber-400 font-mono block">
                  {item.rating} pts
                </span>
                <span className="text-[9px] text-slate-400">High: {item.bestScore}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
