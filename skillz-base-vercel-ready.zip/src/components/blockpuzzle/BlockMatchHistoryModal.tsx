import React from 'react';
import { X, History, Trophy, Frown, Handshake, Calendar, Swords, Target } from 'lucide-react';

interface MatchRecord {
  id: string;
  mode: string;
  opponentName?: string;
  userScore: number;
  opponentScore?: number;
  result: 'WIN' | 'LOSS' | 'DRAW' | 'PRACTICE';
  ratingChange?: number;
  lines: number;
  date: string;
}

interface BlockMatchHistoryModalProps {
  onClose: () => void;
}

export const BlockMatchHistoryModal: React.FC<BlockMatchHistoryModalProps> = ({ onClose }) => {
  const history: MatchRecord[] = [
    { id: 'm1', mode: 'Online Duel 1v1', opponentName: 'Mahir_Pro', userScore: 840, opponentScore: 620, result: 'WIN', ratingChange: 25, lines: 18, date: 'Today, 03:45 PM' },
    { id: 'm2', mode: 'Ranked 1v1', opponentName: 'Tanvir_Gamer', userScore: 530, opponentScore: 710, result: 'LOSS', ratingChange: -18, lines: 11, date: 'Today, 02:10 PM' },
    { id: 'm3', mode: 'Online Duel 1v1', opponentName: 'Sabbir99', userScore: 690, opponentScore: 690, result: 'DRAW', ratingChange: 0, lines: 14, date: 'Yesterday, 09:30 PM' },
    { id: 'm4', mode: 'Online Practice (Hard)', userScore: 920, result: 'PRACTICE', lines: 22, date: 'Yesterday, 06:15 PM' },
    { id: 'm5', mode: 'Weekly Tournament R1', opponentName: 'Fahim_Boss', userScore: 780, opponentScore: 590, result: 'WIN', ratingChange: 30, lines: 16, date: '2 days ago' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in select-none">
      <div className="bg-[#0e162f] border border-indigo-500/60 rounded-3xl p-5 max-w-sm w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-indigo-900/80 pb-2.5">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h3 className="font-black text-white text-base">MATCH HISTORY</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#141b38] flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* History List */}
        <div className="space-y-2">
          {history.map((m) => {
            const isWin = m.result === 'WIN';
            const isLoss = m.result === 'LOSS';
            const isDraw = m.result === 'DRAW';

            return (
              <div
                key={m.id}
                className="p-3 rounded-2xl bg-[#121935] border border-indigo-950/80 flex items-center justify-between shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                      isWin
                        ? 'bg-amber-400/20 text-amber-400 border border-amber-400/40'
                        : isLoss
                        ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                        : isDraw
                        ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    }`}
                  >
                    {isWin ? '🏆' : isLoss ? '😔' : isDraw ? '🤝' : '🎯'}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-extrabold text-white">
                        {m.mode}
                      </span>
                    </div>
                    {m.opponentName && (
                      <span className="text-[10px] text-slate-400 block">
                        vs {m.opponentName}
                      </span>
                    )}
                    <span className="text-[9px] text-slate-500 block mt-0.5">
                      {m.date} • {m.lines} lines cleared
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="flex items-baseline justify-end gap-1 font-mono">
                    <span className="text-sm font-black text-amber-400">
                      {m.userScore}
                    </span>
                    {m.opponentScore !== undefined && (
                      <span className="text-[10px] text-slate-500">
                        / {m.opponentScore}
                      </span>
                    )}
                  </div>

                  {m.ratingChange !== undefined && (
                    <span
                      className={`text-[10px] font-black font-mono block ${
                        m.ratingChange > 0
                          ? 'text-emerald-400'
                          : m.ratingChange < 0
                          ? 'text-red-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {m.ratingChange > 0 ? `+${m.ratingChange}` : m.ratingChange} Rating
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
