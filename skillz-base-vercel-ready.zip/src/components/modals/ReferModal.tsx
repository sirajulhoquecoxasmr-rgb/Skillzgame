import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Gift, X, Copy, Check, Share2, Users, Coins } from 'lucide-react';

export const ReferModal: React.FC = () => {
  const { activeModal, closeModal, user } = useApp();
  const [copied, setCopied] = useState<boolean>(false);

  if (activeModal !== 'refer') return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm animate-fade-in">
      <div 
        id="refer-modal-box"
        className="w-full max-w-sm bg-[#121935] border border-emerald-500/50 rounded-2xl p-5 shadow-2xl relative text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Gift className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Refer & Earn</h3>
              <p className="text-[10px] text-slate-400">বন্ধু রেফার করে আয় করুন</p>
            </div>
          </div>
          <button
            id="refer-close-btn"
            onClick={closeModal}
            className="w-7 h-7 rounded-full bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Hero Card */}
        <div className="bg-gradient-to-br from-emerald-900/60 to-indigo-950 p-4 rounded-2xl border border-emerald-500/30 text-center mb-4">
          <div className="text-3xl mb-1">🎁</div>
          <h4 className="font-extrabold text-sm text-emerald-300">
            প্রতিটি সফল রেফারে পান ৳২০ বোনাস!
          </h4>
          <p className="text-xs text-slate-300 mt-1">
            আপনার রেফারেল কোড ব্যবহার করে আপনার বন্ধু একাউন্ট খুলে ১ম ম্যাচ খেললেই আপনি পাবেন ক্যাশ রিওয়ার্ড।
          </p>
        </div>

        {/* Code Box */}
        <div className="bg-[#0b1022] border-2 border-dashed border-emerald-500/40 rounded-xl p-4 text-center mb-4">
          <span className="text-[11px] text-slate-400 uppercase font-bold block mb-1">
            আপনার রেফারেল কোড
          </span>
          <div className="text-2xl font-black font-mono tracking-widest text-emerald-400 my-1">
            {user.referralCode}
          </div>
          <button
            id="copy-refer-code-btn"
            type="button"
            onClick={handleCopy}
            className="mt-2 inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-1.5 rounded-lg shadow active:scale-95 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'কোড কপি হয়েছে!' : 'কোড কপি করুন'}</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-2 text-center mb-4">
          <div className="bg-[#0b1022] p-2.5 rounded-xl border border-indigo-950">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">মোট রেফার</span>
            <span className="text-sm font-black font-mono text-white">৩ জন</span>
          </div>
          <div className="bg-[#0b1022] p-2.5 rounded-xl border border-indigo-950">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">অর্জিত বোনাস</span>
            <span className="text-sm font-black font-mono text-emerald-400">৳৬০.০০</span>
          </div>
        </div>

        <button
          onClick={closeModal}
          className="w-full py-2.5 bg-indigo-950 hover:bg-indigo-900 border border-indigo-800 text-slate-200 font-bold rounded-xl text-xs"
        >
          ঠিক আছে
        </button>
      </div>
    </div>
  );
};
