import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Match } from '../../types';
import { ArrowLeft, Wallet, AlertTriangle, PlusCircle } from 'lucide-react';

export const JoinMatchModal: React.FC = () => {
  const { activeModal, closeModal, modalPayload, user, joinMatch, openModal } = useApp();
  const match: Match = modalPayload;

  const [ludoName, setLudoName] = useState<string>(user.ludoKingName || user.name);
  const [error, setError] = useState<string>('');

  if (activeModal !== 'join_match' || !match) return null;

  const hasEnoughBalance = user.gamingBalance >= match.entryFee;
  const isFull = match.joinedSeats >= match.totalSeats;

  const handleJoin = () => {
    if (!ludoName.trim()) {
      setError('আপনার Ludo King এর সঠিক নাম লিখুন');
      return;
    }
    if (!hasEnoughBalance) {
      setError('আপনার পর্যাপ্ত গেমিং ব্যালেন্স নেই!');
      return;
    }

    const res = joinMatch(match.id, ludoName);
    if (res.success) {
      closeModal();
      openModal('room_id', match);
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        id="join-match-modal-box"
        className="w-full max-w-sm bg-[#121936] border border-indigo-500/50 rounded-2xl overflow-hidden shadow-2xl relative text-white"
      >
        {/* Header (00:59) */}
        <div className="bg-[#0b1024] px-4 py-3 flex items-center justify-between border-b border-indigo-950">
          <button
            id="join-modal-back-btn"
            onClick={closeModal}
            className="w-7 h-7 rounded-full bg-indigo-950 hover:bg-indigo-900 flex items-center justify-center text-slate-300"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <span className="font-extrabold text-sm tracking-wider text-white">LX LUDO</span>
          <div className="flex items-center gap-1 bg-indigo-950/80 px-2 py-0.5 rounded text-xs font-semibold text-amber-400">
            <Wallet className="w-3 h-3" />
            <span>৳{user.gamingBalance.toFixed(2)}</span>
          </div>
        </div>

        {/* Ludo Graphic Banner (00:59) */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-800 to-purple-900 p-4 text-center relative overflow-hidden">
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur p-2 border border-white/20 shadow-inner flex items-center justify-center mb-1">
              <div className="text-4xl animate-bounce">🎲</div>
            </div>
            <div className="text-xl font-black tracking-wider text-amber-300 drop-shadow">
              LUDO KING
            </div>
          </div>
        </div>

        {/* Match Header Details (00:59) */}
        <div className="bg-[#182247] py-2 px-4 text-center border-b border-indigo-950">
          <h3 className="font-black text-sm text-white tracking-wide uppercase">
            LUDO KING || Match No: {match.matchNo}
          </h3>
        </div>

        {/* Entry Fee & Prize */}
        <div className="p-4 space-y-4">
          <div className="bg-[#0b1022] rounded-xl p-3.5 border border-indigo-900/60 flex items-center justify-around text-center">
            <div>
              <div className="text-xs text-slate-400 font-medium">Entry Fee:</div>
              <div className="text-base font-extrabold text-emerald-400 font-mono">
                ৳{match.entryFee.toFixed(2)}
              </div>
            </div>
            <div className="h-8 w-px bg-indigo-900" />
            <div>
              <div className="text-xs text-slate-400 font-medium">Win Prize:</div>
              <div className="text-base font-extrabold text-amber-400 font-mono">
                ৳{match.totalPrize.toFixed(2)}
              </div>
            </div>
          </div>

          {/* Ludo King Name Input (01:00) */}
          <div>
            <label className="block text-xs font-bold text-slate-200 mb-1.5">
              Enter your Ludo King name here:
            </label>
            <input
              id="ludo-king-name-input"
              type="text"
              value={ludoName}
              onChange={(e) => setLudoName(e.target.value)}
              placeholder="e.g. Sirajul Hoque"
              className="w-full px-3.5 py-2.5 bg-[#0b1022] border border-indigo-900 focus:border-amber-400 rounded-xl text-sm text-white focus:outline-none transition-colors"
            />
            <p className="text-[11px] text-amber-300/80 mt-1">
              ⚠️ Ludo King অ্যাপে আপনার যে নাম আছে, ঠিক সেই নামটিই দিন।
            </p>
          </div>

          {error && (
            <div className="bg-red-500/20 border border-red-500/40 text-red-300 text-xs p-2.5 rounded-lg flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Join / Insufficient Balance Button (01:00 - 01:08) */}
          {hasEnoughBalance && !isFull ? (
            <button
              id="join-match-confirm-btn"
              onClick={handleJoin}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold rounded-xl shadow-lg shadow-blue-500/20 active:scale-95 transition-all text-sm uppercase tracking-wider"
            >
              ম্যাচে জয়েন করুন (৳{match.entryFee})
            </button>
          ) : (
            <div className="space-y-2">
              <button
                id="insufficient-balance-btn"
                disabled
                className="w-full py-3 bg-[#e05263]/25 border border-[#e05263]/50 text-[#fca5a5] font-bold rounded-xl text-xs uppercase tracking-wider cursor-not-allowed text-center"
              >
                {isFull ? 'Match Full' : 'Insufficient Balance or Match Full'}
              </button>

              {!hasEnoughBalance && (
                <button
                  id="join-modal-add-money-btn"
                  onClick={() => {
                    closeModal();
                    openModal('add_money');
                  }}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>ব্যালেন্স এড করুন (Add Money)</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
