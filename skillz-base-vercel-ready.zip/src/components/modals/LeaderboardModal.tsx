import React from 'react';
import { useApp } from '../../context/AppContext';
import { topPlayers } from '../../data/mockData';
import { Trophy, X, Medal, Award, Flame } from 'lucide-react';

export const LeaderboardModal: React.FC = () => {
  const { activeModal, closeModal } = useApp();

  if (activeModal !== 'leaderboard') return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        id="leaderboard-modal-box"
        className="w-full max-w-sm bg-[#121935] border border-amber-500/50 rounded-2xl p-5 shadow-2xl relative text-white my-6 max-h-[85vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-400/20 flex items-center justify-center text-amber-400">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Top Players</h3>
              <p className="text-[10px] text-slate-400">সর্বোচ্চ বিজয়ী প্লেয়ারদের তালিকা</p>
            </div>
          </div>
          <button
            id="leaderboard-close-btn"
            onClick={closeModal}
            className="w-7 h-7 rounded-full bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top 3 Podium Cards */}
        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
          {/* 2nd Place */}
          <div className="bg-[#0b1022] border border-slate-400/30 rounded-xl p-2 pt-3 flex flex-col items-center justify-end">
            <div className="text-lg">🥈</div>
            <div className="text-[11px] font-bold text-slate-200 truncate w-full mt-1">{topPlayers[1].name}</div>
            <div className="text-[10px] text-amber-400 font-mono font-bold">৳{topPlayers[1].totalEarnings}</div>
          </div>

          {/* 1st Place */}
          <div className="bg-gradient-to-b from-[#2a220a] to-[#0b1022] border border-amber-400/60 rounded-xl p-2 pt-1 flex flex-col items-center justify-end shadow-lg scale-105">
            <div className="text-2xl animate-bounce">👑</div>
            <div className="text-xs font-black text-amber-300 truncate w-full">{topPlayers[0].name}</div>
            <div className="text-[11px] text-amber-400 font-mono font-black">৳{topPlayers[0].totalEarnings}</div>
          </div>

          {/* 3rd Place */}
          <div className="bg-[#0b1022] border border-amber-700/40 rounded-xl p-2 pt-3 flex flex-col items-center justify-end">
            <div className="text-lg">🥉</div>
            <div className="text-[11px] font-bold text-slate-200 truncate w-full mt-1">{topPlayers[2].name}</div>
            <div className="text-[10px] text-amber-400 font-mono font-bold">৳{topPlayers[2].totalEarnings}</div>
          </div>
        </div>

        {/* Full List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 scrollbar-none">
          {topPlayers.map((player) => (
            <div
              key={player.rank}
              className="bg-[#0b1022] border border-indigo-950 rounded-xl p-3 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black font-mono ${
                  player.rank === 1 ? 'bg-amber-400 text-slate-950' :
                  player.rank === 2 ? 'bg-slate-300 text-slate-950' :
                  player.rank === 3 ? 'bg-amber-700 text-white' :
                  'bg-indigo-950 text-slate-300'
                }`}>
                  {player.rank}
                </span>
                <div>
                  <h4 className="text-xs font-bold text-white">{player.name}</h4>
                  <p className="text-[10px] text-slate-400">জিতছেন: {player.matchesWon} টি ম্যাচ</p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-black font-mono text-emerald-400">
                  ৳{player.totalEarnings}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
