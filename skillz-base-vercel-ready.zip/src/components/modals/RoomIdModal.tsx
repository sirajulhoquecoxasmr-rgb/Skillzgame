import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Match } from '../../types';
import { KeyRound, Copy, Check, X, ShieldCheck, Clock, RefreshCw, AlertCircle, PlayCircle } from 'lucide-react';

export const RoomIdModal: React.FC = () => {
  const { activeModal, closeModal, modalPayload, setCurrentTab, matches } = useApp();
  const rawMatch: Match = modalPayload;
  const [copied, setCopied] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  if (activeModal !== 'room_id' || !rawMatch) return null;

  // Find the latest match object from context to ensure real-time room ID updates
  const match = matches.find(m => m.id === rawMatch.id) || rawMatch;
  const isSeatsFull = match.joinedSeats >= match.totalSeats;
  const hasRoomCode = isSeatsFull && Boolean(match.roomCode && match.roomCode.trim() !== '');

  const handleCopy = () => {
    if (!match.roomCode) return;
    navigator.clipboard.writeText(match.roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        id="room-id-modal-box"
        className="w-full max-w-sm bg-[#121935] border border-indigo-500/50 rounded-3xl p-5 shadow-2xl relative text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900/60 mb-4">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-2xl flex items-center justify-center ${
              hasRoomCode 
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                : isSeatsFull 
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
            }`}>
              {hasRoomCode ? (
                <KeyRound className="w-4 h-4" />
              ) : isSeatsFull ? (
                <Clock className="w-4 h-4 animate-pulse" />
              ) : (
                <KeyRound className="w-4 h-4 opacity-70" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                <span>Room ID</span>
                <span className="text-[11px] font-mono text-amber-400">#{match.matchNo}</span>
              </h3>
              <p className="text-[10px] text-slate-400">{match.title}</p>
            </div>
          </div>
          <button
            id="room-id-close-btn"
            onClick={closeModal}
            className="w-7 h-7 rounded-full bg-indigo-950 hover:bg-indigo-900 text-slate-400 hover:text-white flex items-center justify-center border border-indigo-800/40"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* State 1: Ready - 2 players joined AND Admin entered Room ID */}
        {hasRoomCode ? (
          <div className="bg-[#0b1022] border-2 border-dashed border-emerald-500/50 rounded-2xl p-4 text-center mb-4 shadow-inner">
            <div className="flex items-center justify-center gap-1 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Ludo King Room Code</span>
            </div>
            <div className="text-3xl font-black font-mono tracking-widest text-amber-400 my-2 select-all drop-shadow">
              {match.roomCode}
            </div>
            <button
              id="copy-room-code-btn"
              onClick={handleCopy}
              className="mt-1 inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black px-5 py-2 rounded-xl shadow-lg transition-all active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-slate-950 stroke-[3]" />
                  <span>কপি হয়েছে!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 stroke-[2.5]" />
                  <span>রুম কোড কপি করুন</span>
                </>
              )}
            </button>
          </div>
        ) : isSeatsFull ? (
          /* State 2: 2 players joined BUT Admin hasn't entered Room ID yet (Pending State) */
          <div className="bg-[#0b1022] border border-amber-500/40 rounded-2xl p-4 text-center mb-4 space-y-2.5">
            <div className="w-11 h-11 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/20">
              <Clock className="w-5 h-5 animate-spin" style={{ animationDuration: '4s' }} />
            </div>
            <div>
              <span className="bg-amber-500/20 text-amber-300 text-[11px] font-extrabold px-3 py-1 rounded-full border border-amber-500/30 inline-block">
                ⏳ রুম আইডি পেন্ডিং (Pending)
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed px-1">
              ২ জন খেলোয়াড় সফলভাবে জয়েন করেছেন! এডমিন এখন Ludo King অ্যাপে রুম তৈরি করে কোড দিচ্ছেন। এডমিন কোড সাবমিট করলেই এখানে সরাসরি দেখতে পাবেন।
            </p>
            <button
              id="refresh-room-id-btn"
              onClick={handleRefresh}
              className="inline-flex items-center gap-1.5 bg-indigo-900/80 hover:bg-indigo-800 text-amber-300 text-xs font-bold px-3.5 py-1.5 rounded-xl border border-indigo-700/60 shadow active:scale-95 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'চেক হচ্ছে...' : 'রিফ্রেশ করে চেক করুন'}</span>
            </button>
          </div>
        ) : (
          /* State 3: Less than 2 players joined (e.g. 0/2 or 1/2) */
          <div className="bg-[#0b1022] border border-indigo-500/30 rounded-2xl p-4 text-center mb-4 space-y-2.5">
            <div className="w-11 h-11 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto border border-indigo-500/20">
              <AlertCircle className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <span className="bg-indigo-950 text-indigo-300 border border-indigo-800 text-[11px] font-extrabold px-3 py-1 rounded-full inline-block">
                👥 ২ জন খেলোয়াড় এখনও জয়েন করেনি
              </span>
            </div>
            <div className="text-xs text-slate-300 leading-relaxed px-1">
              <p>
                যতক্ষণ না ২ জন প্লেয়ার জয়েন সম্পন্ন করবে, ততক্ষণ রুম আইডি জেনারেট হবে না।
              </p>
              <div className="mt-2 bg-indigo-950/60 p-2 rounded-xl border border-indigo-900/60 flex items-center justify-between text-xs">
                <span className="text-slate-400">বর্তমান জয়েন স্ট্যাটাস:</span>
                <span className="font-bold font-mono text-amber-400">{match.joinedSeats}/{match.totalSeats} জন</span>
              </div>
            </div>
            <button
              id="refresh-room-id-btn"
              onClick={handleRefresh}
              className="inline-flex items-center gap-1.5 bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 text-xs font-bold px-3.5 py-1.5 rounded-xl border border-indigo-700/60 shadow active:scale-95 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'চেক হচ্ছে...' : 'রিফ্রেশ করুন'}</span>
            </button>
          </div>
        )}

        {/* Instructions */}
        <div className="space-y-2 text-xs text-slate-300 bg-indigo-950/40 p-3.5 rounded-2xl border border-indigo-900/60 mb-4">
          <div className="font-bold text-amber-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>কীভাবে খেলবেন?</span>
          </div>
          <p className="flex items-start gap-1.5">
            <span className="text-amber-400 font-bold">১.</span>
            <span>{hasRoomCode ? 'উপরের কোডটি কপি করে Ludo King অ্যাপটি খুলুন।' : 'রুম কোড পাওয়ার পর কপি করে Ludo King অ্যাপ খুলুন।'}</span>
          </p>
          <p className="flex items-start gap-1.5">
            <span className="text-amber-400 font-bold">২.</span>
            <span>"Play with Friends" এ যান এবং "JOIN" সিলেক্ট করুন।</span>
          </p>
          <p className="flex items-start gap-1.5">
            <span className="text-amber-400 font-bold">৩.</span>
            <span>রুম কোডটি পেস্ট করে ম্যাচে প্রবেশ করুন।</span>
          </p>
          <p className="flex items-start gap-1.5">
            <span className="text-amber-400 font-bold">৪.</span>
            <span>খেলা শেষে বিজয়ী স্ক্রিনশট তুলে Result এ জমা দিন।</span>
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            id="room-id-upload-btn"
            onClick={() => {
              closeModal();
              setCurrentTab('upload_result');
            }}
            className="w-full py-2.5 bg-indigo-950 hover:bg-indigo-900 text-slate-200 border border-indigo-700/60 font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow"
          >
            <span>স্ক্রিনশট আপলোড</span>
          </button>
          <button
            id="room-id-done-btn"
            onClick={closeModal}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs shadow-lg"
          >
            ঠিক আছে
          </button>
        </div>
      </div>
    </div>
  );
};

