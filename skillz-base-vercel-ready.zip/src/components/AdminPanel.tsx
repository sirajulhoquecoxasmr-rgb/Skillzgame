import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, 
  Gamepad2, 
  CheckCircle2, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  Users, 
  Settings, 
  Plus, 
  RotateCcw, 
  Trash2, 
  ExternalLink, 
  KeyRound, 
  ShieldAlert, 
  Check, 
  X, 
  Eye, 
  Phone, 
  Copy, 
  Search, 
  AlertTriangle,
  ArrowRight,
  Sparkles,
  DollarSign,
  Lock,
  Radio,
  Image as ImageIcon
} from 'lucide-react';
import { Match, MatchCategory } from '../types';

export const AdminPanel: React.FC = () => {
  const {
    setCurrentTab,
    matches,
    createMatch,
    setMatchRoomCode,
    cancelMatchAndRefund,
    deleteMatch,
    depositRequests,
    approveDepositRequest,
    rejectDepositRequest,
    withdrawRequests,
    approveWithdrawRequest,
    rejectWithdrawRequest,
    resultSubmissions,
    approveResultSubmission,
    rejectResultSubmission,
    registeredUsers,
    adjustUserBalance,
    toggleUserBan,
    paymentSettings,
    updatePaymentSettings,
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<
    'dashboard' | 'matches' | 'results' | 'deposits' | 'withdraws' | 'users' | 'settings'
  >('dashboard');

  // Match creation state
  const [showCreateMatchModal, setShowCreateMatchModal] = useState(false);
  const [newMatchTitle, setNewMatchTitle] = useState('🔥 SPECIAL MATCH 🔥');
  const [newMatchSubtitle, setNewMatchSubtitle] = useState('২ জন জয়েন হলেই স্টার্ট দেওয়া হবে।');
  const [newMatchCategory, setNewMatchCategory] = useState<MatchCategory>('special');
  const [newMatchEntry, setNewMatchEntry] = useState(220);
  const [newMatchPrize, setNewMatchPrize] = useState(400);
  const [newMatchSeats, setNewMatchSeats] = useState(2);
  const [newMatchBoard, setNewMatchBoard] = useState('Ludo King');
  const [newMatchVersion, setNewMatchVersion] = useState('Mobile');
  const [newMatchRoomCode, setNewMatchRoomCode] = useState('');

  // Editing Room Code inline
  const [editingRoomMatchId, setEditingRoomMatchId] = useState<string | null>(null);
  const [roomCodeInput, setRoomCodeInput] = useState('');

  // Image preview modal
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);

  // User balance adjustment modal
  const [adjustingUser, setAdjustingUser] = useState<any | null>(null);
  const [adjustBalanceType, setAdjustBalanceType] = useState<'gaming' | 'winning'>('gaming');
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [adjustIsAdd, setAdjustIsAdd] = useState<boolean>(true);
  const [adjustNote, setAdjustNote] = useState<string>('এডমিন রিচার্জ');

  // Custom in-app Action Dialogs (Replaces blocked window.prompt / window.confirm)
  const [withdrawModal, setWithdrawModal] = useState<{
    action: 'approve' | 'reject';
    req: any;
    trxId: string;
    reason: string;
  } | null>(null);

  const [depositModal, setDepositModal] = useState<{
    action: 'approve' | 'reject';
    req: any;
    reason: string;
  } | null>(null);

  const [resultModal, setResultModal] = useState<{
    action: 'approve' | 'reject';
    sub: any;
    reason: string;
  } | null>(null);

  const [matchModal, setMatchModal] = useState<{
    action: 'cancel' | 'delete';
    match: Match;
  } | null>(null);

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // User Search
  const [userSearchTerm, setUserSearchTerm] = useState('');

  // Editable settings form
  const [settingsForm, setSettingsForm] = useState(paymentSettings);
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    setSettingsForm(paymentSettings);
  }, [paymentSettings]);

  // Stats calculation
  const pendingDepositsCount = depositRequests.filter(r => r.status === 'PENDING').length;
  const pendingWithdrawsCount = withdrawRequests.filter(r => r.status === 'PENDING').length;
  const pendingResultsCount = resultSubmissions.filter(s => s.status === 'PENDING').length;
  const waitingRoomCodeMatchesCount = matches.filter(m => m.joinedSeats >= m.totalSeats && !m.roomCode).length;

  const totalGamingBalance = registeredUsers.reduce((sum, u) => sum + (u.gamingBalance || 0), 0);
  const totalWinningBalance = registeredUsers.reduce((sum, u) => sum + (u.winningBalance || 0), 0);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentSettings(settingsForm);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2500);
  };

  const handleCreateMatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMatch({
      title: newMatchTitle,
      subtitle: newMatchSubtitle,
      category: newMatchCategory,
      entryFee: Number(newMatchEntry),
      totalPrize: Number(newMatchPrize),
      totalSeats: Number(newMatchSeats),
      boardType: newMatchBoard,
      version: newMatchVersion,
      roomCode: newMatchRoomCode,
    });
    setShowCreateMatchModal(false);
    setNewMatchRoomCode('');
  };

  const handleSaveRoomCode = (matchId: string) => {
    if (!roomCodeInput.trim()) return;
    setMatchRoomCode(matchId, roomCodeInput.trim());
    setEditingRoomMatchId(null);
    setRoomCodeInput('');
  };

  const handleAdjustBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingUser || adjustAmount <= 0) return;
    adjustUserBalance(adjustingUser.id, adjustBalanceType, Number(adjustAmount), adjustIsAdd, adjustNote);
    setAdjustingUser(null);
  };

  const filteredUsers = registeredUsers.filter(u => 
    u.name.toLowerCase().includes(userSearchTerm.toLowerCase()) || 
    u.phone.includes(userSearchTerm) ||
    u.ludoKingName.toLowerCase().includes(userSearchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#090d1a] text-slate-100 pb-24">
      {/* Top Admin Navbar */}
      <header className="sticky top-0 z-40 bg-[#0e1428]/95 backdrop-blur border-b border-indigo-900/60 px-4 py-3 shadow-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-red-500 to-indigo-600 p-0.5 shadow-lg shadow-amber-500/20">
              <div className="w-full h-full bg-[#0d1222] rounded-[10px] flex items-center justify-center">
                <span className="text-amber-400 font-black text-sm">LX</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-wide text-white">
                  LX LUDO Admin Panel
                </h1>
                <span className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  LIVE ADMIN
                </span>
              </div>
              <p className="text-xs text-slate-400">রুম আইডি, রেজাল্ট ভেরিফিকেশন ও সাইট ম্যানেজমেন্ট</p>
            </div>
          </div>

          <button
            id="admin-exit-btn"
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-1.5 bg-indigo-900/60 hover:bg-indigo-800 text-slate-200 border border-indigo-700/50 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow active:scale-95"
          >
            <span>ব্যবহারকারী ভিউ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Navigation Sub-bar */}
      <div className="bg-[#111833] border-b border-indigo-950 px-4 py-2 sticky top-[61px] z-30 overflow-x-auto scrollbar-none">
        <div className="max-w-6xl mx-auto flex items-center gap-1.5 min-w-max">
          <button
            id="admin-tab-dashboard"
            onClick={() => setActiveAdminTab('dashboard')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeAdminTab === 'dashboard'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>ড্যাশবোর্ড</span>
          </button>

          <button
            id="admin-tab-matches"
            onClick={() => setActiveAdminTab('matches')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative ${
              activeAdminTab === 'matches'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span>ম্যাচ ও রুম আইডি</span>
            {waitingRoomCodeMatchesCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            )}
          </button>

          <button
            id="admin-tab-results"
            onClick={() => setActiveAdminTab('results')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative ${
              activeAdminTab === 'results'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>রেজাল্ট যাচাই</span>
            {pendingResultsCount > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full">
                {pendingResultsCount}
              </span>
            )}
          </button>

          <button
            id="admin-tab-deposits"
            onClick={() => setActiveAdminTab('deposits')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative ${
              activeAdminTab === 'deposits'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>ডিপোজিট রিকোয়েস্ট</span>
            {pendingDepositsCount > 0 && (
              <span className="bg-emerald-500 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                {pendingDepositsCount}
              </span>
            )}
          </button>

          <button
            id="admin-tab-withdraws"
            onClick={() => setActiveAdminTab('withdraws')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative ${
              activeAdminTab === 'withdraws'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <ArrowUpCircle className="w-3.5 h-3.5" />
            <span>উইথড্র রিকোয়েস্ট</span>
            {pendingWithdrawsCount > 0 && (
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                {pendingWithdrawsCount}
              </span>
            )}
          </button>

          <button
            id="admin-tab-users"
            onClick={() => setActiveAdminTab('users')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeAdminTab === 'users'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>ইউজার তালিকা</span>
          </button>

          <button
            id="admin-tab-settings"
            onClick={() => setActiveAdminTab('settings')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeAdminTab === 'settings'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-indigo-950/50'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>সেটিংস ও নোটিশ</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        
        {/* ================= 1. DASHBOARD TAB ================= */}
        {activeAdminTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Urgent Action Alerts */}
            {(waitingRoomCodeMatchesCount > 0 || pendingResultsCount > 0 || pendingDepositsCount > 0) && (
              <div className="bg-gradient-to-r from-red-950/80 to-amber-950/60 border border-red-500/40 rounded-2xl p-4 shadow-lg animate-pulse">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm mb-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>জরুরি পেন্ডিং অ্যাকশন প্রয়োজন:</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {waitingRoomCodeMatchesCount > 0 && (
                    <button
                      onClick={() => setActiveAdminTab('matches')}
                      className="bg-red-900/60 hover:bg-red-800/80 border border-red-700/60 p-2.5 rounded-xl text-left text-xs"
                    >
                      <p className="font-bold text-white">🎮 {waitingRoomCodeMatchesCount}টি ম্যাচে রুম আইডি দিতে হবে</p>
                      <p className="text-[11px] text-red-200">২ জন প্লেয়ার জয়েন করে অপেক্ষায় রয়েছে</p>
                    </button>
                  )}
                  {pendingResultsCount > 0 && (
                    <button
                      onClick={() => setActiveAdminTab('results')}
                      className="bg-amber-900/60 hover:bg-amber-800/80 border border-amber-700/60 p-2.5 rounded-xl text-left text-xs"
                    >
                      <p className="font-bold text-white">📸 {pendingResultsCount}টি রেজাল্ট স্ক্রিনশট যাচাই বাকি</p>
                      <p className="text-[11px] text-amber-200">যাচাই করে প্রাইজ উইনিং ব্যালেন্সে দিন</p>
                    </button>
                  )}
                  {pendingDepositsCount > 0 && (
                    <button
                      onClick={() => setActiveAdminTab('deposits')}
                      className="bg-emerald-900/60 hover:bg-emerald-800/80 border border-emerald-700/60 p-2.5 rounded-xl text-left text-xs"
                    >
                      <p className="font-bold text-white">💳 {pendingDepositsCount}টি নতুন ডিপোজিট রিকোয়েস্ট</p>
                      <p className="text-[11px] text-emerald-200">TrxID যাচাই করে অনুমোদন করুন</p>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Stat Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>মোট ইউজার</span>
                  <Users className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-2xl font-black text-white">{registeredUsers.length} জন</div>
                <div className="text-[10px] text-emerald-400 font-semibold mt-1">সব একাউন্ট সক্রিয়</div>
              </div>

              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>মোট ম্যাচ</span>
                  <Gamepad2 className="w-4 h-4 text-purple-400" />
                </div>
                <div className="text-2xl font-black text-white">{matches.length} টি</div>
                <div className="text-[10px] text-amber-400 font-semibold mt-1">
                  {matches.filter(m => m.status === 'open').length} টি ওপেন রয়েছে
                </div>
              </div>

              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>গেমিং ব্যালেন্স (সার্কুলেশন)</span>
                  <DollarSign className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-amber-400">৳{totalGamingBalance.toFixed(0)}</div>
                <div className="text-[10px] text-slate-400 mt-1">ইউজার ওয়ালেটে মোট জমা</div>
              </div>

              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                  <span>উইনিং ব্যালেন্স (প্রাইজ)</span>
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-emerald-400">৳{totalWinningBalance.toFixed(0)}</div>
                <div className="text-[10px] text-slate-400 mt-1">উইথড্র যোগ্য ব্যালেন্স</div>
              </div>
            </div>

            {/* Quick Navigation Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Left Column: Match & Room ID Status */}
              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4 text-amber-400" />
                    <span>চলমান ম্যাচের রুম আইডি অবস্থা</span>
                  </h3>
                  <button
                    onClick={() => setActiveAdminTab('matches')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                  >
                    সব দেখুন &rarr;
                  </button>
                </div>
                
                <div className="space-y-2">
                  {matches.slice(0, 4).map(m => (
                    <div key={m.id} className="bg-[#0b1022] p-3 rounded-xl border border-indigo-950 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>Match #{m.matchNo}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-900 text-indigo-200">
                            {m.joinedSeats}/{m.totalSeats} জন
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">ফি: ৳{m.entryFee} • প্রাইজ: ৳{m.totalPrize}</p>
                      </div>

                      <div className="text-right">
                        {m.roomCode ? (
                          <span className="font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-1 rounded">
                            {m.roomCode}
                          </span>
                        ) : m.joinedSeats >= m.totalSeats ? (
                          <span className="text-red-400 font-bold animate-pulse text-[11px]">
                            রুম কোড দিন!
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[11px]">প্লেয়ার বাকি</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Pending Results Preview */}
              <div className="bg-[#121935] border border-indigo-900/60 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>সর্বশেষ রেজাল্ট সাবমিশন</span>
                  </h3>
                  <button
                    onClick={() => setActiveAdminTab('results')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                  >
                    সব যাচাই করুন &rarr;
                  </button>
                </div>

                <div className="space-y-2">
                  {resultSubmissions.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-6">কোনো সাবমিশন জমা নেই।</p>
                  ) : (
                    resultSubmissions.slice(0, 4).map(sub => (
                      <div key={sub.id} className="bg-[#0b1022] p-3 rounded-xl border border-indigo-950 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div 
                            onClick={() => sub.imageUrl && setPreviewImageUrl(sub.imageUrl)}
                            className="w-10 h-10 rounded-lg bg-indigo-950 overflow-hidden cursor-pointer border border-indigo-800 flex items-center justify-center text-slate-400 hover:opacity-80"
                          >
                            {sub.imageUrl ? (
                              <img src={sub.imageUrl} alt="Result" className="w-full h-full object-cover" />
                            ) : (
                              <ImageIcon className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <div className="font-bold text-white">{sub.userName}</div>
                            <div className="text-[11px] text-slate-400">Room: {sub.roomCode} • ৳{sub.prizeAmount}</div>
                          </div>
                        </div>

                        <div>
                          {sub.status === 'PENDING' ? (
                            <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              পেন্ডিং
                            </span>
                          ) : sub.status === 'APPROVED' ? (
                            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              অনুমোদিত
                            </span>
                          ) : (
                            <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              বাতিল
                            </span>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= 2. MATCHES & ROOM ID TAB ================= */}
        {activeAdminTab === 'matches' && (
          <div className="space-y-5">
            {/* Header + Add Match Button */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121935] p-4 rounded-2xl border border-indigo-900/60">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Gamepad2 className="w-5 h-5 text-amber-400" />
                  <span>ম্যাচ ও রুম আইডি কন্ট্রোল</span>
                </h2>
                <p className="text-xs text-slate-400">
                  প্লেয়ার জয়েন হলে Ludo King থেকে রুম ক্রিয়েট করে ৮ সংখ্যার Room ID টি এখানে ইনপুট দিন।
                </p>
              </div>

              <button
                id="admin-create-match-btn"
                onClick={() => setShowCreateMatchModal(true)}
                className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-4 py-2 rounded-xl text-xs shadow-lg active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>নতুন ম্যাচ তৈরি করুন</span>
              </button>
            </div>

            {/* Matches List */}
            <div className="space-y-3.5">
              {matches.map(m => {
                const isFull = m.joinedSeats >= m.totalSeats;
                const isEditingRoom = editingRoomMatchId === m.id;

                return (
                  <div
                    key={m.id}
                    className="bg-[#121935] rounded-2xl border border-indigo-900/60 p-4 shadow-xl transition-all"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2 border-b border-indigo-950 pb-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-amber-400 text-sm">Match #{m.matchNo}</span>
                          <span className="text-xs font-bold text-white bg-indigo-950 px-2 py-0.5 rounded-md border border-indigo-800">
                            {m.title}
                          </span>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                            m.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : m.status === 'cancelled'
                              ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                              : isFull && !m.roomCode
                              ? 'bg-red-500 text-white animate-pulse'
                              : isFull
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          }`}>
                            {m.status === 'completed' ? 'ম্যাচ সমাপ্ত' : m.status === 'cancelled' ? 'বাতিলকৃত' : isFull && !m.roomCode ? 'রুম আইডি দিন (অপেক্ষায়)' : isFull ? 'খেলছে (Ready)' : 'ওপেন (জয়েন চলছে)'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{m.subtitle}</p>
                      </div>

                      {/* Fee and Prize */}
                      <div className="flex items-center gap-3 text-xs">
                        <div className="bg-[#0b1022] px-3 py-1.5 rounded-xl border border-indigo-950">
                          <span className="text-slate-400">এন্ট্রি ফি: </span>
                          <span className="font-bold text-white">৳{m.entryFee}</span>
                        </div>
                        <div className="bg-[#0b1022] px-3 py-1.5 rounded-xl border border-indigo-950">
                          <span className="text-slate-400">প্রাইজ: </span>
                          <span className="font-bold text-amber-400">৳{m.totalPrize}</span>
                        </div>
                      </div>
                    </div>

                    {/* Joined Players */}
                    <div className="mb-3 bg-[#0b1022] p-3 rounded-xl border border-indigo-950/80">
                      <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
                        <span>জয়েনকৃত প্লেয়ার ({m.joinedSeats}/{m.totalSeats})</span>
                        <span>Ludo King নাম</span>
                      </div>

                      {m.joinedPlayers.length === 0 ? (
                        <p className="text-xs text-slate-600 italic">এখনো কোনো প্লেয়ার জয়েন করেনি।</p>
                      ) : (
                        <div className="space-y-1.5">
                          {m.joinedPlayers.map((p, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs text-slate-300 bg-indigo-950/40 px-2.5 py-1.5 rounded-lg">
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-indigo-800 flex items-center justify-center text-[10px] font-bold text-white">
                                  {idx + 1}
                                </span>
                                <div>
                                  <span className="font-bold text-white">{p.name}</span>
                                  {p.phone && <span className="text-[10px] text-slate-400 ml-1.5">({p.phone})</span>}
                                </div>
                              </div>
                              <div className="font-mono text-amber-400 font-bold bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">
                                {p.ludoKingName || 'Unknown'}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Room ID Section */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-indigo-950">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 font-semibold">Ludo King Room ID:</span>
                        {isEditingRoom ? (
                          <div className="flex items-center gap-1.5">
                            <input
                              type="text"
                              value={roomCodeInput}
                              onChange={(e) => setRoomCodeInput(e.target.value)}
                              placeholder="e.g. 06447612"
                              className="bg-[#0b1022] border border-amber-500/60 rounded-lg px-2.5 py-1 text-xs text-amber-400 font-mono font-bold w-32 focus:outline-none"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveRoomCode(m.id)}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-xs font-bold"
                            >
                              সেভ
                            </button>
                            <button
                              onClick={() => setEditingRoomMatchId(null)}
                              className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-lg text-xs"
                            >
                              বাতিল
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-black text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-lg text-xs tracking-wider">
                              {m.roomCode || 'রুম আইডি দেওয়া হয়নি'}
                            </span>
                            <button
                              onClick={() => {
                                setEditingRoomMatchId(m.id);
                                setRoomCodeInput(m.roomCode || '');
                              }}
                              className="bg-indigo-900 hover:bg-indigo-800 text-slate-200 border border-indigo-700/60 px-2.5 py-1 rounded-lg text-xs font-bold"
                            >
                              {m.roomCode ? 'পরিবর্তন' : '+ রুম কোড দিন'}
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Admin Actions for match */}
                      <div className="flex items-center gap-2">
                        {m.status !== 'cancelled' && m.status !== 'completed' && m.joinedSeats > 0 && (
                          <button
                            onClick={() => setMatchModal({ action: 'cancel', match: m })}
                            className="bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800/60 px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors active:scale-95"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>বাতিল ও রিফান্ড</span>
                          </button>
                        )}

                        <button
                          onClick={() => setMatchModal({ action: 'delete', match: m })}
                          className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-red-400 border border-slate-800 px-2 py-1 rounded-lg text-xs active:scale-95"
                          title="Delete Match"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= 3. RESULT VERIFICATION TAB ================= */}
        {activeAdminTab === 'results' && (
          <div className="space-y-4">
            <div className="bg-[#121935] p-4 rounded-2xl border border-indigo-900/60 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>রেজাল্ট ও স্ক্রিনশট যাচাইকরণ</span>
                </h2>
                <p className="text-xs text-slate-400">
                  ব্যবহারকারীদের আপলোডকৃত Ludo King উইনিং স্ক্রিনশট যাচাই করে প্রাইজ প্রদান করুন।
                </p>
              </div>
              <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-xs font-bold px-3 py-1 rounded-full">
                পেন্ডিং: {pendingResultsCount} টি
              </span>
            </div>

            <div className="space-y-3.5">
              {resultSubmissions.length === 0 ? (
                <div className="bg-[#121935] border border-indigo-950 rounded-2xl p-8 text-center text-slate-500 text-sm">
                  বর্তমানে কোনো রেজাল্ট সাবমিশন জমা নেই।
                </div>
              ) : (
                resultSubmissions.map(sub => (
                  <div
                    key={sub.id}
                    className={`bg-[#121935] border rounded-2xl p-4 shadow-lg ${
                      sub.status === 'PENDING'
                        ? 'border-amber-500/40'
                        : sub.status === 'APPROVED'
                        ? 'border-emerald-500/30 opacity-90'
                        : 'border-red-500/30 opacity-80'
                    }`}
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                      {/* Submitter & Match details */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{sub.userName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">({sub.userPhone})</span>
                        </div>
                        <p className="text-xs text-slate-300">Ludo King ID: <span className="text-amber-400 font-bold">{sub.ludoKingName || sub.userName}</span></p>
                        <p className="text-xs text-slate-300">Room Code: <span className="font-mono text-white font-bold bg-indigo-950 px-1.5 py-0.5 rounded">{sub.roomCode}</span></p>
                        <p className="text-[11px] text-slate-500">{sub.submittedAt}</p>
                      </div>

                      {/* Screenshot thumbnail */}
                      <div className="flex items-center gap-3">
                        {sub.imageUrl ? (
                          <div 
                            onClick={() => setPreviewImageUrl(sub.imageUrl!)}
                            className="relative group cursor-pointer w-24 h-24 rounded-xl overflow-hidden border-2 border-indigo-700/60 bg-black flex-shrink-0"
                          >
                            <img src={sub.imageUrl} alt="Result Screenshot" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                              <Eye className="w-5 h-5 text-white" />
                            </div>
                          </div>
                        ) : (
                          <div className="w-24 h-24 rounded-xl bg-indigo-950 border border-indigo-800 flex items-center justify-center text-slate-500 text-xs">
                            স্ক্রিনশট নেই
                          </div>
                        )}
                        <div>
                          <span className="text-xs text-slate-400 block mb-0.5">প্রাইজ পরিমাণ:</span>
                          <span className="text-xl font-extrabold text-amber-400">৳{sub.prizeAmount}</span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-col gap-2 justify-center">
                        {sub.status === 'PENDING' ? (
                          <>
                            <button
                              onClick={() => setResultModal({ action: 'approve', sub, reason: '' })}
                              className="w-full py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                            >
                              <Check className="w-4 h-4 stroke-[3]" />
                              <span>বিজয়ী অনুমোদন ও ৳{sub.prizeAmount} প্রদান</span>
                            </button>

                            <button
                              onClick={() => setResultModal({ action: 'reject', sub, reason: 'নকল বা ভুল স্ক্রিনশট' })}
                              className="w-full py-1.5 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800/60 font-semibold rounded-xl text-xs transition-colors active:scale-95"
                            >
                              বাতিল করুন
                            </button>
                          </>
                        ) : sub.status === 'APPROVED' ? (
                          <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 p-2 rounded-xl text-center text-xs font-bold">
                            ✅ বিজয়ী অনুমোদিত ও প্রাইজ পেইড!
                          </div>
                        ) : (
                          <div className="bg-red-950/40 border border-red-500/40 text-red-300 p-2 rounded-xl text-center text-xs font-bold">
                            ❌ বাতিলকৃত ({sub.adminNote || 'ভুল স্ক্রিনশট'})
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= 4. DEPOSIT REQUESTS TAB ================= */}
        {activeAdminTab === 'deposits' && (
          <div className="space-y-4">
            <div className="bg-[#121935] p-4 rounded-2xl border border-indigo-900/60 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <ArrowDownCircle className="w-5 h-5 text-emerald-400" />
                  <span>ডিপোজিট রিকোয়েস্ট ম্যানেজমেন্ট</span>
                </h2>
                <p className="text-xs text-slate-400">
                  ব্যবহারকারীর TrxID যাচাই করে অনুমোদন করলে সাথে সাথে গেমিং ব্যালেন্স যোগ হবে।
                </p>
              </div>
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold px-3 py-1 rounded-full">
                পেন্ডিং: {pendingDepositsCount} টি
              </span>
            </div>

            <div className="space-y-3">
              {depositRequests.length === 0 ? (
                <div className="bg-[#121935] border border-indigo-950 rounded-2xl p-8 text-center text-slate-500 text-sm">
                  কোনো ডিপোজিট রিকোয়েস্ট নেই।
                </div>
              ) : (
                depositRequests.map(req => (
                  <div
                    key={req.id}
                    className={`bg-[#121935] border rounded-2xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-3 ${
                      req.status === 'PENDING'
                        ? 'border-emerald-500/40'
                        : req.status === 'APPROVED'
                        ? 'border-indigo-900/60 opacity-80'
                        : 'border-red-500/30 opacity-70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{req.userName}</span>
                        <span className="text-xs text-slate-400 font-mono">({req.userPhone})</span>
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-900 text-amber-300">
                          {req.method}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-300 mt-1">
                        <span>সেন্ডার নম্বর: <b className="font-mono text-white">{req.senderNumber}</b></span>
                        <span>TrxID: <b className="font-mono text-amber-400 bg-indigo-950 px-1.5 py-0.5 rounded border border-indigo-800">{req.trxId}</b></span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">{req.timestamp}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <span className="text-xs text-slate-400 block">পরিমাণ</span>
                        <span className="text-xl font-extrabold text-emerald-400">৳{req.amount}</span>
                      </div>

                      {req.status === 'PENDING' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setDepositModal({ action: 'approve', req, reason: '' })}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow active:scale-95 transition-all"
                          >
                            অনুমোদন করুন
                          </button>
                          <button
                            onClick={() => setDepositModal({ action: 'reject', req, reason: 'ভুল ট্রানজেকশন আইডি' })}
                            className="bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800 text-xs px-2.5 py-2 rounded-xl transition-colors active:scale-95"
                          >
                            বাতিল
                          </button>
                        </div>
                      ) : req.status === 'APPROVED' ? (
                        <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold px-3 py-1 rounded-full">
                          ✅ অনুমোদিত
                        </span>
                      ) : (
                        <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-xs font-bold px-3 py-1 rounded-full">
                          ❌ বাতিলকৃত
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= 5. WITHDRAW REQUESTS TAB ================= */}
        {activeAdminTab === 'withdraws' && (
          <div className="space-y-4">
            <div className="bg-[#121935] p-4 rounded-2xl border border-indigo-900/60 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <ArrowUpCircle className="w-5 h-5 text-amber-400" />
                  <span>উইথড্র রিকোয়েস্ট ম্যানেজমেন্ট</span>
                </h2>
                <p className="text-xs text-slate-400">
                  ব্যবহারকারীর নাম্বারে টাকা পাঠিয়ে 'পরিশোধ সম্পন্ন' ক্লিক করুন অথবা বাতিল ও রিফান্ড করুন।
                </p>
              </div>
              <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 text-xs font-bold px-3 py-1 rounded-full">
                পেন্ডিং: {pendingWithdrawsCount} টি
              </span>
            </div>

            <div className="space-y-3">
              {withdrawRequests.length === 0 ? (
                <div className="bg-[#121935] border border-indigo-950 rounded-2xl p-8 text-center text-slate-500 text-sm">
                  কোনো উইথড্র রিকোয়েস্ট নেই।
                </div>
              ) : (
                withdrawRequests.map(req => (
                  <div
                    key={req.id}
                    className={`bg-[#121935] border rounded-2xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-3 ${
                      req.status === 'PENDING'
                        ? 'border-amber-500/40'
                        : req.status === 'APPROVED'
                        ? 'border-indigo-900/60 opacity-80'
                        : 'border-red-500/30 opacity-70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{req.userName}</span>
                        <span className="text-xs text-slate-400 font-mono">({req.userPhone})</span>
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-900 text-amber-300">
                          {req.method} ({req.accountType})
                        </span>
                      </div>
                      <div className="text-xs text-slate-300 mt-1">
                        টাকা পাঠানোর নাম্বার: <b className="font-mono text-amber-400 text-sm">{req.accountNumber}</b>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">{req.timestamp}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <span className="text-xs text-slate-400 block">উইথড্র পরিমাণ</span>
                        <span className="text-xl font-extrabold text-amber-400">৳{req.amount}</span>
                      </div>

                      {req.status === 'PENDING' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setWithdrawModal({
                              action: 'approve',
                              req,
                              trxId: `ADM${Math.floor(100000 + Math.random() * 900000)}`,
                              reason: ''
                            })}
                            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black px-3.5 py-2 rounded-xl shadow active:scale-95 transition-all"
                          >
                            পরিশোধ সম্পন্ন
                          </button>
                          <button
                            onClick={() => setWithdrawModal({
                              action: 'reject',
                              req,
                              trxId: '',
                              reason: 'ভুল একাউন্ট নম্বর'
                            })}
                            className="bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800 text-xs px-2.5 py-2 rounded-xl transition-colors active:scale-95"
                          >
                            বাতিল ও রিফান্ড
                          </button>
                        </div>
                      ) : req.status === 'APPROVED' ? (
                        <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold px-3 py-1 rounded-full">
                          ✅ পরিশোধিত ({req.adminTrxId || 'PAID'})
                        </span>
                      ) : (
                        <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-xs font-bold px-3 py-1 rounded-full">
                          ❌ বাতিলকৃত ({req.adminNote || 'রিফান্ড সম্পন্ন'})
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= 6. USERS MANAGEMENT TAB ================= */}
        {activeAdminTab === 'users' && (
          <div className="space-y-4">
            <div className="bg-[#121935] p-4 rounded-2xl border border-indigo-900/60 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-400" />
                  <span>রেজিস্টার্ড ব্যবহারকারী তালিকা</span>
                </h2>
                <p className="text-xs text-slate-400">
                  ব্যালেন্স যোগ/কর্তন করুন এবং প্রয়োজনে সন্দেহভাজন ইউজার ব্যান করুন।
                </p>
              </div>

              {/* Search Box */}
              <div className="relative w-full sm:w-64">
                <input
                  type="text"
                  value={userSearchTerm}
                  onChange={(e) => setUserSearchTerm(e.target.value)}
                  placeholder="নাম বা ফোন নাম্বার দিয়ে খুঁজুন..."
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div className="space-y-3">
              {filteredUsers.map(u => (
                <div
                  key={u.id}
                  className={`bg-[#121935] border rounded-2xl p-4 shadow-lg flex flex-wrap items-center justify-between gap-3 ${
                    u.isBanned ? 'border-red-600/50 bg-red-950/20' : 'border-indigo-900/60'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{u.name}</span>
                      <span className="text-xs text-slate-400 font-mono">({u.phone})</span>
                      {u.isBanned && (
                        <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase">
                          BANNED
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300">Ludo King Name: <span className="text-amber-400 font-bold">{u.ludoKingName || u.name}</span></p>
                    <p className="text-[11px] text-slate-500">ম্যাচ খেলেছেন: {u.matchesPlayed || 0} টি • যুক্ত হয়েছেন: {u.joinedAt}</p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-xs text-slate-400">
                        গেমিং: <b className="text-amber-400 font-mono font-bold">৳{u.gamingBalance.toFixed(0)}</b>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        উইনিং: <b className="text-emerald-400 font-mono font-bold">৳{u.winningBalance.toFixed(0)}</b>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setAdjustingUser(u);
                          setAdjustAmount(100);
                        }}
                        className="bg-indigo-900 hover:bg-indigo-800 text-white border border-indigo-700 px-3 py-1.5 rounded-xl text-xs font-bold"
                      >
                        ব্যালেন্স এডিট
                      </button>

                      <button
                        onClick={() => {
                          toggleUserBan(u.id);
                        }}
                        className={`text-xs px-2.5 py-1.5 rounded-xl font-bold ${
                          u.isBanned
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                            : 'bg-red-950 text-red-300 border border-red-800'
                        }`}
                      >
                        {u.isBanned ? 'আনব্যান' : 'ব্যান'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= 7. SETTINGS & NOTICES TAB ================= */}
        {activeAdminTab === 'settings' && (
          <div className="space-y-6 max-w-3xl">
            <div className="bg-[#121935] p-4 rounded-2xl border border-indigo-900/60">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-amber-400" />
                <span>পেমেন্ট নম্বর ও সাইট সেটিংস</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                এখানে আপনার বিকাশ, নগদ, রকেট এবং সাপোর্ট নম্বর পরিবর্তন করতে পারেন।
              </p>
            </div>

            <form onSubmit={handleSaveSettings} className="bg-[#121935] p-6 rounded-2xl border border-indigo-900/60 space-y-4">
              <h3 className="text-sm font-bold text-amber-400 border-b border-indigo-950 pb-2">
                পেমেন্ট ডিপোজিট নম্বরসমূহ (Personal)
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">bKash নম্বর (Personal)</label>
                  <input
                    type="text"
                    value={settingsForm.bkash}
                    onChange={(e) => setSettingsForm({ ...settingsForm, bkash: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">Nagad নম্বর (Personal)</label>
                  <input
                    type="text"
                    value={settingsForm.nagad}
                    onChange={(e) => setSettingsForm({ ...settingsForm, nagad: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">Rocket নম্বর (Personal)</label>
                  <input
                    type="text"
                    value={settingsForm.rocket}
                    onChange={(e) => setSettingsForm({ ...settingsForm, rocket: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">Upay নম্বর (Personal)</label>
                  <input
                    type="text"
                    value={settingsForm.upay}
                    onChange={(e) => setSettingsForm({ ...settingsForm, upay: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <h3 className="text-sm font-bold text-amber-400 border-b border-indigo-950 pb-2 pt-2">
                সাপোর্ট ও যোগাযোগ
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">WhatsApp হেল্পলাইন নম্বর</label>
                  <input
                    type="text"
                    value={settingsForm.whatsappSupport}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsappSupport: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">Telegram চ্যানেল লিংক</label>
                  <input
                    type="text"
                    value={settingsForm.telegramLink}
                    onChange={(e) => setSettingsForm({ ...settingsForm, telegramLink: e.target.value })}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              <h3 className="text-sm font-bold text-amber-400 border-b border-indigo-950 pb-2 pt-2">
                হেডার নোটিশ ও পপ-আপ মেসেজ
              </h3>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">হেডার রানিং স্ক্রল নোটিশ (Marquee)</label>
                <input
                  type="text"
                  value={settingsForm.marqueeNotice}
                  onChange={(e) => setSettingsForm({ ...settingsForm, marqueeNotice: e.target.value })}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">পপ-আপ নোটিশ বার্তা (Popup Notice)</label>
                <textarea
                  rows={2}
                  value={settingsForm.popupNoticeText}
                  onChange={(e) => setSettingsForm({ ...settingsForm, popupNoticeText: e.target.value })}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs shadow-lg active:scale-95 transition-all flex items-center gap-2"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>সেটিংস সেভ করুন</span>
                </button>
                {settingsSaved && (
                  <p className="text-xs text-emerald-400 font-bold mt-2 animate-fade-in">
                    ✅ সেটিংস সফলভাবে আপডেট ও সংরক্ষিত হয়েছে!
                  </p>
                )}
              </div>
            </form>
          </div>
        )}
      </main>

      {/* ================= MODAL: CREATE MATCH ================= */}
      {showCreateMatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-[#121935] border border-indigo-500/50 rounded-2xl p-5 shadow-2xl text-white">
            <div className="flex items-center justify-between border-b border-indigo-950 pb-3 mb-4">
              <h3 className="text-sm font-bold flex items-center gap-2 text-amber-400">
                <Plus className="w-4 h-4" />
                <span>নতুন লুডো ম্যাচ তৈরি করুন</span>
              </h3>
              <button
                onClick={() => setShowCreateMatchModal(false)}
                className="w-7 h-7 rounded-full bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateMatchSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">ম্যাচ শিরোনাম (Title)</label>
                <input
                  type="text"
                  value={newMatchTitle}
                  onChange={(e) => setNewMatchTitle(e.target.value)}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">সাবটাইটেল / শর্ত</label>
                <input
                  type="text"
                  value={newMatchSubtitle}
                  onChange={(e) => setNewMatchSubtitle(e.target.value)}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">এন্ট্রি ফি (৳)</label>
                  <input
                    type="number"
                    value={newMatchEntry}
                    onChange={(e) => setNewMatchEntry(Number(e.target.value))}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">মোট প্রাইজ (৳)</label>
                  <input
                    type="number"
                    value={newMatchPrize}
                    onChange={(e) => setNewMatchPrize(Number(e.target.value))}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-amber-400 font-mono font-bold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">ক্যাটাগরি</label>
                  <select
                    value={newMatchCategory}
                    onChange={(e) => setNewMatchCategory(e.target.value as MatchCategory)}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="special">স্পেশাল ম্যাচ (Special)</option>
                    <option value="time">টাইম ম্যাচ (Time Match)</option>
                    <option value="one_player">১ জন জয়েন (1 Player)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-300 font-semibold mb-1">প্লেয়ার আসন (Seats)</label>
                  <select
                    value={newMatchSeats}
                    onChange={(e) => setNewMatchSeats(Number(e.target.value))}
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value={2}>২ জন (1 VS 1)</option>
                    <option value={4}>৪ জন (1 VS 3)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">Ludo King Room Code (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={newMatchRoomCode}
                  onChange={(e) => setNewMatchRoomCode(e.target.value)}
                  placeholder="খালি রাখতে পারেন, প্লেয়ার জয়েনের পরও দেওয়া যাবে"
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-amber-400 font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black rounded-xl text-xs shadow-lg active:scale-95 transition-all"
                >
                  ম্যাচ তৈরি সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: BALANCE ADJUSTMENT ================= */}
      {adjustingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#121935] border border-indigo-500/50 rounded-2xl p-5 shadow-2xl text-white">
            <div className="flex items-center justify-between border-b border-indigo-950 pb-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-white">ব্যালেন্স এডজাস্টমেন্ট</h3>
                <p className="text-[11px] text-amber-400 font-bold">{adjustingUser.name} ({adjustingUser.phone})</p>
              </div>
              <button
                onClick={() => setAdjustingUser(null)}
                className="w-7 h-7 rounded-full bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAdjustBalanceSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">অ্যাকশন টাইপ</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustIsAdd(true)}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      adjustIsAdd ? 'bg-emerald-600 text-white' : 'bg-[#0b1022] text-slate-400 border border-indigo-900'
                    }`}
                  >
                    + যোগ করুন (Add)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustIsAdd(false)}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      !adjustIsAdd ? 'bg-red-600 text-white' : 'bg-[#0b1022] text-slate-400 border border-indigo-900'
                    }`}
                  >
                    - কর্তন করুন (Deduct)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">কোন ব্যালেন্স?</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustBalanceType('gaming')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      adjustBalanceType === 'gaming' ? 'bg-amber-500 text-slate-950' : 'bg-[#0b1022] text-slate-400 border border-indigo-900'
                    }`}
                  >
                    গেমিং ব্যালেন্স (৳{adjustingUser.gamingBalance})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustBalanceType('winning')}
                    className={`py-1.5 rounded-lg text-xs font-bold ${
                      adjustBalanceType === 'winning' ? 'bg-emerald-500 text-slate-950' : 'bg-[#0b1022] text-slate-400 border border-indigo-900'
                    }`}
                  >
                    উইনিং ব্যালেন্স (৳{adjustingUser.winningBalance})
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">টাকার পরিমাণ (৳)</label>
                <input
                  type="number"
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(Number(e.target.value))}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-slate-300 font-semibold mb-1">নোট / কারণ</label>
                <input
                  type="text"
                  value={adjustNote}
                  onChange={(e) => setAdjustNote(e.target.value)}
                  className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black rounded-xl text-xs shadow-lg"
                >
                  কনফার্ম করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: IMAGE PREVIEW ================= */}
      {previewImageUrl && (
        <div 
          onClick={() => setPreviewImageUrl(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/90 backdrop-blur-md animate-fade-in cursor-pointer"
        >
          <div className="relative max-w-xl max-h-[85vh] bg-[#121935] p-2 rounded-2xl border border-indigo-500/50">
            <button
              onClick={() => setPreviewImageUrl(null)}
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-black/80 text-white flex items-center justify-center border border-white/20"
            >
              <X className="w-5 h-5" />
            </button>
            <img src={previewImageUrl} alt="Full Preview" className="max-h-[80vh] w-auto rounded-xl object-contain" />
          </div>
        </div>
      )}

      {/* ================= MODAL: WITHDRAW ACTION ================= */}
      {withdrawModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121935] border border-indigo-500/40 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-indigo-900/60 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                {withdrawModal.action === 'approve' ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>উইথড্র পেমেন্ট পরিশোধ নিশ্চিতকরণ</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    <span>উইথড্র বাতিল ও রিফান্ড</span>
                  </>
                )}
              </h3>
              <button
                onClick={() => setWithdrawModal(null)}
                className="w-7 h-7 rounded-lg bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center border border-indigo-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Request info summary card */}
            <div className="bg-[#0b1022] p-3.5 rounded-xl border border-indigo-900/60 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>গ্রাহক নাম:</span>
                <span className="font-bold text-white">{withdrawModal.req.userName} ({withdrawModal.req.userPhone})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>মেথড ও টাইপ:</span>
                <span className="font-bold text-amber-400 uppercase">{withdrawModal.req.method} ({withdrawModal.req.accountType})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>টাকা পাঠানোর নাম্বার:</span>
                <span className="font-mono font-black text-white text-sm bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">{withdrawModal.req.accountNumber}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300 pt-1 border-t border-indigo-900/50">
                <span>উইথড্র পরিমাণ:</span>
                <span className="font-black text-emerald-400 text-base">৳{withdrawModal.req.amount}</span>
              </div>
            </div>

            {withdrawModal.action === 'approve' ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  আপনি কি গ্রাহকের নাম্বারে <b>৳{withdrawModal.req.amount}</b> টাকা পাঠিয়েছেন? নিচে TrxID লিখে পরিশোধ সম্পন্ন করুন।
                </p>
                <div>
                  <label className="block text-xs text-slate-400 font-semibold mb-1">বিকাশ / নগদ TrxID (ঐচ্ছিক):</label>
                  <input
                    type="text"
                    value={withdrawModal.trxId}
                    onChange={(e) => setWithdrawModal({ ...withdrawModal, trxId: e.target.value })}
                    placeholder="e.g. ADM782391"
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-amber-400 outline-none"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setWithdrawModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      approveWithdrawRequest(withdrawModal.req.id, withdrawModal.trxId.trim() || 'PAID');
                      showToast(`উইথড্র ৳${withdrawModal.req.amount} সফলভাবে পরিশোধ সম্পন্ন হয়েছে!`, 'success');
                      setWithdrawModal(null);
                    }}
                    className="flex-1 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ✅ পরিশোধ সম্পন্ন করুন
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-red-950/40 border border-red-800/60 p-2.5 rounded-xl text-red-200 text-xs">
                  ⚠️ বাতিল করলে গ্রাহকের <b>৳{withdrawModal.req.amount}</b> টাকা সাথে সাথে তার <b>উইনিং ব্যালেন্সে</b> ফেরত চলে যাবে।
                </div>

                <div>
                  <label className="block text-xs text-slate-400 font-semibold mb-1.5">বাতিলের কারণ সিলেক্ট করুন বা লিখুন:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {['ভুল একাউন্ট নম্বর', 'নাম্বার সার্ভিস বন্ধ', 'ব্যক্তিগত তথ্য অসম্পূর্ণ', 'সন্দেহজনক কার্যক্রম'].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => setWithdrawModal({ ...withdrawModal, reason })}
                        className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                          withdrawModal.reason === reason
                            ? 'bg-red-900/80 border-red-500 text-white font-bold'
                            : 'bg-[#0b1022] border-indigo-900 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={withdrawModal.reason}
                    onChange={(e) => setWithdrawModal({ ...withdrawModal, reason: e.target.value })}
                    placeholder="কাস্টম কারণ লিখুন..."
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white focus:border-red-400 outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setWithdrawModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      rejectWithdrawRequest(withdrawModal.req.id, withdrawModal.reason.trim() || 'ভুল একাউন্ট তথ্য');
                      showToast(`উইথড্র বাতিল করা হয়েছে এবং ৳${withdrawModal.req.amount} রিফান্ড করা হয়েছে!`, 'info');
                      setWithdrawModal(null);
                    }}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ❌ বাতিল ও ব্যালেন্স রিফান্ড
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL: DEPOSIT ACTION ================= */}
      {depositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121935] border border-indigo-500/40 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-indigo-900/60 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                {depositModal.action === 'approve' ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>ডিপোজিট অনুমোদন</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    <span>ডিপোজিট বাতিল</span>
                  </>
                )}
              </h3>
              <button
                onClick={() => setDepositModal(null)}
                className="w-7 h-7 rounded-lg bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center border border-indigo-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Request info */}
            <div className="bg-[#0b1022] p-3.5 rounded-xl border border-indigo-900/60 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>গ্রাহক নাম:</span>
                <span className="font-bold text-white">{depositModal.req.userName} ({depositModal.req.userPhone})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>পেমেন্ট মেথড:</span>
                <span className="font-bold text-amber-400 uppercase">{depositModal.req.method}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>সেন্ডার নম্বর:</span>
                <span className="font-mono text-white font-bold">{depositModal.req.senderNumber}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>গ্রাহকের TrxID:</span>
                <span className="font-mono text-amber-400 font-bold bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">{depositModal.req.trxId}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300 pt-1 border-t border-indigo-900/50">
                <span>ডিপোজিট পরিমাণ:</span>
                <span className="font-black text-emerald-400 text-base">৳{depositModal.req.amount}</span>
              </div>
            </div>

            {depositModal.action === 'approve' ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  অনুমোদন করলে ব্যবহারকারীর একাউন্টে সাথে সাথে <b>৳{depositModal.req.amount}</b> গেমিং ব্যালেন্স যোগ হবে।
                </p>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setDepositModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const res = approveDepositRequest(depositModal.req.id);
                      showToast(res.message, res.success ? 'success' : 'error');
                      setDepositModal(null);
                    }}
                    className="flex-1 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ✅ অনুমোদন করুন
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="block text-xs text-slate-400 font-semibold mb-1.5">বাতিলের কারণ সিলেক্ট করুন বা লিখুন:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {['ভুল ট্রানজেকশন আইডি', 'টাকা জমা পাওয়া যায়নি', 'টাকার পরিমাণ মিল নেই', 'ভুল সেন্ডার নম্বর'].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => setDepositModal({ ...depositModal, reason })}
                        className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                          depositModal.reason === reason
                            ? 'bg-red-900/80 border-red-500 text-white font-bold'
                            : 'bg-[#0b1022] border-indigo-900 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={depositModal.reason}
                    onChange={(e) => setDepositModal({ ...depositModal, reason: e.target.value })}
                    placeholder="কাস্টম কারণ লিখুন..."
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white focus:border-red-400 outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setDepositModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      rejectDepositRequest(depositModal.req.id, depositModal.reason.trim() || 'ভুল ট্রানজেকশন তথ্য');
                      showToast('ডিপোজিট রিকোয়েস্ট বাতিল করা হয়েছে!', 'info');
                      setDepositModal(null);
                    }}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ❌ ডিপোজিট বাতিল করুন
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL: RESULT ACTION ================= */}
      {resultModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121935] border border-indigo-500/40 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-indigo-900/60 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                {resultModal.action === 'approve' ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>বিজয়ী অনুমোদন ও প্রাইজ মানি প্রদান</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    <span>স্ক্রিনশট সাবমিশন বাতিল</span>
                  </>
                )}
              </h3>
              <button
                onClick={() => setResultModal(null)}
                className="w-7 h-7 rounded-lg bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center border border-indigo-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-[#0b1022] p-3.5 rounded-xl border border-indigo-900/60 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>প্লেয়ার নাম:</span>
                <span className="font-bold text-white">{resultModal.sub.userName} ({resultModal.sub.userPhone})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Ludo King ID:</span>
                <span className="font-bold text-amber-400">{resultModal.sub.ludoKingName || resultModal.sub.userName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>রুম কোড:</span>
                <span className="font-mono text-white font-bold bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">{resultModal.sub.roomCode}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300 pt-1 border-t border-indigo-900/50">
                <span>প্রাইজ পরিমাণ:</span>
                <span className="font-black text-amber-400 text-base">৳{resultModal.sub.prizeAmount}</span>
              </div>
            </div>

            {resultModal.action === 'approve' ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  অনুমোদন করলে <b>{resultModal.sub.userName}</b> এর উইনিং ব্যালেন্সে <b>৳{resultModal.sub.prizeAmount}</b> যোগ হবে এবং ম্যাচটি সম্পন্ন হবে।
                </p>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setResultModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const res = approveResultSubmission(resultModal.sub.id);
                      showToast(res.message, res.success ? 'success' : 'error');
                      setResultModal(null);
                    }}
                    className="flex-1 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    🏆 বিজয়ী অনুমোদন ও প্রাইজ দিন
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label className="block text-xs text-slate-400 font-semibold mb-1.5">বাতিলের কারণ সিলেক্ট করুন বা লিখুন:</label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {['নকল বা এডিটেড স্ক্রিনশট', 'ভুল রুম আইডি', 'পরাজয়ের স্ক্রিনশট', 'স্পষ্ট নয় এমন ছবি'].map((reason) => (
                      <button
                        key={reason}
                        type="button"
                        onClick={() => setResultModal({ ...resultModal, reason })}
                        className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                          resultModal.reason === reason
                            ? 'bg-red-900/80 border-red-500 text-white font-bold'
                            : 'bg-[#0b1022] border-indigo-900 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    value={resultModal.reason}
                    onChange={(e) => setResultModal({ ...resultModal, reason: e.target.value })}
                    placeholder="কাস্টম কারণ লিখুন..."
                    className="w-full bg-[#0b1022] border border-indigo-800 rounded-xl px-3 py-2 text-xs text-white focus:border-red-400 outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setResultModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      rejectResultSubmission(resultModal.sub.id, resultModal.reason.trim() || 'ভুল বা নকল স্ক্রিনশট');
                      showToast('রেজাল্ট সাবমিশন বাতিল করা হয়েছে!', 'info');
                      setResultModal(null);
                    }}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ❌ সাবমিশন বাতিল করুন
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL: MATCH ACTION ================= */}
      {matchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121935] border border-indigo-500/40 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-indigo-900/60 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                {matchModal.action === 'cancel' ? (
                  <>
                    <RotateCcw className="w-5 h-5 text-amber-400" />
                    <span>ম্যাচ বাতিল ও ফি রিফান্ড</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-5 h-5 text-red-400" />
                    <span>ম্যাচ ডিলিট নিশ্চিতকরণ</span>
                  </>
                )}
              </h3>
              <button
                onClick={() => setMatchModal(null)}
                className="w-7 h-7 rounded-lg bg-indigo-950 text-slate-400 hover:text-white flex items-center justify-center border border-indigo-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-[#0b1022] p-3.5 rounded-xl border border-indigo-900/60 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>ম্যাচ নং:</span>
                <span className="font-bold text-amber-400">#{matchModal.match.matchNo} ({matchModal.match.title})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>এন্ট্রি ফি:</span>
                <span className="font-bold text-white">৳{matchModal.match.entryFee}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>মোট পুরস্কার:</span>
                <span className="font-bold text-emerald-400">৳{matchModal.match.totalPrize}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>জয়েনকৃত প্লেয়ার:</span>
                <span className="font-bold text-white">{matchModal.match.joinedSeats} / {matchModal.match.totalSeats} জন</span>
              </div>
            </div>

            {matchModal.action === 'cancel' ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-300">
                  ম্যাচটি বাতিল করলে জয়েনকৃত সকল ({matchModal.match.joinedSeats} জন) প্লেয়ারকে তাদের এন্ট্রি ফি <b>৳{matchModal.match.entryFee}</b> সাথে সাথে <b>গেমিং ব্যালেন্সে রিফান্ড</b> করে দেওয়া হবে।
                </p>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMatchModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    ফিরে যান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      cancelMatchAndRefund(matchModal.match.id);
                      showToast(`ম্যাচ #${matchModal.match.matchNo} বাতিল ও এন্ট্রি ফি রিফান্ড করা হয়েছে!`, 'info');
                      setMatchModal(null);
                    }}
                    className="flex-1 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    ✅ হ্যাঁ, বাতিল ও রিফান্ড করুন
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-red-300">
                  আপনি কি নিশ্চিত যে ম্যাচ <b>#{matchModal.match.matchNo}</b> সম্পূর্ণভাবে তালিকা থেকে মুছে ফেলতে চান?
                </p>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMatchModal(null)}
                    className="flex-1 py-2 bg-indigo-950 hover:bg-indigo-900 text-slate-300 font-bold rounded-xl text-xs border border-indigo-800"
                  >
                    না, রাখুন
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      deleteMatch(matchModal.match.id);
                      showToast(`ম্যাচ #${matchModal.match.matchNo} ডিলিট করা হয়েছে!`, 'info');
                      setMatchModal(null);
                    }}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-lg active:scale-95"
                  >
                    🗑️ ডিলিট করুন
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= IN-APP TOAST NOTIFICATION ================= */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 animate-bounce">
          <div className={`px-4 py-2.5 rounded-2xl shadow-2xl border flex items-center gap-2 text-xs font-bold ${
            toast.type === 'success'
              ? 'bg-emerald-950 text-emerald-200 border-emerald-500/60 shadow-emerald-950/80'
              : toast.type === 'error'
              ? 'bg-red-950 text-red-200 border-red-500/60 shadow-red-950/80'
              : 'bg-indigo-950 text-amber-200 border-amber-500/60 shadow-indigo-950/80'
          }`}>
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
};
