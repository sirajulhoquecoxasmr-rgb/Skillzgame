import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { 
  BlockGameMode, 
  PracticeDifficulty, 
  BlockShape, 
  BlockPlayerState, 
  SpecialBlockType
} from '../types';
import { 
  BOARD_SIZE, 
  createEmptyBoard, 
  canPlaceBlock, 
  placeBlockOnBoard, 
  checkAndClearLines, 
  calculateMoveScore, 
  generateBlockTrio, 
  hasAnyLegalMove, 
  getTileCount,
  computeBoardHash,
  SPECIAL_BLOCKS
} from '../utils/blockPuzzleEngine';
import { blockAudio } from '../utils/blockPuzzleAudio';

// Components
import { BlockLobbyView, ENTRY_FEE_OPTIONS } from './blockpuzzle/BlockLobbyView';
import { BlockHud } from './blockpuzzle/BlockHud';
import { BlockBoardView, FloatingScoreItem } from './blockpuzzle/BlockBoardView';
import { BlockTrayView } from './blockpuzzle/BlockTrayView';
import { BlockSubmitModal } from './blockpuzzle/BlockSubmitModal';
import { BlockResultModal } from './blockpuzzle/BlockResultModal';
import { BlockPendingMatchesModal, PendingMatchItem } from './blockpuzzle/BlockPendingMatchesModal';
import { BlockProfileModal } from './blockpuzzle/BlockProfileModal';
import { BlockLeaderboardModal } from './blockpuzzle/BlockLeaderboardModal';
import { BlockMatchHistoryModal } from './blockpuzzle/BlockMatchHistoryModal';
import { BlockRulesModal } from './blockpuzzle/BlockRulesModal';
import { AndroidCodeViewerModal } from './blockpuzzle/AndroidCodeViewerModal';
import { 
  Sparkles, 
  Swords, 
  Timer, 
  ShieldCheck, 
  Pause, 
  Play, 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  Zap, 
  Flame, 
  ArrowLeft,
  Clock,
  RotateCcw
} from 'lucide-react';

type ScreenState = 'lobby' | 'matchmaking' | 'countdown' | 'playing' | 'submit' | 'result';

export const BlockPuzzleDuel: React.FC = () => {
  const { 
    user, 
    setCurrentTab, 
    startBlockPuzzleMatch, 
    finishBlockPuzzleMatch, 
    refundBlockPuzzleMatch 
  } = useApp();

  // Screen State
  const [screenState, setScreenState] = useState<ScreenState>('lobby');
  const [gameMode, setGameMode] = useState<BlockGameMode>('duel');
  const [difficulty, setDifficulty] = useState<PracticeDifficulty>('normal');
  const [entryFee, setEntryFee] = useState<number>(20);
  const [prize, setPrize] = useState<number>(35);
  const [activeMatchId, setActiveMatchId] = useState<string>('');

  // Modals
  const [showPendingModal, setShowPendingModal] = useState<boolean>(false);
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [showRules, setShowRules] = useState<boolean>(false);
  const [showAndroidCode, setShowAndroidCode] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Audio / Haptic
  const [isMuted, setIsMuted] = useState<boolean>(blockAudio.isMuted);
  const [isHaptic, setIsHaptic] = useState<boolean>(blockAudio.isHapticEnabled);

  // Match Outcome and Opponent data
  const [isSubmittingScore, setIsSubmittingScore] = useState<boolean>(false);
  const [matchOutcome, setMatchOutcome] = useState<'WON' | 'LOST' | 'DRAW' | 'PENDING'>('WON');
  const [matchedOpponent, setMatchedOpponent] = useState<{ name: string; score: number; linesCleared?: number } | undefined>();

  // Career Persistent Stats
  const [rating, setRating] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_rating')) || 1250;
    } catch {
      return 1250;
    }
  });

  const [bestScore, setBestScore] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_best_score')) || 3820;
    } catch {
      return 3820;
    }
  });

  const [practiceBestScore, setPracticeBestScore] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_practice_best')) || 2450;
    } catch {
      return 2450;
    }
  });

  const [winStreak, setWinStreak] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_win_streak')) || 2;
    } catch {
      return 2;
    }
  });

  const [matchesPlayed, setMatchesPlayed] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_matches_played')) || 14;
    } catch {
      return 14;
    }
  });

  const [matchesWon, setMatchesWon] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_matches_won')) || 9;
    } catch {
      return 9;
    }
  });

  const [matchesLost, setMatchesLost] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_matches_lost')) || 5;
    } catch {
      return 5;
    }
  });

  const [totalLines, setTotalLines] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('bp_total_lines')) || 142;
    } catch {
      return 142;
    }
  });

  // Pending Matches from LocalStorage
  const [pendingMatches, setPendingMatches] = useState<PendingMatchItem[]>(() => {
    try {
      const raw = localStorage.getItem('bp_pending_matches');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const activePendingCount = pendingMatches.filter(m => m.status === 'PENDING').length;

  // Active Match State (10x10 Board)
  const [matchSeed, setMatchSeed] = useState<number>(Date.now());
  const [trioIndex, setTrioIndex] = useState<number>(0);
  const [board, setBoard] = useState<number[][]>(createEmptyBoard);
  const [pieces, setPieces] = useState<(BlockShape | null)[]>([]);
  const [selectedPieceIndex, setSelectedPieceIndex] = useState<number | null>(null);
  
  // Placement preview & drag handling
  const gridRef = useRef<HTMLDivElement>(null);
  const [hoveredCell, setHoveredCell] = useState<{ r: number; c: number } | null>(null);
  const [clearingRows, setClearingRows] = useState<number[]>([]);
  const [clearingCols, setClearingCols] = useState<number[]>([]);
  const [floatingScores, setFloatingScores] = useState<FloatingScoreItem[]>([]);
  const [bannerAlert, setBannerAlert] = useState<{ text: string; subText?: string; type: 'info' | 'bolt' | 'fire' | 'warning' } | null>(null);
  const [isOutOfMoves, setIsOutOfMoves] = useState<boolean>(false);

  // Drag floating piece coordinate state
  const [dragPointer, setDragPointer] = useState<{ x: number; y: number } | null>(null);

  // Timer & Countdown (180s = 3:00 Minutes like Skillz Block Blitz in Video)
  const TOTAL_MATCH_TIME = 180;
  const [countdown, setCountdown] = useState<number>(3);
  const [remainingTime, setRemainingTime] = useState<number>(TOTAL_MATCH_TIME);

  // Player State
  const [playerState, setPlayerState] = useState<BlockPlayerState>({
    playerId: user?.id || 'player_1',
    name: user?.name || 'Player 70lol70',
    avatar: '😎',
    ready: true,
    connected: true,
    score: 0,
    linesCleared: 0,
    combo: 0,
    bestCombo: 0,
    streak: 0,
    boardState: createEmptyBoard(),
    remainingTime: TOTAL_MATCH_TIME,
    lastActionTimestamp: Date.now(),
  });

  const matchTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Toggle Mute / Haptic
  const handleToggleMute = () => {
    const val = blockAudio.toggleMute();
    setIsMuted(val);
  };

  const handleToggleHaptic = () => {
    const val = blockAudio.toggleHaptic();
    setIsHaptic(val);
  };

  // Trigger floating text
  const triggerFloatingScore = (text: string, x: number, y: number, color?: string, banner?: 'POWER_BOLT' | 'FIRE_STREAK' | null) => {
    const id = `fs_${Date.now()}_${Math.random()}`;
    setFloatingScores((prev) => [...prev, { id, text, x, y, color, banner }]);
    setTimeout(() => {
      setFloatingScores((prev) => prev.filter((item) => item.id !== id));
    }, 1200);
  };

  // Show center arcade banner
  const triggerBanner = (text: string, subText?: string, type: 'info' | 'bolt' | 'fire' | 'warning' = 'info', duration: number = 1600) => {
    setBannerAlert({ text, subText, type });
    setTimeout(() => {
      setBannerAlert(null);
    }, duration);
  };

  // Start Entry Fee Duel Match
  const handleStartDuel = (fee: number, winPrize: number) => {
    blockAudio.playClick();
    setEntryFee(fee);
    setPrize(winPrize);
    setGameMode('duel');

    // Deduct entry fee from wallet via AppContext
    const res = startBlockPuzzleMatch(fee);
    if (!res.success) {
      alert(res.message);
      return;
    }

    setActiveMatchId(res.matchId || `bp_${Date.now()}`);
    // Show Finding Opponent Matchmaking view first (Video 00:00)
    setScreenState('matchmaking');
  };

  // Start Practice Mode (Free)
  const handleStartPractice = (diff: PracticeDifficulty) => {
    blockAudio.playClick();
    setGameMode('practice');
    setDifficulty(diff);
    setEntryFee(0);
    setPrize(0);
    startCountdown('practice');
  };

  // 3-second Countdown before match
  const startCountdown = (mode: BlockGameMode) => {
    setScreenState('countdown');
    setCountdown(3);

    let count = 3;
    const interval = setInterval(() => {
      count -= 1;
      setCountdown(count);
      blockAudio.playClick();

      if (count <= 0) {
        clearInterval(interval);
        initMatch(mode, difficulty);
      }
    }, 1000);
  };

  // Initialize 10x10 Match
  const initMatch = (mode: BlockGameMode, diff: PracticeDifficulty = 'normal') => {
    const seed = Date.now();
    setMatchSeed(seed);
    setTrioIndex(0);
    setBoard(createEmptyBoard());
    setClearingRows([]);
    setClearingCols([]);
    setSelectedPieceIndex(null);
    setHoveredCell(null);
    setDragPointer(null);
    setIsOutOfMoves(false);
    setIsPaused(false);
    setRemainingTime(TOTAL_MATCH_TIME);
    setMatchedOpponent(undefined);

    const initialPieces = generateBlockTrio(seed, 0, diff, false);
    setPieces(initialPieces);

    setPlayerState({
      playerId: user?.id || 'player_1',
      name: user?.name || 'Player 70lol70',
      avatar: '😎',
      ready: true,
      connected: true,
      score: 0,
      linesCleared: 0,
      combo: 0,
      bestCombo: 0,
      streak: 0,
      boardState: createEmptyBoard(),
      remainingTime: TOTAL_MATCH_TIME,
      lastActionTimestamp: Date.now(),
    });

    setScreenState('playing');

    // Video 00:02: Display "3 MINUTES LEFT" banner at game start
    setTimeout(() => {
      triggerBanner('3 MINUTES LEFT', 'Fill rows & columns to score!', 'info', 1800);
    }, 400);
  };

  // Main Match Timer (180s = 3:00 Minutes)
  useEffect(() => {
    if (screenState !== 'playing' || isPaused) {
      if (matchTimerRef.current) clearInterval(matchTimerRef.current);
      return;
    }

    matchTimerRef.current = setInterval(() => {
      setRemainingTime((prev) => {
        const next = prev - 1;

        // Periodic minute announcements (Video 00:02)
        if (next === 120) {
          triggerBanner('2 MINUTES LEFT', undefined, 'info', 1500);
        } else if (next === 60) {
          triggerBanner('1 MINUTE LEFT', 'Hurry up!', 'warning', 1500);
        } else if (next === 30) {
          triggerBanner('30 SECONDS LEFT', undefined, 'warning', 1500);
        }

        if (next <= 0) {
          if (matchTimerRef.current) clearInterval(matchTimerRef.current);
          handleTimeUp();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => {
      if (matchTimerRef.current) clearInterval(matchTimerRef.current);
    };
  }, [screenState, isPaused]);

  // When Time is up or no moves remain
  const handleTimeUp = useCallback(() => {
    if (matchTimerRef.current) clearInterval(matchTimerRef.current);
    blockAudio.playClick();

    if (gameMode === 'practice') {
      // In practice, show result directly
      const newPracticeBest = Math.max(practiceBestScore, playerState.score);
      setPracticeBestScore(newPracticeBest);
      try {
        localStorage.setItem('bp_practice_best', String(newPracticeBest));
      } catch {}
      setScreenState('result');
    } else {
      // In Entry Fee Duel, show Submit Score screen (Video 01:35)
      setScreenState('submit');
    }
  }, [gameMode, playerState.score, practiceBestScore]);

  // Submit Score Handler: Match with waiting opponent or set to Pending!
  const handleSubmitScore = () => {
    setIsSubmittingScore(true);

    setTimeout(() => {
      setIsSubmittingScore(false);

      // Check if there is an existing pending match from another player with same entry fee
      const allPending: PendingMatchItem[] = (() => {
        try {
          const raw = localStorage.getItem('bp_pending_matches');
          return raw ? JSON.parse(raw) : [];
        } catch {
          return [];
        }
      })();

      // Find an opponent match with status PENDING for this entryFee and not this exact match
      const waitingOpponentIndex = allPending.findIndex(
        (m) => m.status === 'PENDING' && m.entryFee === entryFee && m.id !== activeMatchId
      );

      const currentDateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

      if (waitingOpponentIndex !== -1) {
        // MATCH FOUND! Pair them together!
        const waitingMatch = allPending[waitingOpponentIndex];
        const oppScore = waitingMatch.score;
        const oppName = waitingMatch.userName;

        let outcome: 'WON' | 'LOST' | 'DRAW' = 'WON';
        if (playerState.score > oppScore) {
          outcome = 'WON';
          finishBlockPuzzleMatch(activeMatchId, entryFee, true, prize, playerState.score);
          blockAudio.playWin();
        } else if (playerState.score < oppScore) {
          outcome = 'LOST';
          finishBlockPuzzleMatch(activeMatchId, entryFee, false, 0, playerState.score);
          blockAudio.playClick();
        } else {
          outcome = 'DRAW';
          finishBlockPuzzleMatch(activeMatchId, entryFee, false, entryFee, playerState.score, true);
          blockAudio.playClick();
        }

        // Update waiting match
        allPending[waitingOpponentIndex] = {
          ...waitingMatch,
          status: outcome === 'WON' ? 'LOST' : outcome === 'LOST' ? 'WON' : 'DRAW',
          opponentName: playerState.name,
          opponentScore: playerState.score,
        };

        // Add current user's match as resolved
        const currentMatchItem: PendingMatchItem = {
          id: activeMatchId,
          userId: user?.id || 'player_1',
          userName: user?.name || 'Player 70lol70',
          entryFee,
          prize,
          score: playerState.score,
          linesCleared: playerState.linesCleared,
          bestCombo: playerState.bestCombo,
          date: currentDateStr,
          status: outcome,
          opponentName: oppName,
          opponentScore: oppScore,
        };

        const updatedPending = [currentMatchItem, ...allPending];
        setPendingMatches(updatedPending);
        try {
          localStorage.setItem('bp_pending_matches', JSON.stringify(updatedPending));
        } catch {}

        setMatchedOpponent({
          name: oppName,
          score: oppScore,
          linesCleared: waitingMatch.linesCleared,
        });
        setMatchOutcome(outcome);
      } else {
        // NO OPPONENT WAITING YET -> Mark match as PENDING!
        const newPendingItem: PendingMatchItem = {
          id: activeMatchId,
          userId: user?.id || 'player_1',
          userName: user?.name || 'Player 70lol70',
          entryFee,
          prize,
          score: playerState.score,
          linesCleared: playerState.linesCleared,
          bestCombo: playerState.bestCombo,
          date: currentDateStr,
          status: 'PENDING',
        };

        const updatedPending = [newPendingItem, ...allPending];
        setPendingMatches(updatedPending);
        try {
          localStorage.setItem('bp_pending_matches', JSON.stringify(updatedPending));
        } catch {}

        setMatchOutcome('PENDING');
      }

      // Update Career Stats
      const newMatchesPlayed = matchesPlayed + 1;
      const newBest = Math.max(bestScore, playerState.score);
      const newTotalLines = totalLines + playerState.linesCleared;

      setMatchesPlayed(newMatchesPlayed);
      setBestScore(newBest);
      setTotalLines(newTotalLines);

      try {
        localStorage.setItem('bp_matches_played', String(newMatchesPlayed));
        localStorage.setItem('bp_best_score', String(newBest));
        localStorage.setItem('bp_total_lines', String(newTotalLines));
      } catch {}

      setScreenState('result');
    }, 600);
  };

  // Piece Selection
  const handleSelectPiece = (idx: number) => {
    blockAudio.playClick();
    const piece = pieces[idx];
    if (!piece) return;
    setSelectedPieceIndex(idx === selectedPieceIndex ? null : idx);
  };

  // Touch / Pointer Drag handling without offset drift
  const handlePiecePointerDown = (index: number, e: React.PointerEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    const piece = pieces[index];
    if (!piece) return;

    setSelectedPieceIndex(index);
    const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as React.PointerEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as React.PointerEvent).clientY;
    if (clientX && clientY) {
      setDragPointer({ x: clientX, y: clientY });
    }
  };

  // Global Drag Tracker over 10x10 Board with exact grid alignment
  useEffect(() => {
    if (screenState !== 'playing' || selectedPieceIndex === null) return;

    const handlePointerMove = (e: PointerEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as PointerEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as PointerEvent).clientY;

      if (!clientX || !clientY) return;

      setDragPointer({ x: clientX, y: clientY });

      if (!gridRef.current) return;

      const rect = gridRef.current.getBoundingClientRect();
      if (
        clientX >= rect.left &&
        clientX <= rect.right &&
        clientY >= rect.top &&
        clientY <= rect.bottom
      ) {
        const cellWidth = rect.width / BOARD_SIZE;
        const cellHeight = rect.height / BOARD_SIZE;
        const targetCol = Math.min(BOARD_SIZE - 1, Math.max(0, Math.floor((clientX - rect.left) / cellWidth)));
        const targetRow = Math.min(BOARD_SIZE - 1, Math.max(0, Math.floor((clientY - rect.top) / cellHeight)));

        const piece = pieces[selectedPieceIndex];
        if (piece) {
          const pH = piece.matrix.length;
          const pW = piece.matrix[0].length;
          const halfH = Math.floor((pH - 1) / 2);
          const halfW = Math.floor((pW - 1) / 2);
          const startRow = Math.max(0, Math.min(BOARD_SIZE - pH, targetRow - halfH));
          const startCol = Math.max(0, Math.min(BOARD_SIZE - pW, targetCol - halfW));

          if (canPlaceBlock(board, piece.matrix, startRow, startCol)) {
            setHoveredCell({ r: startRow, c: startCol });
          } else if (canPlaceBlock(board, piece.matrix, targetRow, targetCol)) {
            setHoveredCell({ r: targetRow, c: targetCol });
          } else {
            // Check adjacent snug fits
            let found = false;
            for (let dr = -1; dr <= 1 && !found; dr++) {
              for (let dc = -1; dc <= 1 && !found; dc++) {
                const tr = startRow + dr;
                const tc = startCol + dc;
                if (tr >= 0 && tr + pH <= BOARD_SIZE && tc >= 0 && tc + pW <= BOARD_SIZE) {
                  if (canPlaceBlock(board, piece.matrix, tr, tc)) {
                    setHoveredCell({ r: tr, c: tc });
                    found = true;
                  }
                }
              }
            }
            if (!found) {
              setHoveredCell({ r: startRow, c: startCol });
            }
          }
        }
      } else {
        setHoveredCell(null);
      }
    };

    const handlePointerUp = () => {
      if (hoveredCell && selectedPieceIndex !== null) {
        handleCellClick(hoveredCell.r, hoveredCell.c);
      }
      setDragPointer(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('touchend', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('touchend', handlePointerUp);
    };
  }, [screenState, selectedPieceIndex, hoveredCell, board, pieces]);

  // Preview placement computation
  const activePiece = selectedPieceIndex !== null ? pieces[selectedPieceIndex] : null;
  const previewPlacement = activePiece && hoveredCell ? {
    matrix: activePiece.matrix,
    startRow: hoveredCell.r,
    startCol: hoveredCell.c,
    isValid: canPlaceBlock(board, activePiece.matrix, hoveredCell.r, hoveredCell.c),
  } : null;

  // Handle Cell Click / Placement on 10x10 Board with smart auto-centering
  const handleCellClick = (r: number, c: number) => {
    if (selectedPieceIndex === null || !activePiece) return;

    let placeR = r;
    let placeC = c;
    const pH = activePiece.matrix.length;
    const pW = activePiece.matrix[0].length;

    if (canPlaceBlock(board, activePiece.matrix, r, c)) {
      placeR = r;
      placeC = c;
    } else {
      const halfH = Math.floor((pH - 1) / 2);
      const halfW = Math.floor((pW - 1) / 2);
      const centerR = Math.max(0, Math.min(BOARD_SIZE - pH, r - halfH));
      const centerC = Math.max(0, Math.min(BOARD_SIZE - pW, c - halfW));

      if (canPlaceBlock(board, activePiece.matrix, centerR, centerC)) {
        placeR = centerR;
        placeC = centerC;
      } else {
        let found = false;
        for (let dr = -1; dr <= 1 && !found; dr++) {
          for (let dc = -1; dc <= 1 && !found; dc++) {
            const nr = centerR + dr;
            const nc = centerC + dc;
            if (nr >= 0 && nr + pH <= BOARD_SIZE && nc >= 0 && nc + pW <= BOARD_SIZE) {
              if (canPlaceBlock(board, activePiece.matrix, nr, nc)) {
                placeR = nr;
                placeC = nc;
                found = true;
              }
            }
          }
        }
        if (!found) {
          blockAudio.triggerHaptic(25);
          return;
        }
      }
    }

    // Place block on board (using color code)
    blockAudio.playPlace();
    const styleVal = ((selectedPieceIndex + 1) % 6) + 1;
    const placedBoard = placeBlockOnBoard(board, activePiece.matrix, placeR, placeC, styleVal);
    
    // Check line clears
    const { newBoard, clearedRows, clearedCols, totalLinesCleared } = checkAndClearLines(placedBoard);

    // Calculate score
    const tileCount = getTileCount(activePiece.matrix);
    const { pointsEarned, newCombo, newStreak, bannerType } = calculateMoveScore(
      totalLinesCleared,
      tileCount,
      playerState.combo,
      playerState.streak
    );

    // Visual score popup at placement location
    if (gridRef.current) {
      const rect = gridRef.current.getBoundingClientRect();
      const cellW = rect.width / BOARD_SIZE;
      const cellH = rect.height / BOARD_SIZE;
      const popupX = placeC * cellW + cellW / 2;
      const popupY = placeR * cellH + cellH / 2;
      
      triggerFloatingScore(`+${pointsEarned}`, popupX, popupY, totalLinesCleared > 0 ? '#38bdf8' : '#fde047', bannerType);
    }

    if (totalLinesCleared > 0) {
      setClearingRows(clearedRows);
      setClearingCols(clearedCols);
      blockAudio.playLineClear(playerState.combo + 1);

      if (bannerType === 'POWER_BOLT') {
        blockAudio.playLightning();
        triggerBanner('POWER BOLT', '+200 PTS', 'bolt', 1400);
      } else if (bannerType === 'FIRE_STREAK') {
        blockAudio.playWin();
        triggerBanner('FIRE STREAK', `+${pointsEarned} PTS BONUS`, 'fire', 1600);
      }

      setTimeout(() => {
        setClearingRows([]);
        setClearingCols([]);
        setBoard(newBoard);
      }, 200);
    } else {
      setBoard(placedBoard);
    }

    consumePiece(selectedPieceIndex, pointsEarned, totalLinesCleared, newCombo, newStreak, totalLinesCleared > 0 ? newBoard : placedBoard);
  };

  // Consume used piece & check if tray is empty
  const consumePiece = (
    pieceIdx: number, 
    pts: number, 
    linesCount: number, 
    newCombo: number = 0, 
    newStreak: number = 0, 
    currentBoard: number[][] = board
  ) => {
    const updatedPieces = [...pieces];
    updatedPieces[pieceIdx] = null;
    setSelectedPieceIndex(null);
    setPieces(updatedPieces);

    // Update Player State
    setPlayerState((prev) => {
      const newScore = prev.score + pts;
      const newLines = prev.linesCleared + linesCount;
      const newBestCombo = Math.max(prev.bestCombo, newCombo);

      return {
        ...prev,
        score: newScore,
        linesCleared: newLines,
        combo: newCombo,
        bestCombo: newBestCombo,
        streak: newStreak,
        lastActionTimestamp: Date.now(),
      };
    });

    // If all 3 pieces are consumed, generate next trio
    const allConsumed = updatedPieces.every((p) => p === null);
    let nextPieces = updatedPieces;

    if (allConsumed) {
      const nextTrioIdx = trioIndex + 1;
      setTrioIndex(nextTrioIdx);
      nextPieces = generateBlockTrio(matchSeed, nextTrioIdx, difficulty, false);
      setPieces(nextPieces);
    }

    // Check if any legal move remains on 10x10 board
    const hasMove = hasAnyLegalMove(currentBoard, nextPieces);
    if (!hasMove && !allConsumed) {
      setIsOutOfMoves(true);
      triggerBanner('YOU ARE OUT OF MOVES', 'No shapes fit on board', 'warning', 2000);
      blockAudio.triggerHaptic([40, 50, 60]);

      setTimeout(() => {
        handleTimeUp();
      }, 1600);
    }
  };

  // Can place map for tray feedback
  const canPlaceMap = pieces.map((p) => {
    if (!p) return false;
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        if (canPlaceBlock(board, p.matrix, r, c)) return true;
      }
    }
    return false;
  });

  return (
    <div className="min-h-screen bg-[#070b18] text-white flex flex-col justify-between max-w-md mx-auto relative select-none">
      {/* 1. LOBBY VIEW */}
      {screenState === 'lobby' && (
        <BlockLobbyView
          userRating={rating}
          userBestScore={bestScore}
          userWinStreak={winStreak}
          matchesPlayed={matchesPlayed}
          userBalance={user?.gamingBalance || 0}
          pendingMatchesCount={activePendingCount}
          isAdmin={Boolean(user?.isAdmin || user?.phone === '01832822322')}
          onStartDuel={handleStartDuel}
          onStartPractice={handleStartPractice}
          onOpenPendingMatches={() => setShowPendingModal(true)}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          onOpenHistory={() => setShowHistory(true)}
          onOpenProfile={() => setShowProfile(true)}
          onOpenRules={() => setShowRules(true)}
          onOpenAndroidCode={() => setShowAndroidCode(true)}
          onBackToHome={() => setCurrentTab('home')}
          onGoToWallet={() => setCurrentTab('wallet')}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* 2. MATCHMAKING SCREEN (From Video 00:00 - Finding Opponent / VS Card) */}
      {screenState === 'matchmaking' && (
        <div className="flex-1 flex flex-col justify-between p-5 text-center relative overflow-hidden animate-fade-in">
          {/* Ambient Lightning Backdrop */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#0b1230] via-[#070b1a] to-[#04060e] -z-10" />
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-64 h-64 bg-cyan-500/15 rounded-full blur-3xl -z-10" />

          {/* Top Bar */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => {
                refundBlockPuzzleMatch(activeMatchId, entryFee);
                setScreenState('lobby');
              }}
              className="p-2 rounded-xl bg-[#101738] border border-indigo-900/60 text-slate-300 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-black text-amber-400 uppercase tracking-widest">
              MATCHMAKING
            </span>
            <div className="w-8" />
          </div>

          {/* Player VS Opponent Cards */}
          <div className="space-y-6 my-auto">
            {/* Player Card */}
            <div className="bg-[#0e1635] p-4 rounded-3xl border-2 border-indigo-500/60 shadow-2xl flex items-center justify-between max-w-xs mx-auto">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 p-0.5 shadow-lg">
                  <div className="w-full h-full bg-[#0d1226] rounded-[14px] flex items-center justify-center text-2xl">
                    😎
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-[10px] font-bold text-amber-400 uppercase bg-amber-400/10 px-1.5 py-0.5 rounded">
                    Novice • 🇧🇩 BD
                  </span>
                  <h3 className="text-base font-black text-white mt-0.5">
                    {user?.name || '70lol70'}
                  </h3>
                  <span className="text-[11px] text-slate-300 font-semibold">
                    Best: {bestScore} pts
                  </span>
                </div>
              </div>
            </div>

            {/* VS Badge */}
            <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-r from-red-500 to-amber-500 p-0.5 shadow-xl flex items-center justify-center animate-pulse">
              <div className="w-full h-full bg-[#080d20] rounded-full flex items-center justify-center font-black text-sm text-amber-300">
                VS
              </div>
            </div>

            {/* Finding Opponent Mystery Card (Matching Video 00:00) */}
            <div className="bg-[#0b1028]/80 p-4 rounded-3xl border border-indigo-900/60 border-dashed max-w-xs mx-auto text-center space-y-1">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-[#101735] flex items-center justify-center text-xl text-slate-500">
                ❓
              </div>
              <p className="text-xs font-bold text-slate-300">
                Play now, we're finding your opponent
              </p>
              <span className="text-[10px] text-slate-300">
                Score will be submitted automatically at match end
              </span>
            </div>
          </div>

          {/* Bottom Begin Match Action */}
          <div className="space-y-3 max-w-xs mx-auto w-full">
            <div className="bg-[#0c122a] px-4 py-2 rounded-xl border border-indigo-900/60 flex items-center justify-between text-xs">
              <span className="text-slate-300">GUARANTEED PRIZE</span>
              <span className="text-amber-400 font-black text-sm">৳{prize}</span>
            </div>

            <button
              onClick={() => startCountdown('duel')}
              className="w-full py-4 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-black text-base uppercase tracking-wider rounded-2xl shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 active:scale-95 transition-transform"
            >
              <span>BEGIN MATCH NOW</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. 3-SECOND COUNTDOWN OVERLAY */}
      {screenState === 'countdown' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4 animate-fade-in">
          <span className="text-sm font-black text-cyan-400 uppercase tracking-widest">
            GET READY!
          </span>
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-tr from-cyan-400 to-indigo-600 p-1 shadow-2xl shadow-cyan-500/30 flex items-center justify-center animate-pulse">
            <div className="w-full h-full bg-[#080d20] rounded-[22px] flex items-center justify-center">
              <span className="text-6xl font-black text-white font-mono">
                {countdown}
              </span>
            </div>
          </div>
          <span className="text-xs text-slate-300 font-semibold">
            {gameMode === 'duel' ? `এন্ট্রি ফি: ৳${entryFee} • ৩ মিনিটে সর্বোচ্চ স্কোর করুন!` : 'প্র্যাকটিস মোড চালু হচ্ছে...'}
          </span>
        </div>
      )}

      {/* 4. ACTIVE PLAYING GAMEPLAY SCREEN (Skillz Block Blitz Video UI) */}
      {screenState === 'playing' && (
        <div className="pb-8 pt-2 px-3 space-y-2 relative flex flex-col justify-between flex-1">
          {/* Top HUD: 3:00 Clock on Left, Center Trophy Score Pill, Help on Right */}
          <BlockHud
            mode={gameMode}
            difficulty={difficulty}
            entryFee={entryFee}
            prize={prize}
            player={playerState}
            remainingTime={remainingTime}
            totalTime={TOTAL_MATCH_TIME}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onPause={() => setIsPaused(true)}
            onOpenRules={() => setShowRules(true)}
          />

          {/* 10x10 Board Grid */}
          <BlockBoardView
            board={board}
            previewPlacement={previewPlacement}
            clearingRows={clearingRows}
            clearingCols={clearingCols}
            selectedPiece={activePiece}
            floatingScores={floatingScores}
            bannerAlert={bannerAlert}
            isOutOfMoves={isOutOfMoves}
            onCellClick={handleCellClick}
            onCellHover={(r, c) => setHoveredCell({ r, c })}
            onMouseLeave={() => setHoveredCell(null)}
            gridRef={gridRef}
          />

          {/* 3-Block Tray */}
          <BlockTrayView
            pieces={pieces}
            selectedPieceIndex={selectedPieceIndex}
            onSelectPiece={handleSelectPiece}
            canPlaceMap={canPlaceMap}
            onPiecePointerDown={handlePiecePointerDown}
          />

          {/* Bottom Bar: Left Pause (||) and Right Speaker Mute/Unmute */}
          <div className="flex items-center justify-between px-3 pt-1">
            <button
              id="block-bottom-pause-btn"
              type="button"
              onClick={() => setIsPaused(true)}
              className="w-10 h-10 rounded-2xl bg-[#0f1738] hover:bg-[#15204d] border border-[#1d2b5c] flex items-center justify-center text-slate-300 hover:text-white shadow-lg active:scale-95 transition-transform"
              title="Pause Game"
            >
              <Pause className="w-5 h-5 fill-current" />
            </button>

            <button
              id="block-bottom-sound-btn"
              type="button"
              onClick={handleToggleMute}
              className="w-10 h-10 rounded-2xl bg-[#0f1738] hover:bg-[#15204d] border border-[#1d2b5c] flex items-center justify-center text-slate-300 hover:text-white shadow-lg active:scale-95 transition-transform"
              title="Toggle Sound"
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-amber-400" />}
            </button>
          </div>

          {/* Floating Drag Piece above touch pointer */}
          {dragPointer && activePiece && (
            <div
              className="fixed pointer-events-none z-50 transform -translate-x-1/2 -translate-y-1/2 opacity-90 scale-110 drop-shadow-2xl"
              style={{
                left: `${dragPointer.x}px`,
                top: `${dragPointer.y}px`,
              }}
            >
              {/* Touch Anchor glow */}
              <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 w-10 h-10 rounded-full border-2 border-cyan-400/80 bg-cyan-400/20 animate-ping pointer-events-none" />

              <div className="flex flex-col items-center justify-center gap-1 bg-[#090e24]/90 p-2 rounded-xl border border-cyan-400/80 shadow-2xl">
                {activePiece.matrix.map((row, r) => (
                  <div key={r} className="flex items-center gap-1">
                    {row.map((cell, c) => (
                      <div
                        key={c}
                        className={`w-6 h-6 rounded-[4px] border-t border-l border-white/50 border-b-2 border-r-2 border-black/50 ${
                          cell !== 0 ? '' : 'opacity-0'
                        }`}
                        style={{
                          backgroundColor: cell !== 0 ? activePiece.color : 'transparent',
                          borderColor: cell !== 0 ? activePiece.accentColor : 'transparent',
                        }}
                      />
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. PAUSE MODAL */}
      {isPaused && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
          <div className="bg-[#0b1028] border-2 border-[#1f2d63] rounded-3xl p-6 max-w-xs w-full shadow-2xl space-y-4 text-center">
            <h3 className="text-xl font-black text-white uppercase tracking-wider font-mono">
              GAME PAUSED
            </h3>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-sm uppercase rounded-xl flex items-center justify-center gap-2 active:scale-95"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>RESUME MATCH</span>
              </button>

              <button
                onClick={() => {
                  setShowRules(true);
                }}
                className="w-full py-2.5 bg-[#12193d] border border-[#213069] text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 hover:text-white active:scale-95"
              >
                <HelpCircle className="w-4 h-4" />
                <span>HOW TO PLAY</span>
              </button>

              <button
                onClick={() => {
                  setIsPaused(false);
                  handleTimeUp();
                }}
                className="w-full py-2.5 bg-red-500/20 border border-red-500/40 text-red-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 active:scale-95"
              >
                <span>FORFEIT & SUBMIT</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. SUBMIT SCORE MODAL (From Video 01:35 - Game Over & Submit) */}
      {screenState === 'submit' && (
        <BlockSubmitModal
          player={playerState}
          entryFee={entryFee}
          prize={prize}
          bestScore={bestScore}
          isSubmitting={isSubmittingScore}
          onSubmit={handleSubmitScore}
        />
      )}

      {/* 7. RESULT MODAL */}
      {screenState === 'result' && (
        <BlockResultModal
          mode={gameMode}
          entryFee={entryFee}
          prize={prize}
          player={playerState}
          opponent={matchedOpponent}
          isPractice={gameMode === 'practice'}
          isPending={matchOutcome === 'PENDING'}
          outcome={matchOutcome}
          onPlayAgain={() => {
            if (gameMode === 'practice') {
              handleStartPractice(difficulty);
            } else {
              handleStartDuel(entryFee, prize);
            }
          }}
          onGoHome={() => setScreenState('lobby')}
          onViewPendingMatches={() => {
            setScreenState('lobby');
            setShowPendingModal(true);
          }}
          onViewHistory={() => {
            setShowHistory(true);
          }}
        />
      )}

      {/* MODALS */}
      {showPendingModal && (
        <BlockPendingMatchesModal
          pendingMatches={pendingMatches}
          onClose={() => setShowPendingModal(false)}
          onRefresh={() => {
            try {
              const raw = localStorage.getItem('bp_pending_matches');
              setPendingMatches(raw ? JSON.parse(raw) : []);
            } catch {}
          }}
        />
      )}

      {showProfile && (
        <BlockProfileModal
          userName={user?.name || 'Player 70lol70'}
          avatar="😎"
          rating={rating}
          bestScore={bestScore}
          matchesWon={matchesWon}
          matchesLost={matchesLost}
          totalLines={totalLines}
          bestCombo={playerState.bestCombo || 4}
          practiceBestScore={practiceBestScore}
          onClose={() => setShowProfile(false)}
        />
      )}

      {showLeaderboard && (
        <BlockLeaderboardModal
          currentUserId={user?.id || 'player_1'}
          onClose={() => setShowLeaderboard(false)}
        />
      )}

      {showHistory && (
        <BlockMatchHistoryModal onClose={() => setShowHistory(false)} />
      )}

      {showRules && (
        <BlockRulesModal onClose={() => setShowRules(false)} />
      )}

      {showAndroidCode && (
        <AndroidCodeViewerModal onClose={() => setShowAndroidCode(false)} />
      )}
    </div>
  );
};
