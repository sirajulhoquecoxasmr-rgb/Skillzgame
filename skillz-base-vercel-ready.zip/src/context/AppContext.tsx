import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  Match, 
  Transaction, 
  TabType, 
  MatchCategory, 
  DepositRequest, 
  WithdrawRequest, 
  ResultSubmission, 
  PaymentSettings 
} from '../types';
import { 
  initialUser, 
  initialMatches, 
  initialTransactions, 
  initialRegisteredUsers,
  initialDepositRequests,
  initialWithdrawRequests,
  initialResultSubmissions,
  initialPaymentSettings
} from '../data/mockData';
import confetti from 'canvas-confetti';

interface AppContextType {
  user: User;
  isLoggedIn: boolean;
  login: (phone: string, pass: string) => { success: boolean; message?: string };
  register: (name: string, phone: string, pass: string, refCode?: string) => { success: boolean; message?: string };
  logout: () => void;
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  matches: Match[];
  matchFilter: MatchCategory;
  setMatchFilter: (cat: MatchCategory) => void;
  transactions: Transaction[];
  activeModal: string | null;
  openModal: (modalName: string, payload?: any) => void;
  closeModal: () => void;
  modalPayload: any;
  joinMatch: (matchId: string, ludoKingName: string) => { success: boolean; message: string };
  depositMoney: (method: 'bKash' | 'Nagad' | 'Rocket' | 'Upay', amount: number, senderNumber: string, trxId: string) => boolean;
  withdrawMoney: (method: 'bKash' | 'Nagad' | 'Rocket', accountType: 'Personal' | 'Agent', accountNumber: string, amount: number) => { success: boolean; message: string };
  transferWinningBalance: (amount: number) => { success: boolean; message: string };
  submitResultScreenshot: (matchId: string, roomCode: string, image?: string) => { success: boolean; message: string };
  refreshMatches: () => void;
  isRefreshing: boolean;
  playAutoLudoRound: (betAmount: number) => Promise<{ won: boolean; prize: number; userRoll: number; botRoll: number }>;
  startLiveLudoMatch: (entryFee: number, modeTitle: string) => { success: boolean; message: string; matchId?: string };
  finishLiveLudoMatch: (matchId: string, entryFee: number, won: boolean, prize: number, opponentName: string, modeTitle: string) => void;
  refundLiveLudoMatch: (matchId: string, entryFee: number, reason?: string) => void;
  startBlockPuzzleMatch: (entryFee: number) => { success: boolean; message: string; matchId?: string };
  finishBlockPuzzleMatch: (matchId: string, entryFee: number, won: boolean, prize: number, score: number, isDraw?: boolean) => void;
  refundBlockPuzzleMatch: (matchId: string, entryFee: number, reason?: string) => void;
  
  // Admin Context
  isAdminMode: boolean;
  setIsAdminMode: (val: boolean) => void;
  registeredUsers: User[];
  depositRequests: DepositRequest[];
  withdrawRequests: WithdrawRequest[];
  resultSubmissions: ResultSubmission[];
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: Partial<PaymentSettings>) => void;
  createMatch: (match: Partial<Match>) => void;
  setMatchRoomCode: (matchId: string, roomCode: string) => boolean;
  cancelMatchAndRefund: (matchId: string, reason?: string) => boolean;
  deleteMatch: (matchId: string) => boolean;
  approveDepositRequest: (requestId: string) => { success: boolean; message: string };
  rejectDepositRequest: (requestId: string, reason?: string) => { success: boolean; message: string };
  approveWithdrawRequest: (requestId: string, adminTrxId?: string) => { success: boolean; message: string };
  rejectWithdrawRequest: (requestId: string, reason?: string) => { success: boolean; message: string };
  approveResultSubmission: (submissionId: string) => { success: boolean; message: string };
  rejectResultSubmission: (submissionId: string, reason?: string) => { success: boolean; message: string };
  adjustUserBalance: (userId: string, balanceType: 'gaming' | 'winning', amount: number, isAddition: boolean, note?: string) => boolean;
  toggleUserBan: (userId: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(() => {
    const saved = localStorage.getItem('lx_ludo_user');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Clean up previous 50.00 default if user hasn't played matches or deposited
      if (parsed.gamingBalance === 50 && (!parsed.matchesPlayed || parsed.matchesPlayed === 0)) {
        parsed.gamingBalance = 0.00;
      }
      if (parsed.phone === '01832822322') {
        parsed.isAdmin = true;
        parsed.password = 'Agriments@09';
      }
      localStorage.setItem('lx_ludo_user', JSON.stringify(parsed));
      return parsed;
    }
    return initialUser;
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    const saved = localStorage.getItem('lx_ludo_auth');
    return saved === 'true';
  });

  const [isAdminMode, setIsAdminMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('lx_ludo_admin_mode');
    return saved === 'true';
  });

  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [matchFilter, setMatchFilter] = useState<MatchCategory>('special');

  const [matches, setMatches] = useState<Match[]>(() => {
    const saved = localStorage.getItem('lx_ludo_matches');
    return saved ? JSON.parse(saved) : initialMatches;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('lx_ludo_transactions');
    return saved ? JSON.parse(saved) : initialTransactions;
  });

  const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('lx_ludo_users_list');
    if (saved) {
      const parsed: User[] = JSON.parse(saved);
      const updated = parsed.map(u => {
        if (u.phone === '01832822322') {
          return { ...u, isAdmin: true, password: 'Agriments@09' };
        }
        return u;
      });
      if (!updated.some(u => u.phone === '01832822322')) {
        updated.unshift(initialUser);
      }
      localStorage.setItem('lx_ludo_users_list', JSON.stringify(updated));
      return updated;
    }
    return initialRegisteredUsers;
  });

  const [depositRequests, setDepositRequests] = useState<DepositRequest[]>(() => {
    const saved = localStorage.getItem('lx_ludo_deposit_requests');
    return saved ? JSON.parse(saved) : initialDepositRequests;
  });

  const [withdrawRequests, setWithdrawRequests] = useState<WithdrawRequest[]>(() => {
    const saved = localStorage.getItem('lx_ludo_withdraw_requests');
    return saved ? JSON.parse(saved) : initialWithdrawRequests;
  });

  const [resultSubmissions, setResultSubmissions] = useState<ResultSubmission[]>(() => {
    const saved = localStorage.getItem('lx_ludo_result_submissions');
    return saved ? JSON.parse(saved) : initialResultSubmissions;
  });

  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    const saved = localStorage.getItem('lx_ludo_payment_settings');
    if (saved) {
      const parsed: PaymentSettings = JSON.parse(saved);
      if (parsed.marqueeNotice && parsed.marqueeNotice.includes('LX LUDO')) {
        parsed.marqueeNotice = parsed.marqueeNotice.replace(/LX LUDO/g, 'Skillzgame');
      }
      if (parsed.popupNoticeText && parsed.popupNoticeText.includes('LX Ludo')) {
        parsed.popupNoticeText = initialPaymentSettings.popupNoticeText;
        parsed.popupNoticeTitle = initialPaymentSettings.popupNoticeTitle;
      }
      localStorage.setItem('lx_ludo_payment_settings', JSON.stringify(parsed));
      return parsed;
    }
    return initialPaymentSettings;
  });

  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [modalPayload, setModalPayload] = useState<any>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('lx_ludo_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_auth', String(isLoggedIn));
  }, [isLoggedIn]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_admin_mode', String(isAdminMode));
  }, [isAdminMode]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_matches', JSON.stringify(matches));
  }, [matches]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_users_list', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_deposit_requests', JSON.stringify(depositRequests));
  }, [depositRequests]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_withdraw_requests', JSON.stringify(withdrawRequests));
  }, [withdrawRequests]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_result_submissions', JSON.stringify(resultSubmissions));
  }, [resultSubmissions]);

  useEffect(() => {
    localStorage.setItem('lx_ludo_payment_settings', JSON.stringify(paymentSettings));
  }, [paymentSettings]);

  const login = (phone: string, pass: string): { success: boolean; message?: string } => {
    const cleanPhone = phone.trim();
    const cleanPass = pass.trim();

    if (cleanPhone.length < 10) {
      return { success: false, message: 'সঠিক মোবাইল নম্বর দিন (কমপক্ষে ১০ ডিজিট)' };
    }
    if (cleanPass.length < 4) {
      return { success: false, message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে' };
    }

    // Find registered user by phone
    const existing = registeredUsers.find(u => u.phone === cleanPhone);
    if (!existing) {
      return { 
        success: false, 
        message: 'এই ফোন নম্বরে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে "রেজিস্টার" ট্যাবে ক্লিক করে নতুন অ্যাকাউন্ট খুলুন।' 
      };
    }

    if (existing.isBanned) {
      return { success: false, message: 'আপনার একাউন্টটি সাময়িকভাবে ব্যান রয়েছে। এডমিনের সাথে যোগাযোগ করুন।' };
    }

    // Verify Password
    if (existing.password && existing.password !== cleanPass) {
      return { success: false, message: 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিয়ে লগইন করুন।' };
    }

    // Logged in successfully
    setUser(existing);
    setIsLoggedIn(true);
    localStorage.setItem('lx_ludo_user', JSON.stringify(existing));
    localStorage.setItem('lx_ludo_auth', 'true');
    setActiveModal(null);
    return { success: true };
  };

  const register = (name: string, phone: string, pass: string, refCode?: string): { success: boolean; message?: string } => {
    const cleanName = name.trim();
    const cleanPhone = phone.trim();
    const cleanPass = pass.trim();

    if (!cleanName) {
      return { success: false, message: 'আপনার পূর্ণ নাম লিখুন' };
    }
    if (cleanPhone.length < 10) {
      return { success: false, message: 'সঠিক মোবাইল নম্বর দিন (কমপক্ষে ১০ ডিজিট)' };
    }
    if (cleanPass.length < 4) {
      return { success: false, message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে' };
    }

    // Strictly enforce: Phone number can ONLY be registered once!
    const phoneAlreadyExists = registeredUsers.some(u => u.phone === cleanPhone);
    if (phoneAlreadyExists) {
      return { 
        success: false, 
        message: 'এই ফোন নম্বর দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা রয়েছে! পুনরায় একাউন্ট খোলা যাবে না, অনুগ্রহ করে "লগইন করুন"।' 
      };
    }

    // New user is strictly regular user (never admin)
    const newUser: User = {
      id: `user_${Date.now()}`,
      name: cleanName,
      phone: cleanPhone,
      password: cleanPass,
      isAdmin: false, // Strictly false for all new registrations
      ludoKingName: cleanName,
      gamingBalance: 0.00,
      winningBalance: 0.00,
      matchesPlayed: 0,
      totalWinnings: 0.00,
      referralCode: `LX${Math.floor(1000 + Math.random() * 9000)}`,
      referredBy: refCode?.trim() || undefined,
      joinedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    };

    setUser(newUser);
    setRegisteredUsers(prev => [newUser, ...prev]);
    setIsLoggedIn(true);
    localStorage.setItem('lx_ludo_user', JSON.stringify(newUser));
    localStorage.setItem('lx_ludo_auth', 'true');
    setActiveModal('notice');
    return { success: true };
  };

  const logout = () => {
    setIsLoggedIn(false);
    setCurrentTab('home');
  };

  const openModal = (modalName: string, payload: any = null) => {
    setActiveModal(modalName);
    setModalPayload(payload);
  };

  const closeModal = () => {
    setActiveModal(null);
    setModalPayload(null);
  };

  const refreshMatches = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  // Join match
  const joinMatch = (matchId: string, ludoKingName: string): { success: boolean; message: string } => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return { success: false, message: 'ম্যাচ পাওয়া যায়নি।' };
    if (match.joinedSeats >= match.totalSeats) {
      return { success: false, message: 'দুঃখিত, এই ম্যাচটি ইতিমধ্যে পূর্ণ (Seat Full)!' };
    }
    if (user.gamingBalance < match.entryFee) {
      return { success: false, message: 'আপনার পর্যাপ্ত গেমিং ব্যালেন্স নেই! দয়া করে ডিপোজিট করুন।' };
    }

    const alreadyJoined = match.joinedPlayers.some(p => p.userId === user.id || p.phone === user.phone);
    if (alreadyJoined) {
      return { success: false, message: 'আপনি ইতিমধ্যে এই ম্যাচে জয়েন করেছেন।' };
    }

    // Deduct entry fee
    const updatedUser = {
      ...user,
      gamingBalance: user.gamingBalance - match.entryFee,
      matchesPlayed: user.matchesPlayed + 1,
      ludoKingName: ludoKingName || user.ludoKingName,
    };
    setUser(updatedUser);

    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    // Update match seats
    const newJoined = match.joinedSeats + 1;
    const isNowFull = newJoined >= match.totalSeats;
    const newStatus = isNowFull 
      ? (match.roomCode ? ('ready_to_play' as const) : ('waiting_room_id' as const))
      : ('open' as const);

    const updatedMatches = matches.map(m => {
      if (m.id === matchId) {
        return {
          ...m,
          joinedSeats: newJoined,
          status: newStatus,
          joinedPlayers: [
            ...m.joinedPlayers,
            { 
              userId: user.id,
              name: user.name, 
              phone: user.phone,
              ludoKingName: ludoKingName || user.ludoKingName, 
              joinedAt: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) 
            }
          ]
        };
      }
      return m;
    });
    setMatches(updatedMatches);

    // Create Match Transaction
    const newTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'match_loss',
      title: 'Match Join Fee',
      subtitle: `via ${match.boardType}`,
      amount: -match.entryFee,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      matchId: `#${match.matchNo}`,
      roomCode: match.roomCode,
      category: 'match',
    };
    setTransactions(prev => [newTrx, ...prev]);

    return { 
      success: true, 
      message: isNowFull 
        ? (match.roomCode 
            ? `ম্যাচ #${match.matchNo} তে জয়েন সম্পন্ন! রুম কোড: ${match.roomCode}` 
            : `ম্যাচ #${match.matchNo} তে জয়েন সম্পন্ন! এডমিন শীঘ্রই Ludo King রুম আইডি দিবেন।`)
        : `ম্যাচ #${match.matchNo} তে সফলভাবে জয়েন করেছেন! ২য় প্লেয়ার জয়েনের অপেক্ষায়।`
    };
  };

  // User submits Deposit Request
  const depositMoney = (method: 'bKash' | 'Nagad' | 'Rocket' | 'Upay', amount: number, senderNumber: string, trxId: string): boolean => {
    if (amount <= 0 || !senderNumber || !trxId) return false;

    const newReq: DepositRequest = {
      id: `dep_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      method,
      amount,
      senderNumber,
      trxId: trxId.toUpperCase().trim(),
      timestamp: 'এখনই (' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ')',
      status: 'PENDING',
    };

    setDepositRequests(prev => [newReq, ...prev]);

    const newTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(10000 + Math.random() * 90000)}`,
      type: 'deposit',
      title: 'Deposit Request',
      subtitle: `via ${method.toLowerCase()} (যাচাইধীন)`,
      amount: amount,
      status: 'PENDING',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      trxId: trxId.toUpperCase().trim(),
      paymentMethod: method,
      category: 'deposit',
    };

    setTransactions(prev => [newTrx, ...prev]);
    return true;
  };

  // User submits Withdraw Request
  const withdrawMoney = (method: 'bKash' | 'Nagad' | 'Rocket', accountType: 'Personal' | 'Agent', accountNumber: string, amount: number): { success: boolean; message: string } => {
    if (amount < 100) {
      return { success: false, message: 'সর্বনিম্ন উইথড্রয়াল পরিমাণ ৳১০০ টাকা।' };
    }
    if (user.winningBalance < amount) {
      return { success: false, message: 'আপনার উইনিং ব্যালেন্স অপর্যাপ্ত!' };
    }

    // Deduct winning balance immediately to prevent double withdrawal
    const updatedUser = {
      ...user,
      winningBalance: user.winningBalance - amount,
    };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    const newReq: WithdrawRequest = {
      id: `wth_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      method,
      accountType,
      accountNumber,
      amount,
      timestamp: 'এখনই (' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ')',
      status: 'PENDING',
    };
    setWithdrawRequests(prev => [newReq, ...prev]);

    const newTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(10000 + Math.random() * 90000)}`,
      type: 'withdraw',
      title: 'Withdraw Request',
      subtitle: `via ${method.toLowerCase()} (${accountType}) - অপেক্ষমাণ`,
      amount: -amount,
      status: 'PENDING',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      paymentMethod: method,
      trxId: `WTH${Math.floor(100000 + Math.random() * 900000)}`,
      category: 'withdraw',
    };

    setTransactions(prev => [newTrx, ...prev]);
    return { success: true, message: `৳${amount} টাকা উইথড্রয়াল রিকোয়েস্ট জমা হয়েছে। এডমিন যাচাই করে টাকা পাঠিয়ে দিবে।` };
  };

  // Transfer winning to gaming
  const transferWinningBalance = (amount: number): { success: boolean; message: string } => {
    if (amount <= 0) return { success: false, message: 'সঠিক পরিমাণ লিখুন।' };
    if (user.winningBalance < amount) return { success: false, message: 'পর্যাপ্ত উইনিং ব্যালেন্স নেই।' };

    const updatedUser = {
      ...user,
      winningBalance: user.winningBalance - amount,
      gamingBalance: user.gamingBalance + amount,
    };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    const newTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(10000 + Math.random() * 90000)}`,
      type: 'admin_add',
      title: 'Balance Transfer',
      subtitle: 'Winning to Gaming Balance',
      amount: amount,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'admin',
    };

    setTransactions(prev => [newTrx, ...prev]);
    return { success: true, message: `৳${amount} টাকা গেমিং ব্যালেন্সে সফলভাবে ট্রান্সফার করা হয়েছে!` };
  };

  // User submits Screenshot Result
  const submitResultScreenshot = (matchId: string, roomCode: string, image?: string): { success: boolean; message: string } => {
    if (!roomCode.trim()) return { success: false, message: 'দয়া করে সঠিক Room ID প্রদান করুন।' };

    const match = matches.find(m => m.id === matchId || m.roomCode === roomCode || m.matchNo === matchId);
    const prize = match ? match.totalPrize : 400;

    const newSub: ResultSubmission = {
      id: `res_${Date.now()}`,
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      ludoKingName: user.ludoKingName,
      matchId: match?.id,
      matchNo: match?.matchNo || 'Custom',
      roomCode: roomCode.trim(),
      imageUrl: image || 'https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?w=600&auto=format&fit=crop&q=80',
      prizeAmount: prize,
      status: 'PENDING',
      submittedAt: 'এখনই (' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ')',
    };

    setResultSubmissions(prev => [newSub, ...prev]);

    return {
      success: true,
      message: 'রেজাল্ট স্ক্রিনশট এডমিন প্যানেলে জমা হয়েছে! এডমিন যাচাই করে দ্রুত বিজয়ী হিসেবে প্রাইজ ব্যালেন্স যোগ করে দিবেন।'
    };
  };

  // Auto Ludo mini-game round
  const playAutoLudoRound = async (betAmount: number) => {
    if (user.gamingBalance < betAmount) {
      throw new Error('অপর্যাপ্ত গেমিং ব্যালেন্স! দয়া করে ডিপোজিট করুন।');
    }

    const updatedUser = {
      ...user,
      gamingBalance: user.gamingBalance - betAmount,
      matchesPlayed: user.matchesPlayed + 1
    };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    const userRoll = Math.floor(Math.random() * 6) + 1;
    const botRoll = Math.floor(Math.random() * 6) + 1;
    const won = userRoll > botRoll;
    const prize = won ? Math.round(betAmount * 1.85) : 0;

    if (won) {
      const wonUser = {
        ...updatedUser,
        winningBalance: updatedUser.winningBalance + prize,
        totalWinnings: updatedUser.totalWinnings + prize,
      };
      setUser(wonUser);
      setRegisteredUsers(prev => prev.map(u => u.id === user.id ? wonUser : u));

      const newTrx: Transaction = {
        id: `t_${Date.now()}`,
        trxNumber: `#${Math.floor(100000 + Math.random() * 900000)}`,
        type: 'match_win',
        title: 'Auto Ludo Win',
        subtitle: `Roll ${userRoll} vs ${botRoll}`,
        amount: prize,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [newTrx, ...prev]);
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.5 } });
    } else {
      const newTrx: Transaction = {
        id: `t_${Date.now()}`,
        trxNumber: `#${Math.floor(100000 + Math.random() * 900000)}`,
        type: 'match_loss',
        title: 'Auto Ludo Loss',
        subtitle: `Roll ${userRoll} vs ${botRoll}`,
        amount: -betAmount,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [newTrx, ...prev]);
    }

    return { won, prize, userRoll, botRoll };
  };

  // 1v1 Head-to-Head Live Ludo Match Engine Handlers
  const startLiveLudoMatch = (entryFee: number, modeTitle: string): { success: boolean; message: string; matchId?: string } => {
    if (user.gamingBalance < entryFee) {
      return { success: false, message: 'অপর্যাপ্ত গেমিং ব্যালেন্স! দয়া করে ডিপোজিট করুন।' };
    }

    const matchId = `live_${Date.now()}`;
    const updatedUser = {
      ...user,
      gamingBalance: Number((user.gamingBalance - entryFee).toFixed(2)),
    };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    // Record Entry Fee Transaction
    const entryTrx: Transaction = {
      id: `trx_${Date.now()}`,
      trxNumber: `#${Math.floor(200000 + Math.random() * 800000)}`,
      type: 'match_loss',
      title: '1v1 Live Ludo Entry',
      subtitle: `${modeTitle} • Match #${matchId.slice(-4)}`,
      amount: -entryFee,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'match',
    };
    setTransactions(prev => [entryTrx, ...prev]);

    return { success: true, message: 'ম্যাচ শুরু হয়েছে!', matchId };
  };

  const finishLiveLudoMatch = (
    matchId: string, 
    entryFee: number, 
    won: boolean, 
    prize: number, 
    opponentName: string, 
    modeTitle: string
  ) => {
    if (won) {
      setUser(prev => {
        const updated = {
          ...prev,
          winningBalance: Number((prev.winningBalance + prize).toFixed(2)),
          totalWinnings: Number((prev.totalWinnings + prize).toFixed(2)),
          matchesPlayed: prev.matchesPlayed + 1,
        };
        setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
        return updated;
      });

      const winTrx: Transaction = {
        id: `trx_${Date.now()}`,
        trxNumber: `#${Math.floor(200000 + Math.random() * 800000)}`,
        type: 'match_win',
        title: '1v1 Live Ludo Victory 🏆',
        subtitle: `Vs ${opponentName} (${modeTitle})`,
        amount: prize,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [winTrx, ...prev]);
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.45 } });
    } else {
      setUser(prev => {
        const updated = {
          ...prev,
          matchesPlayed: prev.matchesPlayed + 1,
        };
        setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
        return updated;
      });

      const lossTrx: Transaction = {
        id: `trx_${Date.now()}`,
        trxNumber: `#${Math.floor(200000 + Math.random() * 800000)}`,
        type: 'match_loss',
        title: '1v1 Live Ludo Defeat',
        subtitle: `Vs ${opponentName} (${modeTitle})`,
        amount: -entryFee,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [lossTrx, ...prev]);
    }
  };

  const refundLiveLudoMatch = (matchId: string, entryFee: number, reason = 'Match Aborted') => {
    setUser(prev => {
      const updated = {
        ...prev,
        gamingBalance: Number((prev.gamingBalance + entryFee).toFixed(2)),
      };
      setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
      return updated;
    });

    const refTrx: Transaction = {
      id: `trx_${Date.now()}`,
      trxNumber: `#${Math.floor(200000 + Math.random() * 800000)}`,
      type: 'refund',
      title: 'Live Ludo Refund',
      subtitle: `${reason} • Match #${matchId.slice(-4)}`,
      amount: entryFee,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'match',
    };
    setTransactions(prev => [refTrx, ...prev]);
  };

  // Block Puzzle Duel Match Handlers
  const startBlockPuzzleMatch = (entryFee: number): { success: boolean; message: string; matchId?: string } => {
    if (user.gamingBalance < entryFee) {
      return { success: false, message: 'অপর্যাপ্ত গেমিং ব্যালেন্স! দয়া করে ওয়ালেটে টাকা রিচার্জ / ডিপোজিট করুন।' };
    }

    const matchId = `bp_${Date.now()}`;
    const updatedUser = {
      ...user,
      gamingBalance: Number((user.gamingBalance - entryFee).toFixed(2)),
    };
    setUser(updatedUser);
    setRegisteredUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));

    // Entry Fee Transaction
    const entryTrx: Transaction = {
      id: `trx_${Date.now()}`,
      trxNumber: `#${Math.floor(300000 + Math.random() * 600000)}`,
      type: 'match_loss',
      title: 'Block Puzzle Duel Entry',
      subtitle: `এন্ট্রি ফি ৳${entryFee} • Match #${matchId.slice(-4)}`,
      amount: -entryFee,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'match',
    };
    setTransactions(prev => [entryTrx, ...prev]);

    return { success: true, message: 'ম্যাচ শুরু হয়েছে!', matchId };
  };

  const finishBlockPuzzleMatch = (
    matchId: string, 
    entryFee: number, 
    won: boolean, 
    prize: number, 
    score: number,
    isDraw = false
  ) => {
    if (won) {
      setUser(prev => {
        const updated = {
          ...prev,
          winningBalance: Number((prev.winningBalance + prize).toFixed(2)),
          totalWinnings: Number((prev.totalWinnings + prize).toFixed(2)),
          matchesPlayed: prev.matchesPlayed + 1,
          matchesWon: (prev.matchesWon || 0) + 1,
        };
        setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
        return updated;
      });

      const winTrx: Transaction = {
        id: `trx_${Date.now()}`,
        trxNumber: `#${Math.floor(300000 + Math.random() * 600000)}`,
        type: 'match_win',
        title: 'Block Puzzle Duel Victory 🧩🏆',
        subtitle: `স্কোর: ${score} pts • প্রাইজ: ৳${prize}`,
        amount: prize,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [winTrx, ...prev]);
      confetti({ particleCount: 120, spread: 90, origin: { y: 0.45 } });
    } else if (isDraw) {
      setUser(prev => {
        const updated = {
          ...prev,
          gamingBalance: Number((prev.gamingBalance + entryFee).toFixed(2)),
          matchesPlayed: prev.matchesPlayed + 1,
        };
        setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
        return updated;
      });

      const drawTrx: Transaction = {
        id: `trx_${Date.now()}`,
        trxNumber: `#${Math.floor(300000 + Math.random() * 600000)}`,
        type: 'refund',
        title: 'Block Puzzle Match Draw (Refund)',
        subtitle: `ড্র হওয়ায় এন্ট্রি ফি ৳${entryFee} ফেরত দেওয়া হয়েছে`,
        amount: entryFee,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        category: 'match',
      };
      setTransactions(prev => [drawTrx, ...prev]);
    } else {
      setUser(prev => {
        const updated = {
          ...prev,
          matchesPlayed: prev.matchesPlayed + 1,
        };
        setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
        return updated;
      });
    }
  };

  const refundBlockPuzzleMatch = (matchId: string, entryFee: number, reason = 'Match Aborted') => {
    setUser(prev => {
      const updated = {
        ...prev,
        gamingBalance: Number((prev.gamingBalance + entryFee).toFixed(2)),
      };
      setRegisteredUsers(users => users.map(u => u.id === prev.id ? updated : u));
      return updated;
    });

    const refTrx: Transaction = {
      id: `trx_${Date.now()}`,
      trxNumber: `#${Math.floor(300000 + Math.random() * 600000)}`,
      type: 'refund',
      title: 'Block Puzzle Entry Refund',
      subtitle: `${reason} • Match #${matchId.slice(-4)}`,
      amount: entryFee,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'match',
    };
    setTransactions(prev => [refTrx, ...prev]);
  };

  // ================= ADMIN ACTIONS =================

  // 1. Match creation
  const createMatch = (matchData: Partial<Match>) => {
    const newMatch: Match = {
      id: `m_${Date.now()}`,
      matchNo: String(Math.floor(259000 + Math.random() * 9999)),
      title: matchData.title || '🔥 SPECIAL MATCH 🔥',
      subtitle: matchData.subtitle || '২ জন জয়েন হলেই স্টার্ট দেওয়া হবে।',
      category: matchData.category || 'special',
      totalPrize: matchData.totalPrize || 400,
      entryFee: matchData.entryFee || 220,
      version: matchData.version || 'Mobile',
      boardType: matchData.boardType || 'Ludo King',
      totalSeats: matchData.totalSeats || 2,
      joinedSeats: 0,
      joinedPlayers: [],
      status: 'open',
      roomCode: matchData.roomCode || '',
      isHot: matchData.isHot || false,
    };

    setMatches(prev => [newMatch, ...prev]);
  };

  // 2. Set Room ID (Admin enters room code created in Ludo King app)
  const setMatchRoomCode = (matchId: string, roomCode: string): boolean => {
    if (!roomCode.trim()) return false;

    setMatches(prev => prev.map(m => {
      if (m.id === matchId) {
        return {
          ...m,
          roomCode: roomCode.trim(),
          status: m.joinedSeats >= m.totalSeats ? 'ready_to_play' : m.status
        };
      }
      return m;
    }));
    return true;
  };

  // 3. Cancel Match and Auto-refund players
  const cancelMatchAndRefund = (matchId: string, reason = 'Admin cancelled match'): boolean => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return false;

    // Refund each joined player
    match.joinedPlayers.forEach(p => {
      // If current active user is one of the players
      if (p.userId === user.id || p.phone === user.phone) {
        setUser(u => ({
          ...u,
          gamingBalance: u.gamingBalance + match.entryFee
        }));
      }

      // Update in registeredUsers
      setRegisteredUsers(users => users.map(u => {
        if (u.id === p.userId || u.phone === p.phone) {
          return {
            ...u,
            gamingBalance: u.gamingBalance + match.entryFee
          };
        }
        return u;
      }));

      // Log refund transaction
      const refTrx: Transaction = {
        id: `t_${Date.now()}_${Math.random()}`,
        trxNumber: `#${Math.floor(100000 + Math.random() * 900000)}`,
        type: 'refund',
        title: 'Match Refund',
        subtitle: `Match #${match.matchNo} (${reason})`,
        amount: match.entryFee,
        status: 'COMPLETED',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        matchId: `#${match.matchNo}`,
        category: 'match',
      };
      setTransactions(txs => [refTrx, ...txs]);
    });

    setMatches(prev => prev.map(m => {
      if (m.id === matchId) {
        return { ...m, status: 'cancelled' };
      }
      return m;
    }));

    return true;
  };

  // 4. Delete Match
  const deleteMatch = (matchId: string): boolean => {
    setMatches(prev => prev.filter(m => m.id !== matchId));
    return true;
  };

  // 5. Approve Deposit Request
  const approveDepositRequest = (requestId: string): { success: boolean; message: string } => {
    const req = depositRequests.find(r => r.id === requestId);
    if (!req) return { success: false, message: 'রিকোয়েস্ট পাওয়া যায়নি।' };
    if (req.status !== 'PENDING') return { success: false, message: 'রিকোয়েস্টটি ইতিমধ্যে নিষ্পত্তি করা হয়েছে।' };

    // Credit user gaming balance
    if (req.userId === user.id || req.userPhone === user.phone) {
      setUser(u => ({
        ...u,
        gamingBalance: u.gamingBalance + req.amount
      }));
    }

    setRegisteredUsers(users => users.map(u => {
      if (u.id === req.userId || u.phone === req.userPhone) {
        return { ...u, gamingBalance: u.gamingBalance + req.amount };
      }
      return u;
    }));

    setDepositRequests(prev => prev.map(r => {
      if (r.id === requestId) {
        return { ...r, status: 'APPROVED' };
      }
      return r;
    }));

    // Update transaction
    setTransactions(prev => [
      {
        id: `t_${Date.now()}`,
        trxNumber: `#${Math.floor(10000 + Math.random() * 90000)}`,
        type: 'deposit',
        title: 'Deposit Approved',
        subtitle: `via ${req.method.toLowerCase()} (Approved by Admin)`,
        amount: req.amount,
        status: 'SUCCESS',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        trxId: req.trxId,
        paymentMethod: req.method,
        category: 'deposit',
      },
      ...prev
    ]);

    return { success: true, message: `৳${req.amount} টাকা ব্যবহারকারীর গেমিং ব্যালেন্সে যোগ হয়েছে!` };
  };

  // 6. Reject Deposit Request
  const rejectDepositRequest = (requestId: string, reason = 'ভুল ট্রানজেকশন আইডি'): { success: boolean; message: string } => {
    setDepositRequests(prev => prev.map(r => {
      if (r.id === requestId) {
        return { ...r, status: 'REJECTED', rejectReason: reason };
      }
      return r;
    }));
    return { success: true, message: 'ডিপোজিট রিকোয়েস্ট বাতিল করা হয়েছে।' };
  };

  // 7. Approve Withdraw Request
  const approveWithdrawRequest = (requestId: string, adminTrxId = `ADM${Math.floor(100000 + Math.random() * 900000)}`): { success: boolean; message: string } => {
    const req = withdrawRequests.find(r => r.id === requestId);
    if (!req) return { success: false, message: 'রিকোয়েস্ট পাওয়া যায়নি।' };
    if (req.status !== 'PENDING') return { success: false, message: 'রিকোয়েস্টটি ইতিমধ্যে নিষ্পত্তি করা হয়েছে।' };

    setWithdrawRequests(prev => prev.map(r => {
      if (r.id === requestId) {
        return { ...r, status: 'APPROVED', adminTrxId };
      }
      return r;
    }));

    setTransactions(prev => [
      {
        id: `t_${Date.now()}`,
        trxNumber: `#${Math.floor(10000 + Math.random() * 90000)}`,
        type: 'withdraw',
        title: 'Withdraw Paid',
        subtitle: `via ${req.method.toLowerCase()} (${req.accountNumber})`,
        amount: -req.amount,
        status: 'SUCCESS',
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        paymentMethod: req.method,
        trxId: adminTrxId,
        category: 'withdraw',
      },
      ...prev
    ]);

    return { success: true, message: `৳${req.amount} টাকা উইথড্র পরিশোধ হিসেবে চিহ্নিত করা হয়েছে!` };
  };

  // 8. Reject Withdraw Request & Refund winning balance
  const rejectWithdrawRequest = (requestId: string, reason = 'ভুল একাউন্ট নম্বর বা তথ্যে ত্রুটি'): { success: boolean; message: string } => {
    const req = withdrawRequests.find(r => r.id === requestId);
    if (!req) return { success: false, message: 'রিকোয়েস্ট পাওয়া যায়নি।' };

    // Refund winning balance to user
    if (req.userId === user.id || req.userPhone === user.phone) {
      setUser(u => ({
        ...u,
        winningBalance: u.winningBalance + req.amount
      }));
    }

    setRegisteredUsers(users => users.map(u => {
      if (u.id === req.userId || u.phone === req.userPhone) {
        return { ...u, winningBalance: u.winningBalance + req.amount };
      }
      return u;
    }));

    setWithdrawRequests(prev => prev.map(r => {
      if (r.id === requestId) {
        return { ...r, status: 'REJECTED', rejectReason: reason };
      }
      return r;
    }));

    return { success: true, message: 'উইথড্র বাতিল করে ব্যবহারকারীকে টাকা রিফান্ড করা হয়েছে।' };
  };

  // 9. Approve Result Submission -> Award Prize to Winner!
  const approveResultSubmission = (submissionId: string): { success: boolean; message: string } => {
    const sub = resultSubmissions.find(s => s.id === submissionId);
    if (!sub) return { success: false, message: 'সাবমিশন পাওয়া যায়নি।' };
    if (sub.status !== 'PENDING') return { success: false, message: 'এটি ইতিমধ্যে ভেরিফাই করা হয়েছে।' };

    const prize = sub.prizeAmount || 400;

    // Credit winner's winning balance
    if (sub.userId === user.id || sub.userPhone === user.phone) {
      setUser(u => ({
        ...u,
        winningBalance: u.winningBalance + prize,
        totalWinnings: u.totalWinnings + prize
      }));
    }

    setRegisteredUsers(users => users.map(u => {
      if (u.id === sub.userId || u.phone === sub.userPhone) {
        return {
          ...u,
          winningBalance: u.winningBalance + prize,
          totalWinnings: u.totalWinnings + prize
        };
      }
      return u;
    }));

    // Update Match Status to Completed
    if (sub.matchId || sub.roomCode) {
      setMatches(prev => prev.map(m => {
        if (m.id === sub.matchId || m.roomCode === sub.roomCode) {
          return {
            ...m,
            status: 'completed',
            winnerId: sub.userId,
            winnerName: sub.userName,
          };
        }
        return m;
      }));
    }

    // Mark submission APPROVED
    setResultSubmissions(prev => prev.map(s => {
      if (s.id === submissionId) {
        return { ...s, status: 'APPROVED', adminNote: 'Verified Winner' };
      }
      return s;
    }));

    // Add Match Win Transaction
    const winTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'match_win',
      title: 'Match Win',
      subtitle: `Room ID: ${sub.roomCode} (Admin Approved)`,
      amount: prize,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      roomCode: sub.roomCode,
      category: 'match',
    };
    setTransactions(prev => [winTrx, ...prev]);

    return { 
      success: true, 
      message: `🎉 বিজয়ী ${sub.userName} কে ৳${prize} টাকা উইনিং ব্যালেন্সে যোগ করে দেওয়া হয়েছে!` 
    };
  };

  // 10. Reject Result Submission
  const rejectResultSubmission = (submissionId: string, reason = 'ভুল বা নকল স্ক্রিনশট'): { success: boolean; message: string } => {
    setResultSubmissions(prev => prev.map(s => {
      if (s.id === submissionId) {
        return { ...s, status: 'REJECTED', adminNote: reason };
      }
      return s;
    }));
    return { success: true, message: 'রেজাল্ট স্ক্রিনশট বাতিল করা হয়েছে।' };
  };

  // 11. Adjust User Balance Manually
  const adjustUserBalance = (userId: string, balanceType: 'gaming' | 'winning', amount: number, isAddition: boolean, note = 'Admin adjustment'): boolean => {
    const delta = isAddition ? amount : -amount;

    setRegisteredUsers(users => users.map(u => {
      if (u.id === userId) {
        if (balanceType === 'gaming') {
          return { ...u, gamingBalance: Math.max(0, u.gamingBalance + delta) };
        } else {
          return { ...u, winningBalance: Math.max(0, u.winningBalance + delta) };
        }
      }
      return u;
    }));

    if (user.id === userId) {
      setUser(u => ({
        ...u,
        [balanceType === 'gaming' ? 'gamingBalance' : 'winningBalance']: Math.max(
          0,
          (balanceType === 'gaming' ? u.gamingBalance : u.winningBalance) + delta
        )
      }));
    }

    const adjTrx: Transaction = {
      id: `t_${Date.now()}`,
      trxNumber: `#${Math.floor(1000 + Math.random() * 9000)}`,
      type: isAddition ? 'admin_add' : 'admin_deduct',
      title: isAddition ? 'Admin Add' : 'Admin Deduct',
      subtitle: `via Admin - ${balanceType} (${note})`,
      amount: delta,
      status: 'COMPLETED',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' • ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      category: 'admin',
    };
    setTransactions(prev => [adjTrx, ...prev]);

    return true;
  };

  // 12. Toggle User Ban
  const toggleUserBan = (userId: string): boolean => {
    setRegisteredUsers(users => users.map(u => {
      if (u.id === userId) {
        return { ...u, isBanned: !u.isBanned };
      }
      return u;
    }));
    return true;
  };

  // 13. Update Payment & App Settings
  const updatePaymentSettings = (newSettings: Partial<PaymentSettings>) => {
    setPaymentSettings(prev => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem('lx_ludo_payment_settings', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isLoggedIn,
        login,
        register,
        logout,
        currentTab,
        setCurrentTab,
        matches,
        matchFilter,
        setMatchFilter,
        transactions,
        activeModal,
        openModal,
        closeModal,
        modalPayload,
        joinMatch,
        depositMoney,
        withdrawMoney,
        transferWinningBalance,
        submitResultScreenshot,
        refreshMatches,
        isRefreshing,
        playAutoLudoRound,
        startLiveLudoMatch,
        finishLiveLudoMatch,
        refundLiveLudoMatch,
        startBlockPuzzleMatch,
        finishBlockPuzzleMatch,
        refundBlockPuzzleMatch,
        
        // Admin
        isAdminMode,
        setIsAdminMode,
        registeredUsers,
        depositRequests,
        withdrawRequests,
        resultSubmissions,
        paymentSettings,
        updatePaymentSettings,
        createMatch,
        setMatchRoomCode,
        cancelMatchAndRefund,
        deleteMatch,
        approveDepositRequest,
        rejectDepositRequest,
        approveWithdrawRequest,
        rejectWithdrawRequest,
        approveResultSubmission,
        rejectResultSubmission,
        adjustUserBalance,
        toggleUserBan,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

