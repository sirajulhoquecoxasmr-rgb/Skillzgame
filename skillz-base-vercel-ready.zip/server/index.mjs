import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import { loadDb, saveDb, id, now, hashPassword, verifyPassword, publicUser } from './store.mjs';

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '4mb' }));

const PORT = Number(process.env.PORT || 8787);
const ADMIN_PHONE = process.env.ADMIN_PHONE || '01832822322';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-this-password';
const TOKEN_SECRET = process.env.TOKEN_SECRET || 'change-this-token-secret';
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || '*';

function sign(payload) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + 1000*60*60*24*7 })).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function readToken(token) {
  try {
    const [body, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch { return null; }
}

async function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const payload = readToken(token);
  if (!payload) return res.status(401).json({ message: 'Unauthorized' });
  const db = await loadDb();
  const user = db.users.find(u => u.id === payload.userId);
  if (!user || user.isBanned) return res.status(403).json({ message: 'Account unavailable' });
  req.user = user; req.db = db; next();
}
function admin(req, res, next) {
  if (!req.user?.isAdmin) return res.status(403).json({ message: 'Admin access required' });
  next();
}
function cleanMatch(m) { return m; }

app.get('/api/health', (req,res) => res.json({ ok:true, firebase:false, service:'skillz-base-backend', time:now() }));

app.post('/api/auth/register', async (req,res) => {
  const { name, phone, password, refCode='' } = req.body || {};
  if (!name || !phone || !password || String(password).length < 4) return res.status(400).json({ message:'Name, phone and password are required.' });
  const db = await loadDb();
  if (db.users.some(u => u.phone === String(phone).trim())) return res.status(409).json({ message:'Phone already registered.' });
  const user = { id:id('usr'), name:String(name).trim(), phone:String(phone).trim(), ludoKingName:String(name).trim(), passwordHash:hashPassword(String(password)), isAdmin:false, isBanned:false, gamingBalance:0, winningBalance:0, matchesPlayed:0, matchesWon:0, refCode, createdAt:now() };
  db.users.unshift(user); await saveDb(db);
  const token = sign({ userId:user.id });
  res.status(201).json({ token, user:publicUser(user) });
});

app.post('/api/auth/login', async (req,res) => {
  const { phone, password } = req.body || {};
  const db = await loadDb();
  let user = db.users.find(u => u.phone === String(phone||'').trim());
  if (!user && String(phone||'').trim() === ADMIN_PHONE && String(password||'') === ADMIN_PASSWORD) {
    user = { id:'admin_1', name:'Admin', phone:ADMIN_PHONE, ludoKingName:'Admin', passwordHash:hashPassword(ADMIN_PASSWORD), isAdmin:true, isBanned:false, gamingBalance:0, winningBalance:0, matchesPlayed:0, matchesWon:0, createdAt:now() };
    db.users.unshift(user); await saveDb(db);
  }
  if (!user || !verifyPassword(String(password||''), user.passwordHash)) return res.status(401).json({ message:'Invalid phone or password.' });
  if (user.isBanned) return res.status(403).json({ message:'Account is banned.' });
  res.json({ token:sign({ userId:user.id }), user:publicUser(user) });
});

app.get('/api/me', auth, (req,res)=>res.json({ user:publicUser(req.user) }));

app.get('/api/users', auth, admin, (req,res)=>res.json({ users:req.db.users.map(publicUser) }));
app.patch('/api/users/:id/ban', auth, admin, async (req,res)=>{
  const u=req.db.users.find(x=>x.id===req.params.id); if(!u) return res.status(404).json({message:'User not found'});
  u.isBanned=Boolean(req.body?.banned ?? !u.isBanned); await saveDb(req.db); res.json({user:publicUser(u)});
});
app.post('/api/users/:id/balance', auth, admin, async (req,res)=>{
  const u=req.db.users.find(x=>x.id===req.params.id); if(!u) return res.status(404).json({message:'User not found'});
  const { balanceType='gaming', amount=0, isAddition=true, note='Admin adjustment' }=req.body||{};
  if(!['gaming','winning'].includes(balanceType) || !Number.isFinite(Number(amount)) || Number(amount)<=0) return res.status(400).json({message:'Invalid balance adjustment'});
  const key=balanceType==='winning'?'winningBalance':'gamingBalance'; const delta=isAddition?Number(amount):-Number(amount);
  if(u[key]+delta < 0) return res.status(400).json({message:'Insufficient balance'});
  u[key]+=delta; req.db.transactions.unshift({id:id('txn'),userId:u.id,type:isAddition?'ADMIN_CREDIT':'ADMIN_DEBIT',amount:Number(amount),balanceType,note,createdAt:now()});
  await saveDb(req.db); res.json({user:publicUser(u)});
});

app.get('/api/matches', auth, (req,res)=>res.json({ matches:req.db.matches.map(cleanMatch) }));
app.post('/api/matches', auth, admin, async (req,res)=>{
  const m={ id:id('match'), status:'open', joinedSeats:0, joinedPlayers:[], createdAt:now(), ...req.body };
  req.db.matches.unshift(m); await saveDb(req.db); res.status(201).json({match:m});
});
app.patch('/api/matches/:id/room', auth, admin, async (req,res)=>{
  const m=req.db.matches.find(x=>x.id===req.params.id); if(!m) return res.status(404).json({message:'Match not found'});
  m.roomCode=String(req.body?.roomCode||'').trim(); m.status=m.roomCode?'ready_to_play':m.status; await saveDb(req.db); res.json({match:m});
});
app.delete('/api/matches/:id', auth, admin, async (req,res)=>{
  const before=req.db.matches.length; req.db.matches=req.db.matches.filter(x=>x.id!==req.params.id); if(before===req.db.matches.length) return res.status(404).json({message:'Match not found'}); await saveDb(req.db); res.json({ok:true});
});
app.post('/api/matches/:id/cancel', auth, admin, async (req,res)=>{
  const m=req.db.matches.find(x=>x.id===req.params.id); if(!m) return res.status(404).json({message:'Match not found'});
  m.status='cancelled'; m.cancelReason=req.body?.reason||'Cancelled by admin'; await saveDb(req.db); res.json({match:m});
});

for (const kind of ['depositRequests','withdrawRequests','resultSubmissions']) {
  const route = kind.replace(/Requests|Submissions/,'').toLowerCase();
  app.get(`/api/${route}-requests`, auth, admin, (req,res)=>res.json({ [kind]:req.db[kind] }));
}
app.post('/api/deposit-requests', auth, async (req,res)=>{
  const r={id:id('dep'),userId:req.user.id,status:'PENDING',createdAt:now(),...req.body}; req.db.depositRequests.unshift(r); await saveDb(req.db); res.status(201).json({request:r});
});
app.post('/api/withdraw-requests', auth, async (req,res)=>{
  const amount=Number(req.body?.amount||0); if(amount<=0 || req.user.winningBalance<amount) return res.status(400).json({message:'Insufficient winning balance'});
  req.user.winningBalance-=amount; const r={id:id('wd'),userId:req.user.id,status:'PENDING',createdAt:now(),...req.body,amount}; req.db.withdrawRequests.unshift(r); await saveDb(req.db); res.status(201).json({request:r});
});
app.patch('/api/deposit-requests/:id', auth, admin, async (req,res)=>{
  const r=req.db.depositRequests.find(x=>x.id===req.params.id); if(!r) return res.status(404).json({message:'Request not found'});
  r.status=req.body?.status||r.status; r.adminNote=req.body?.reason||req.body?.note||'';
  if(r.status==='APPROVED' && !r.applied){ const u=req.db.users.find(x=>x.id===r.userId); if(u){u.gamingBalance+=Number(r.amount||0); r.applied=true;} }
  await saveDb(req.db); res.json({request:r});
});
app.patch('/api/withdraw-requests/:id', auth, admin, async (req,res)=>{
  const r=req.db.withdrawRequests.find(x=>x.id===req.params.id); if(!r) return res.status(404).json({message:'Request not found'});
  r.status=req.body?.status||r.status; r.adminTrxId=req.body?.adminTrxId||''; r.adminNote=req.body?.reason||'';
  if(r.status==='REJECTED' && !r.refunded){ const u=req.db.users.find(x=>x.id===r.userId); if(u){u.winningBalance+=Number(r.amount||0); r.refunded=true;} }
  await saveDb(req.db); res.json({request:r});
});
app.patch('/api/result-submissions/:id', auth, admin, async (req,res)=>{
  const r=req.db.resultSubmissions.find(x=>x.id===req.params.id); if(!r) return res.status(404).json({message:'Submission not found'});
  r.status=req.body?.status||r.status; r.adminNote=req.body?.reason||''; await saveDb(req.db); res.json({submission:r});
});

app.get('/api/settings', auth, (req,res)=>res.json({paymentSettings:req.db.paymentSettings}));
app.patch('/api/settings', auth, admin, async (req,res)=>{ req.db.paymentSettings={...req.db.paymentSettings,...req.body}; await saveDb(req.db); res.json({paymentSettings:req.db.paymentSettings}); });

app.use((err,req,res,next)=>{ console.error(err); res.status(500).json({message:'Server error'}); });
app.listen(PORT, ()=>console.log(`Skillz Base backend listening on http://localhost:${PORT}`));
