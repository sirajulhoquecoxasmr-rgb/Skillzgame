import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const DATA_DIR = path.resolve(process.env.DATA_DIR || './server/data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const defaults = {
  users: [], matches: [], transactions: [], depositRequests: [], withdrawRequests: [], resultSubmissions: [],
  paymentSettings: {
    marqueeNotice: 'Welcome to Skillzgame', popupNoticeTitle: 'Notice', popupNoticeText: 'Play fairly and have fun.'
  }
};

export async function loadDb() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try { return JSON.parse(await fs.readFile(DB_FILE, 'utf8')); }
  catch { await saveDb(defaults); return structuredClone(defaults); }
}

export async function saveDb(db) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const tmp = `${DB_FILE}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(db, null, 2));
  await fs.rename(tmp, DB_FILE);
}

export function id(prefix='id') { return `${prefix}_${crypto.randomUUID()}`; }
export function now() { return new Date().toISOString(); }
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
export function verifyPassword(password, stored) {
  try {
    const [salt, hex] = stored.split(':');
    const a = Buffer.from(hex, 'hex');
    const b = crypto.scryptSync(password, salt, 64);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}
export function publicUser(u) {
  if (!u) return null;
  const { passwordHash, ...safe } = u;
  return safe;
}
